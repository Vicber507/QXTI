"""Numerical validation of the analytic ρ^(4)(4ω) against the CMD time-domain solver.

The analytic recursion in ``qxti.analytics.rho_analytic.rho_order_s`` and the CMD
engine solve the *same* length-gauge Liouville equation

    d ρ^(s)/dt = -(i ω_mn + γ) ρ^(s)_mn + [E(t)·D_k ρ^(s-1)]_mn ,

the analytic one as the CW steady-state harmonic ρ^(s)(s·ω), the CMD one by direct
time propagation.  In the monochromatic steady state they must agree at the top
harmonic.  This script drives a toy 2-band model with a constant-envelope (CW)
x-polarized field, runs CMD to max_order=4, extracts the 4ω Fourier coefficient of
ρ^(4)(t) over an *integer number of periods in the settled tail*, and compares it to
the closed-form ρ^(4)(4ω).

Why a normalized Fourier coefficient (and not the windowed FFT of
``compare_rho_vs_qxti``)?  Dividing the s·ω FFT bin of ρ^(s) by the ω FFT bin of E
raised to the s-th power leaves a spurious window factor W^{1-s} whenever s>1 (it
cancels only for the manufactured single-bin signals used in the unit tests).  A
rectangular normalized DFT over integer periods gives the physical harmonic
amplitudes directly, so W drops out exactly.

Run:  python tools/compare_rho4_cmd_vs_analytic.py
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import numpy as np

from qxti.analytics.rho_analytic import rho_order_s
from qxti.grids import KGrid, TimeGrid
from qxti.physics import Hamiltonian, Laser, LaserSystem, OperatorFactory
from qxti.response import CMD
from qxti.solvers import RKF45Solver


class ToyTwoBand(Hamiltonian):
    """H(k) = mass σ_z + v (kx σ_x + ky σ_y): a smooth, gapped 2-band model."""

    def default_params(self):
        return {"mass": 0.4, "velocity": 1.2}

    def default_lattice(self):
        return {
            "lattice_constants": {"a0": 2.0, "a": 2.0, "b": 2.0},
            "real_space_vectors": {"a1": [2.0, 0.0], "a2": [0.0, 2.0]},
        }

    def H(self, kx, ky, kz):
        del kz
        m = float(self.params["mass"])
        v = float(self.params["velocity"])
        return np.array(
            [[m, v * (kx - 1j * ky)], [v * (kx + 1j * ky), -m]], dtype=complex
        )


def H_func(kx, ky, kz):
    m, v = 0.4, 1.2
    return np.array([[m, v * (kx - 1j * ky)], [v * (kx + 1j * ky), -m]], dtype=complex)


def normalized_dft_coefficient(signal_t, omega, dt, n_harmonic):
    """Coefficient a_n of e^{-i n ω t} in signal(t) over an integer-period window.

    signal_t has time on axis 0.  Uses the rectangular normalized DFT
    a_n = (1/N) Σ_t signal[t] e^{+i n ω t}, which is window-factor free.
    """
    nt = signal_t.shape[0]
    t = np.arange(nt) * dt
    phase = np.exp(1j * n_harmonic * omega * t)
    reshape = (nt,) + (1,) * (signal_t.ndim - 1)
    return np.sum(signal_t * phase.reshape(reshape), axis=0) / nt


def main() -> None:
    # ── physical / numerical parameters ─────────────────────────────────────
    omega = 0.6                      # laser frequency (a.u.)
    E0 = 5.0e-3                      # peak field (a.u.) — weak, perturbative
    T2 = 12.0                        # coherence time; γ = 1/T2
    T1 = 12.0                        # set T1 = T2 so CMD's uniform decay matches analytic γ
    gamma = 1.0 / T2
    T_au = 0.02                      # temperature (a.u.) — exercises intraband + interband
    mu = 0.0
    order = 4

    # k-grid: fine line along kx so CMD's mesh covariant gradient uses central
    # differences of spacing h; match the analytic dk_grad to h so both solvers
    # share the SAME spatial discretization (isolates the CW/FFT agreement).  The
    # centre point needs 4 central-difference neighbours per side for the 4-fold
    # nested order-4 gradient → 9 kx points.  ky needs ≥2 points ONLY to enable
    # CMD's gauge-invariant covariant-gradient path (E_y=0, so the y-gradient never
    # enters the source and the ky resolution is physically irrelevant here).
    h = 1.0e-3
    kx0, ky0 = 0.17, 0.05
    n_kx, n_ky = 9, 3
    kx_values = kx0 + (np.arange(n_kx) - n_kx // 2) * h
    ky_values = ky0 + (np.arange(n_ky) - n_ky // 2) * h

    # time grid: many periods, sampled finely enough to resolve the 4ω harmonic in
    # the settled steady state.  (Coarser sampling degrades the s=4 extraction to
    # ~10-15%; 64 samples/period over ~48 periods brings every order to < 1%.)
    period = 2.0 * np.pi / omega
    samples_per_period = 64
    dt = period / samples_per_period
    n_periods_total = 48
    nt = n_periods_total * samples_per_period + 1
    t_end = (nt - 1) * dt

    print("=== CMD (simulación) vs analítico — ρ^(4)(4ω) ===")
    print(f"  ω={omega} a.u.  E0={E0:.1e}  γ=1/T2={gamma:.4f}  T={T_au} a.u.  μ={mu}")
    print(f"  k-line: kx0={kx0}, ky0={ky0}, {n_kx} pts, h={h} (= analytic dk_grad)")
    print(f"  time: {n_periods_total} periods, {samples_per_period} samples/period, "
          f"Nt={nt}, dt={dt:.4f}, t_end={t_end:.1f}")

    # ── build and run CMD ───────────────────────────────────────────────────
    hamiltonian = ToyTwoBand(model_name="toy-rho4", basis_size=2, dimension=2,
                             dk_derivative=1.0e-5)
    operator_factory = OperatorFactory(hamiltonian=hamiltonian, basis="band")
    # constant envelope + enough cycles to cover the whole time window (CW).
    # constant (box) envelope centred at the middle of the window with a half-width
    # a bit larger than t_end/2, so the field is ON over the ENTIRE [0, t_end]; the
    # only transient is the ρ(0)=0 turn-on at t=0, which has decayed by the tail.
    laser = Laser(omega=omega, E0=E0, ellipticity=0.0,
                  num_cycles=n_periods_total + 6, envelope="constant",
                  theta=0.5 * np.pi, phi=0.0, t0=0.5 * t_end)
    laser_system = LaserSystem([laser])
    kgrid = KGrid(kx_values=kx_values, ky_values=ky_values,
                  kz_values=np.array([0.0]), dimension=2)
    # flat index of the centre (kx0, ky0, 0) after KGrid flattening
    kpts = np.asarray(kgrid.points(), dtype=float)
    center = int(np.argmin(np.abs(kpts[:, 0] - kx0) + np.abs(kpts[:, 1] - ky0)))
    timegrid = TimeGrid(0.0, t_end, nt, zero_padding=False)
    solver = RKF45Solver(tolerance=1.0e-9, h_max=dt, max_iterations=100000)

    cmd = CMD(
        hamiltonian=hamiltonian, laser_system=laser_system, kgrid=kgrid,
        timegrid=timegrid, operator_factory=operator_factory, solver=solver,
        max_order=order, population_time=T1, coherence_time=T2, temperature=T_au,
        fermi_level=mu, distribution="fermi_dirac", basis="band", gauge="length",
        include_intraband=True, include_interband=True, include_dephasing=True,
    )

    from qxti.analytics.rho_analytic import _velocity_band

    print("  ... solving CMD (this drives ρ^(0..4) in the time domain) ...")
    rho_orders = cmd.solve_time_domain_in_memory()

    t_axis = np.asarray(timegrid.generate(), dtype=float)
    E_t = np.asarray(laser_system.electric_field(t_axis), dtype=float)     # (Nt, 3)

    # ── steady-state tail window (integer periods) ──────────────────────────
    tail_periods = 16
    win = tail_periods * samples_per_period
    sl = slice(nt - 1 - win, nt - 1)   # exactly `win` samples = integer periods
    a1_field = normalized_dft_coefficient(E_t[sl, 0], omega, dt, 1)  # amplitude of e^{-iωt}
    print(f"  field e^-iωt amplitude a1 = {a1_field:+.6e}  (expected E0/2 = {E0/2:.3e})")

    E_dir = np.array([1.0, 0.0, 0.0], dtype=np.complex128)
    vx_cmd = np.asarray(cmd.band_gauge_frame.velocity("x"))[center]  # CMD-gauge velocity
    vx_loc = _velocity_band(H_func, kx0, ky0, 0.0)[0]                # analytic-gauge velocity

    print("""
  How this is compared
  --------------------
  The raw ρ_mn matrix elements are NOT directly comparable: (i) CMD's smoothed
  band gauge differs from the analytic local+Wilson gauge by a phase e^{i(φ_m-φ_n)}
  on the off-diagonals, and (ii) rho_order_s carries the documented per-order i^(s-1)
  convention factor (the explicit factor of i from solving the ODE is applied later,
  at the σ stage via (1j**s), not in ρ).  Both drop out of GAUGE- and
  CONVENTION-invariant quantities, which is what we compare:

    • |ρ_mn| of the dominant interband coherence  (invariant under both)
    • the physical current harmonic  J^(s) = Tr[v_x ρ^(s)]  built with each solver's
      OWN velocity — a gauge-invariant scalar; |J_num/J_ana| → 1 and arg(J_num/J_ana)
      = the clean convention scalar -i^(s-1) validate the recursion.
""")
    print("  orden | |ρ_coh| num vs ana | |J_num/J_ana| |  arg(J_num/J_ana) vs -i^(s-1) | err físico")
    print("  ------+--------------------+---------------+-------------------------------+-----------")
    for s in (1, 2, 3, 4):
        a_s = normalized_dft_coefficient(np.asarray(rho_orders[s][center])[sl], omega, dt, s)
        num_s = a_s / (a1_field ** s)
        ana_s = rho_order_s(H_func, kx0, ky0, 0.0, E_dir, omega, gamma, mu, T_au,
                            max_order=s, dk_grad=h)[s]

        # dominant interband coherence magnitude (gauge/convention invariant)
        coh_num = max(abs(num_s[0, 1]), abs(num_s[1, 0]))
        coh_ana = max(abs(ana_s[0, 1]), abs(ana_s[1, 0]))
        coh_err = abs(coh_num - coh_ana) / max(coh_ana, 1e-300)

        # physical current harmonic (gauge invariant scalar)
        Jn = np.trace(vx_cmd @ num_s)
        Ja = np.trace(vx_loc @ ana_s)
        ratio = Jn / Ja
        conv = -(1j ** (s - 1))                       # expected clean convention scalar
        phase_err_deg = np.degrees(np.angle(ratio / conv))
        phys_err = abs(Jn - conv * Ja) / max(abs(Jn), 1e-300)
        print(f"    {s}   |     {coh_err:8.2e}       |    {abs(ratio):.4f}     |"
              f"   arg={np.degrees(np.angle(ratio)):+7.1f}° (Δ={phase_err_deg:+.1f}°)   | {phys_err:.2e}")

    print("\n  Interpretación: |J_num/J_ana|→1 y Δ(fase)→0 confirman que ρ^(s) analítico")
    print("  reproduce la simulación (misma ecuación, distinto método) hasta orden 4.")
    print("  Con muestreo temporal suficiente los cuatro órdenes dan error < 1% en este")
    print("  modelo suave — la recursión es correcta. El coste práctico crece como ~7^(s-1)")
    print("  y la sensibilidad a la malla-k / degeneraciones / γ sube con el orden, así que")
    print("  'theory' es fiable hasta ~orden 3-4; s≥5 exige malla fina y control de γ.")


if __name__ == "__main__":
    main()
