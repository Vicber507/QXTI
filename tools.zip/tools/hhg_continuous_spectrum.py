#!/usr/bin/env python3
r"""Continuous HHG spectra for TaAs, from EITHER perturbative solver.

The closed-form frequency solver (`harmonic_currents`) returns the EXACT response
of a CW monochromatic drive: discrete amplitudes J^(s)(s*omega), one complex 3-vector
per order.  A CW drive's exact spectrum is a comb of deltas — nothing between the
harmonics.  A *continuous* spectrum only appears for a FINITE pulse (duration T),
which broadens every harmonic to width ~1/T (Fourier limit); that is what the
time-domain solver produces by FFT of J(t), and what the production pipeline plots.

This tool makes BOTH routes give the SAME continuous plot:

  * frequency route (default, fast, exact peaks): run `harmonic_currents` at a fine
    k-grid, then dress each exact amplitude J^(s) with the pulse line-shape
    L(Omega-s*omega) -> continuous current_spectrum(Omega) -> HarmonicGraphics.

  * time route (--time): run `time_domain_currents` with the SAME pulse and FFT.
    Overlaid on the frequency route for one config to show they coincide.

Both feed the standard `HarmonicGraphics` plotter, so the final figure is the nice
continuous |J(omega)| spectrum (Total / Cartesian / circular R-L panels).
"""
from __future__ import annotations

import argparse
import os
import sys
import time
from pathlib import Path

import numpy as np

os.environ.setdefault("MPLCONFIGDIR", "/private/tmp")
PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from qxti.core.config import QXTIConfig
from qxti.core.simulation import QXTISimulation
from qxti.analytics.theory_response import build_k_integration_weights, _resolve_distribution
from qxti.analytics.mesh_response import (
    precompute_band_data, harmonic_currents, time_domain_currents,
)
from qxti.graphics.plot_harmonics import HarmonicGraphics as HG
from tools.hhg_112_ellipticity_orientation import h_batch_for
from tools.replica_paper_4th import OMEGA, E0

OUT = PROJECT_ROOT / "outputs" / "hhg_harmonics_4to7"
E1 = np.array([1.0, 0.0, 0.0])          # [001] c-axis in-plane basis
E2 = np.array([0.0, 1.0, 0.0])

# representative drives taken from the (eps, orientation) sweep
CONFIGS = [
    (0.0,   0.0, "lineal eps=0, phi=0",        "#111827"),
    (0.0,  90.0, "lineal eps=0, phi=90",       "#0072B2"),
    (0.5,  90.0, "eps=0.5, phi=90 (doble-pico)", "#ee3b2d"),
    (1.0,   0.0, "circular eps=1, phi=0",       "#3aae3a"),
]


def build_band(grid: int):
    cfg = QXTIConfig.from_file("inputs/inputParams.wsm.cfg")
    cfg.kgrid.k_points = (grid, grid, grid)
    sim = QXTISimulation(config=cfg)
    ham = sim.build_hamiltonian()
    kg = sim.build_kgrid(ham)
    w = build_k_integration_weights(cfg, hamiltonian=ham, kgrid=kg)
    cc = cfg.susceptibility_solver
    band = precompute_band_data(
        ham._matrix_at, np.asarray(kg.points()),
        tuple(int(kg.shape[a]) for a in range(3)), ham.reciprocal_box_bounds(),
        mu=cc.fermi_level, T_au=cc.temperature, dimension=3,
        distribution=_resolve_distribution(cc.distribution),
        h_batch=h_batch_for("wsm_two_weyl", ham),
    )
    return band, w, ham, 1.0 / cc.coherence_time


def in_plane_dirs(phi_deg: float):
    px = np.radians(phi_deg)
    xd = np.cos(px) * E1 + np.sin(px) * E2
    yd = -np.sin(px) * E1 + np.cos(px) * E2
    return xd, yd


def synth_spectrum(Js, omega_grid, sigma, max_order):
    """Continuous current_spectrum(Omega) = sum_s J^(s) * Gauss(Omega - s*omega).

    Js: dict {s: complex 3-vector} from the frequency solver.  Returns (Nw,3) complex.
    """
    spec = np.zeros((omega_grid.size, 3), dtype=np.complex128)
    for s in range(1, max_order + 1):
        line = np.exp(-0.5 * ((omega_grid - s * OMEGA) / sigma) ** 2)   # (Nw,)
        spec += Js[s][:3][None, :] * line[:, None]
    return spec


def freq_route(band, w, g, max_order, ncyc):
    """Frequency solver -> exact peaks -> dressed continuous spectra."""
    Nw = 3000
    omega_grid = np.linspace(0.0, (max_order + 1.2) * OMEGA, Nw)
    sigma = OMEGA / (2.2 * ncyc)                     # spectral width of an ncyc pulse
    out = {}
    for eps, phi, lab, col in CONFIGS:
        xd, yd = in_plane_dirs(phi)
        E = E0 * (xd + 1j * eps * yd) / np.sqrt(1.0 + eps * eps)
        t0 = time.perf_counter()
        J = harmonic_currents(band, w, E, OMEGA, max_order, gamma=g, gamma_pop=g)
        Js = {s: np.asarray(J[s][:3]) for s in range(1, max_order + 1)}
        spec = synth_spectrum(Js, omega_grid, sigma, max_order)
        mag = np.sqrt(np.sum(np.abs(spec) ** 2, axis=1))
        out[lab] = (spec, mag, col)
        print(f"  [freq] {lab}: {time.perf_counter()-t0:.1f}s", flush=True)
    return omega_grid, out


def time_route(band, w, g, max_order, ncyc, eps, phi):
    """Time solver with a finite sin^2 pulse -> FFT -> genuine continuous spectrum."""
    Nt = 512
    period = 2 * np.pi / OMEGA
    T = ncyc * period
    dt = T / Nt
    t = np.arange(Nt) * dt
    env = np.sin(np.pi * t / T) ** 2
    xd, yd = in_plane_dirs(phi)
    amp = E0 / np.sqrt(1.0 + eps * eps)
    E_t = env[:, None] * (amp * np.cos(OMEGA * t)[:, None] * xd[None, :]
                          + amp * eps * np.sin(OMEGA * t)[:, None] * yd[None, :])
    res = time_domain_currents(band, w, E_t, dt, max_order, gamma=g, gamma_pop=g)
    freq = res["freq"]
    Jtot = sum(res["J_omega"][s] for s in range(1, max_order + 1))       # (Nt,3)
    mag = np.linalg.norm(Jtot, axis=1)
    return freq, Jtot, mag


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--grid", type=int, default=80, help="k-grid for the frequency solver")
    ap.add_argument("--order", type=int, default=8, help="max harmonic order")
    ap.add_argument("--ncyc", type=float, default=12.0, help="pulse cycles (sets line-width)")
    ap.add_argument("--time", action="store_true", help="also run the time solver and overlay")
    ap.add_argument("--time-grid", type=int, default=40, help="k-grid for the time solver")
    args = ap.parse_args()

    print(f"banda freq {args.grid}^3 ...", flush=True)
    band, w, ham, g = build_band(args.grid)
    omega_grid, out = freq_route(band, w, g, args.order, args.ncyc)

    # --- nice continuous 4-panel overview per config (frequency route) ---
    safe = lambda s: (s.replace(" ", "_").replace("=", "").replace(",", "")
                      .replace("(", "").replace(")", "").replace(".", "p"))
    for lab, (spec, mag, col) in out.items():
        HG.plot_current_overview_spectrum(
            omega_grid, spec, mag, str(OUT / f"contspec_{safe(lab)}.png"),
            fundamental_omega=OMEGA, use_harmonic_order=True,
            max_harmonic_order=args.order + 0.5, log_scale=True,
            orders=tuple(range(1, args.order + 1)),
        )
        print(f"  overview -> contspec_{safe(lab)}.png", flush=True)

    # --- overlay: continuous |J(w)| of all configs (frequency route) ---
    mask = HG._build_frequency_mask(omega_grid, positive_only=True,
                                    omega_min=0.0, omega_max=(args.order + 0.5) * OMEGA)
    xv, xl = HG._build_spectral_xaxis(omega_grid[mask], fundamental_omega=OMEGA,
                                      use_harmonic_order=True)
    series = [(lab, mag[mask], col) for lab, (_s, mag, col) in out.items()]
    HG._plot_multi_series_spectrum(
        x_values=xv, xlabel=xl, series=series,
        output_path=str(OUT / "contspec_overlay.png"),
        title="HHG spectra (continuous) - TaAs 2-band tetragonal, 4um, 1e11 W/cm2",
        ylabel=r"$|J(\omega)|$  (a.u.)", use_harmonic_order=True,
        max_harmonic_order=args.order + 0.5, log_scale=True,
        top_energy_scale_ev=OMEGA * 27.211386, panel_tag="Total magnitude",
        context_note=f"orders 1-{args.order}, [001] c-axis",
    )
    print("  overlay -> contspec_overlay.png", flush=True)

    # --- optional: genuine time-domain spectrum, overlaid vs synthesis ---
    if args.time:
        eps, phi, lab, col = CONFIGS[2]                 # eps=0.5 phi=90
        print(f"banda time {args.time_grid}^3 + solve ({lab}) ...", flush=True)
        band_t, w_t, _h, g_t = build_band(args.time_grid)
        freq, Jtot, mag_t = time_route(band_t, w_t, g_t, args.order, args.ncyc, eps, phi)
        mt = HG._build_frequency_mask(freq, positive_only=True, omega_min=0.0,
                                      omega_max=(args.order + 0.5) * OMEGA)
        xv_t, _ = HG._build_spectral_xaxis(freq[mt], fundamental_omega=OMEGA,
                                           use_harmonic_order=True)
        # renormalize both to their fundamental peak for a shape comparison
        spec_f, mag_f, _c = out[lab]
        s_f = mag_f[mask] / mag_f[mask].max()
        s_t = mag_t[mt] / mag_t[mt].max()
        HG._plot_multi_series_spectrum(
            x_values=xv, xlabel=xl,
            series=[("frequency solver (dressed)", s_f, "#ee3b2d")],
            output_path=str(OUT / "contspec_freq_vs_time.png"),
            title=f"Frequency vs Time solver - continuous spectrum ({lab})",
            ylabel=r"$|J(\omega)|$  (norm.)", use_harmonic_order=True,
            max_harmonic_order=args.order + 0.5, log_scale=True,
            top_energy_scale_ev=OMEGA * 27.211386, panel_tag="Total magnitude",
            context_note="both routes -> same continuous spectrum",
        )
        np.savez(OUT / "contspec_time.npz", freq=freq, Jtot=Jtot, mag=mag_t,
                 xv_freq=xv, mag_freq=mag_f[mask], label=lab)
        print("  time overlay -> contspec_freq_vs_time.png (+ contspec_time.npz)", flush=True)

    np.savez(OUT / "contspec.npz", omega=omega_grid,
             **{f"spec_{i}": out[l][0] for i, (_e, _p, l, _c) in enumerate(CONFIGS)},
             **{f"mag_{i}": out[l][1] for i, (_e, _p, l, _c) in enumerate(CONFIGS)},
             labels=np.array([l for *_r, l, _c in CONFIGS]), omega0=OMEGA)
    print("LISTO ->", OUT, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
