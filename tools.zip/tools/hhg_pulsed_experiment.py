#!/usr/bin/env python3
r"""HHG ellipticity maps (HO 4-7) + example spectra for TaAs, as a NORMAL PULSED laser.

Single-colour, perturbative drive -> the frequency (CW closed-form) solver is EXACT and
~100x cheaper than the time-domain, because a finite pulse only multiplies each harmonic
by the analytic kinematic factor

    pulsed_J^(N)(N*omega)  =  CW_J^(N)(N*omega)  x  ( sum_t env(t)^N )  x  2^(-N)

(env^N = the sin^2 pulse envelope raised to the harmonic order; 2^(-N) = the real-field
cos = (e^{+}+e^{-})/2 convention).  That factor is COMMON to every (eps, orientation), so
it cancels in any normalised map -> the pulsed maps equal the CW maps.  We therefore build
everything from the CW solver but DRESS it as a real ncyc pulse:

  * MAPS  (HO 4-7): reuse the exact CW currents J^(N)(eps, orientation) at 80^3, apply the
    analyzer conventions (even = co-rotating cross 90 deg; odd = fixed 0 + eps flip) and the
    pulse weight, and plot the ellipticity x orientation heat/waterfall maps.

  * SPECTRA (examples): run the CW solver for a few drives, place each J^(N) at N*omega with
    the pulse line-shape and the env^N 2^-N weight -> a continuous, experiment-faithful
    spectrum, drawn with the standard qxti graphics (HarmonicGraphics overview panels).

Time-domain is reserved for what CW genuinely cannot do: multi-colour laser SYSTEMS (two+
lasers at different frequencies), where every mixing product must appear automatically.
"""
from __future__ import annotations

import math
import os
import sys
import time
from pathlib import Path

import numpy as np

os.environ.setdefault("MPLCONFIGDIR", "/private/tmp")
PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from qxti.core.config import QXTIConfig
from qxti.core.simulation import QXTISimulation
from qxti.analytics.theory_response import build_k_integration_weights, _resolve_distribution
from qxti.analytics.mesh_response import precompute_band_data, harmonic_currents
from qxti.graphics.plot_harmonics import HarmonicGraphics as HG
from tools.hhg_112_ellipticity_orientation import h_batch_for
from tools.replica_paper_4th import OMEGA, E0, plot_paper

OUT = PROJECT_ROOT / "outputs" / "hhg_pulsed_experiment"
CW_DATA = PROJECT_ROOT / "outputs" / "hhg_harmonics_4to7" / "all_data.npz"
E1 = np.array([1.0, 0.0, 0.0])                 # [001] c-axis in-plane basis
E2 = np.array([0.0, 1.0, 0.0])
NCYC = 8                                        # pulse cycles (sets the line-shape + env^N)
MAX_ORDER = 7                                    # recursion order = highest harmonic (rho^7 -> up to 7th)


def pulse_weights(max_order: int, ncyc: int, nt: int = 8192):
    """Relative pulsed weight per harmonic: (mean env^N)/(mean env) * 2^-(N-1)."""
    x = np.linspace(0.0, np.pi, nt, endpoint=False)
    env = np.sin(x) ** 2                        # sin^2 envelope over one pulse
    m1 = np.mean(env)
    return {N: (np.mean(env ** N) / m1) * 0.5 ** (N - 1) for N in range(1, max_order + 1)}


def in_plane_dirs(phi_deg: float):
    px = np.radians(phi_deg)
    xd = np.cos(px) * E1 + np.sin(px) * E2
    yd = -np.sin(px) * E1 + np.cos(px) * E2
    return xd, yd


# ------------------------------------------------------------------ maps
def build_maps(wN):
    if not CW_DATA.exists():
        print(f"  (sin {CW_DATA}; corre primero el barrido CW HO 4-7)", flush=True)
        return
    d = np.load(CW_DATA)
    eps, oris, Jall = d["eps"], d["oris"], d["Jall"]     # Jall[ori,eps,harm(4,5,6,7),xyz]
    harms = [4, 5, 6, 7]
    titles = {4: "(a) 4th harmonic", 5: "(b) 5th harmonic",
              6: "(c) 6th harmonic", 7: "(d) 7th harmonic"}
    colors = {4: "#ee3b2d", 5: "#f7a01d", 6: "#3aae3a", 7: "#2a7fff"}
    M = {}
    for k, N in enumerate(harms):
        m = np.zeros((oris.size, eps.size))
        for io, ori in enumerate(oris):
            px = np.radians(ori)
            epol = (np.cos(px + np.pi / 2) * E1 + np.sin(px + np.pi / 2) * E2
                    if N % 2 == 0 else E1)                # even: co-rot cross; odd: fixed
            proj = Jall[io, :, k, :] @ epol               # (eps,)  projected current
            m[io] = np.abs(proj * wN[N]) ** 2             # pulsed yield (env^N weight)
        if N % 2 == 1:
            m = m[:, ::-1]                                # odd convention: eps inverted
        M[N] = m
        plot_paper(m, eps, oris, str(OUT / f"map_harmonic_{N}.png"),
                   title=titles[N], color=colors[N])
        print(f"  map HO{N} -> map_harmonic_{N}.png", flush=True)
    np.savez(OUT / "pulsed_maps.npz", eps=eps, oris=oris,
             **{f"M{N}": M[N] for N in harms}, ncyc=NCYC,
             weights=np.array([wN[N] for N in harms]))


# ------------------------------------------------------------------ spectra
def build_spectra(wN):
    cfg = QXTIConfig.from_file("inputs/inputParams.wsm.cfg")
    cfg.kgrid.k_points = (80, 80, 80)
    sim = QXTISimulation(config=cfg)
    ham = sim.build_hamiltonian()
    kg = sim.build_kgrid(ham)
    w = build_k_integration_weights(cfg, hamiltonian=ham, kgrid=kg)
    cc = cfg.susceptibility_solver
    g = 1.0 / cc.coherence_time
    print("  banda 80^3 ...", flush=True)
    band = precompute_band_data(
        ham._matrix_at, np.asarray(kg.points()),
        tuple(int(kg.shape[a]) for a in range(3)), ham.reciprocal_box_bounds(),
        mu=cc.fermi_level, T_au=cc.temperature, dimension=3,
        distribution=_resolve_distribution(cc.distribution),
        h_batch=h_batch_for("wsm_two_weyl", ham))

    configs = [
        (0.0, 0.0, "lineal eps=0, phi=0"),
        (0.5, 90.0, "eps=0.5, phi=90 (doble-pico)"),
        (1.0, 0.0, "circular eps=1, phi=0"),
    ]
    Nw = 3000
    omega_grid = np.linspace(0.0, (MAX_ORDER + 1.0) * OMEGA, Nw)
    sigma = OMEGA / (2.2 * NCYC)                          # spectral width of an ncyc pulse
    safe = lambda s: (s.replace(" ", "_").replace("=", "").replace(",", "")
                      .replace("(", "").replace(")", "").replace(".", "p"))
    overlay = []
    for eps, phi, lab in configs:
        xd, yd = in_plane_dirs(phi)
        E = E0 * (xd + 1j * eps * yd) / np.sqrt(1.0 + eps * eps)
        t0 = time.perf_counter()
        J = harmonic_currents(band, w, E, OMEGA, MAX_ORDER, gamma=g, gamma_pop=g)
        spec = np.zeros((Nw, 3), dtype=np.complex128)     # dressed pulsed spectrum
        for N in range(1, MAX_ORDER + 1):
            line = np.exp(-0.5 * ((omega_grid - N * OMEGA) / sigma) ** 2)
            spec += (np.asarray(J[N][:3]) * wN[N])[None, :] * line[:, None]
        mag = np.sqrt(np.sum(np.abs(spec) ** 2, axis=1))
        overlay.append((lab, mag))
        HG.plot_current_overview_spectrum(
            omega_grid, spec, mag, str(OUT / f"spectrum_{safe(lab)}.png"),
            fundamental_omega=OMEGA, use_harmonic_order=True,
            max_harmonic_order=MAX_ORDER + 0.5, log_scale=True,
            orders=tuple(range(1, MAX_ORDER + 1)))
        print(f"  spectrum '{lab}': {time.perf_counter()-t0:.1f}s -> spectrum_{safe(lab)}.png", flush=True)

    mask = HG._build_frequency_mask(omega_grid, positive_only=True, omega_min=0.0,
                                    omega_max=(MAX_ORDER + 0.5) * OMEGA)
    xv, xl = HG._build_spectral_xaxis(omega_grid[mask], fundamental_omega=OMEGA,
                                      use_harmonic_order=True)
    cols = ["#111827", "#ee3b2d", "#3aae3a"]
    HG._plot_multi_series_spectrum(
        x_values=xv, xlabel=xl,
        series=[(lab, mag[mask], cols[i]) for i, (lab, mag) in enumerate(overlay)],
        output_path=str(OUT / "spectrum_overlay.png"),
        title=f"HHG pulsed spectra (freq solver, {NCYC}-cycle pulse) - TaAs 4um 1e11 W/cm2",
        ylabel=r"$|J(\omega)|$  (a.u.)", use_harmonic_order=True,
        max_harmonic_order=MAX_ORDER + 0.5, log_scale=True,
        top_energy_scale_ev=OMEGA * 27.211386, panel_tag="Total magnitude",
        context_note=f"orders 1-{MAX_ORDER}, [001] c-axis")
    print("  overlay -> spectrum_overlay.png", flush=True)


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    wN = pulse_weights(MAX_ORDER, NCYC)
    print(f"pesos de pulso ({NCYC} ciclos, sin^2): "
          + ", ".join(f"w{N}={wN[N]:.3e}" for N in range(1, 8)), flush=True)
    with open(OUT / "README.txt", "w") as f:
        f.write("HHG TaAs 2-band tetragonal - LASER PULSADO NORMAL via SOLVER EN FRECUENCIA\n")
        f.write("maps HO 4-7 (eps x orientacion) + espectros ejemplo estilo graphics.py\n")
        f.write(f"solver: harmonic_currents (CW, exacto) dressed como pulso de {NCYC} ciclos sin^2\n")
        f.write("pulsed_J^(N) = CW_J^(N) x (sum env^N) x 2^-N  (factor cinematico analitico)\n")
        f.write(f"omega={OMEGA} (4um), E0={E0} (1e11 W/cm2), [001] c-axis\n")
        f.write("convencion: PARES(4,6)=analizador co-rot cruzado 90; IMPARES(5,7)=fijo 0 + eps invert\n")
        f.write("time-domain SOLO para laser systems (varios laseres, distinta frecuencia)\n")
    print("== MAPAS HO 4-7 (pulsado via frecuencia) ==", flush=True)
    build_maps(wN)
    print("== ESPECTROS EJEMPLO (estilo graphics.py) ==", flush=True)
    build_spectra(wN)
    print("LISTO ->", OUT, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
