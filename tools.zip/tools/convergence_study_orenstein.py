#!/usr/bin/env python3
"""Exhaustive convergence study of the Orenstein Weyl model optical observables.

Goal: determine, to publication standard, which chi^(2) observables converge and
under what conditions (k-grid density, broadening gamma, photon frequency).

Studies:
  A. k-grid convergence at the paper's low frequency (near Weyl nodes) — hardest.
  B. k-grid convergence at higher frequency (away from nodes) — should be easier.
  C. gamma (broadening) sweep at fixed dense grid.
  D. frequency sweep at fixed dense grid.

Observables tracked (all at 2*omega):
  chi_zzz  (diagonal, dominant, polar z)     -- expect robust
  chi_zxx, chi_zyy (off-diagonal)            -- suspect
  chi_xzx  (= 2 d15, carries CD)             -- suspect
  ratio |chi_zzz|/|chi_xzx|                  -- paper: ~6-30
  CD amplitudes A_sin, A_cos, DC             -- the SHG-CD structure

Saves a full npz and prints convergence tables with relative-change columns.
"""
from __future__ import annotations
import os, sys, time
from pathlib import Path
import numpy as np

os.environ.setdefault("MPLCONFIGDIR", "/private/tmp")
os.environ.setdefault("XDG_CACHE_HOME", "/private/tmp")
PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from qxti.core import QXTIConfig, QXTISimulation
from qxti.analytics.theory_response import order2_tensor_at_omega, build_k_integration_weights

AU_TO_EV = 27.211386245988
E1 = np.array([1., 1.,-1.])/np.sqrt(3.)
E2 = np.array([1.,-1., 0.])/np.sqrt(2.)
CFG_PATH = 'inputs/inputParams.wsm_orenstein.cfg'
OUT = PROJECT_ROOT / 'outputs/convergence_orenstein'
OUT.mkdir(parents=True, exist_ok=True)


def cd_components(sigma2):
    """Return DC, A_sin, A_cos of the SHG circular dichroism CD(theta2)."""
    E_plus  = 0.5*(E1 + 1j*E2)
    E_minus = 0.5*(E1 - 1j*E2)
    J_p = np.einsum('ijk,j,k->i', sigma2, E_plus, E_plus)
    J_m = np.einsum('ijk,j,k->i', sigma2, E_minus, E_minus)
    theta = np.linspace(0, 2*np.pi, 3600)
    ct, st = np.cos(theta), np.sin(theta)
    Ip = np.abs(ct*np.dot(E1,J_p) + st*np.dot(E2,J_p))**2
    Im = np.abs(ct*np.dot(E1,J_m) + st*np.dot(E2,J_m))**2
    cd = Ip - Im
    return np.mean(cd), 2*np.mean(cd*np.sin(2*theta)), 2*np.mean(cd*np.cos(2*theta))


def compute(nk, omega_au, gamma_ct=None, guard=True):
    """Compute all observables for one (nk, omega, gamma) point."""
    cfg = QXTIConfig.from_file(CFG_PATH)
    cfg.kgrid.k_points = [nk, nk, nk]
    cfg.kgrid.auto_degeneracy_guard = bool(guard)
    cfg.kgrid.shifted = True
    if gamma_ct is not None:
        cfg.cmd.coherence_time = float(gamma_ct)
    sim = QXTISimulation(config=cfg)
    H   = sim.build_hamiltonian()
    kg  = sim.build_kgrid(H)
    w   = build_k_integration_weights(cfg, hamiltonian=H, kgrid=kg)
    s2  = order2_tensor_at_omega(H, kg, omega_au, w, cfg.cmd)
    chi2 = s2 / (-1j*2*omega_au)
    dc, a_s, a_c = cd_components(s2)
    return {
        'nk_eff': int(kg.total_points ** (1/3) + 0.5),
        'chi_zzz': chi2[2,2,2], 'chi_zxx': chi2[2,0,0],
        'chi_zyy': chi2[2,1,1], 'chi_xzx': chi2[0,2,0],
        'dc': dc, 'a_sin': a_s, 'a_cos': a_c,
    }


def _fmt_row(label, prev, cur, keys):
    parts = [f"{label:>10}"]
    for k in keys:
        v = abs(cur[k])
        if prev is not None and abs(prev[k]) > 1e-30:
            rel = abs(v - abs(prev[k])) / abs(prev[k]) * 100
            parts.append(f"{v:>11.3e}({rel:4.0f}%)")
        else:
            parts.append(f"{v:>11.3e}(  -- )")
    return "  ".join(parts)


def study_kgrid(omega_eV, grids, guard, tag):
    omega_au = omega_eV / AU_TO_EV
    print(f"\n{'='*95}")
    print(f"STUDY {tag}: k-grid convergence @ {omega_eV:.3f} eV  (guard={guard})")
    print(f"{'='*95}")
    keys = ['chi_zzz', 'chi_zxx', 'chi_zyy', 'chi_xzx']
    hdr = f"{'grid':>10}  " + "  ".join(f"{'|'+k.split('_')[1]+'|':>17}" for k in keys)
    print(hdr)
    rows = []
    prev = None
    for nk in grids:
        t0 = time.perf_counter()
        r = compute(nk, omega_au, guard=guard)
        dt = time.perf_counter() - t0
        print(_fmt_row(f"{r['nk_eff']}^3", prev, r, keys) + f"   [{dt:.0f}s]", flush=True)
        r['nk_req'] = nk
        rows.append(r)
        prev = r
    # CD components separately
    print(f"\n  CD structure (should stabilize if physical):")
    print(f"  {'grid':>10} {'DC':>13} {'A_sin':>13} {'A_cos':>13} {'|zzz|/|xzx|':>12}")
    for r in rows:
        ratio = abs(r['chi_zzz'])/max(abs(r['chi_xzx']),1e-30)
        print(f"  {r['nk_eff']:>7}^3 {r['dc']:>13.3e} {r['a_sin']:>13.3e} "
              f"{r['a_cos']:>13.3e} {ratio:>12.2f}")
    return rows


def study_gamma(omega_eV, nk, cts, tag):
    omega_au = omega_eV / AU_TO_EV
    print(f"\n{'='*95}")
    print(f"STUDY {tag}: gamma (broadening) sweep @ {omega_eV:.3f} eV, grid {nk}^3")
    print(f"{'='*95}")
    print(f"  {'gamma(meV)':>11} {'|chi_zzz|':>13} {'|chi_zxx|':>13} {'|chi_zyy|':>13} "
          f"{'|chi_xzx|':>13} {'zxx/zyy diff':>12}")
    rows = []
    for ct in cts:
        gamma_meV = AU_TO_EV/ct*1000 if ct < 1e11 else 0.0
        r = compute(nk, omega_au, gamma_ct=ct, guard=True)
        zdiff = abs(r['chi_zxx']-r['chi_zyy'])/max(abs(r['chi_zxx']),1e-30)*100
        print(f"  {gamma_meV:>11.1f} {abs(r['chi_zzz']):>13.3e} {abs(r['chi_zxx']):>13.3e} "
              f"{abs(r['chi_zyy']):>13.3e} {abs(r['chi_xzx']):>13.3e} {zdiff:>11.0f}%", flush=True)
        r['gamma_meV'] = gamma_meV; r['ct'] = ct
        rows.append(r)
    return rows


def study_frequency(nk, omegas_eV, tag):
    print(f"\n{'='*95}")
    print(f"STUDY {tag}: frequency dependence @ grid {nk}^3")
    print(f"{'='*95}")
    print(f"  {'w(eV)':>8} {'|chi_zzz|':>13} {'|chi_xzx|':>13} {'|zzz|/|xzx|':>12} "
          f"{'DC/A_sin':>10}")
    rows = []
    for oe in omegas_eV:
        r = compute(nk, oe/AU_TO_EV, guard=True)
        ratio = abs(r['chi_zzz'])/max(abs(r['chi_xzx']),1e-30)
        dcr = r['dc']/r['a_sin'] if abs(r['a_sin'])>1e-30 else 0
        print(f"  {oe:>8.3f} {abs(r['chi_zzz']):>13.3e} {abs(r['chi_xzx']):>13.3e} "
              f"{ratio:>12.2f} {dcr:>10.3f}", flush=True)
        r['omega_eV'] = oe
        rows.append(r)
    return rows


def main():
    t_start = time.perf_counter()
    all_results = {}

    # ── STUDY A: k-grid @ low freq (paper regime, near nodes) ─────────────────
    all_results['A_lowfreq_guard'] = study_kgrid(
        0.272, [40, 50, 60, 70, 80, 100, 120], guard=True, tag='A')

    # ── STUDY B: k-grid @ high freq (away from nodes) ─────────────────────────
    all_results['B_highfreq_guard'] = study_kgrid(
        0.900, [40, 50, 60, 70, 80, 100], guard=True, tag='B')

    # ── STUDY C: gamma sweep @ dense grid ─────────────────────────────────────
    all_results['C_gamma'] = study_gamma(
        0.272, 80, [55, 110, 220, 440, 880], tag='C')

    # ── STUDY D: frequency sweep @ dense grid ─────────────────────────────────
    all_results['D_frequency'] = study_frequency(
        80, [0.15, 0.30, 0.50, 0.70, 0.90, 1.20, 1.55], tag='D')

    # ── save ──────────────────────────────────────────────────────────────────
    flat = {}
    for study, rows in all_results.items():
        for i, r in enumerate(rows):
            for k, v in r.items():
                flat[f"{study}_{i}_{k}"] = v
    np.savez_compressed(OUT / 'convergence_results.npz', **flat)

    print(f"\n{'='*95}")
    print(f"DONE in {(time.perf_counter()-t_start)/60:.1f} min. Saved {OUT/'convergence_results.npz'}")
    print(f"{'='*95}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
