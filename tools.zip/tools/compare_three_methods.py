"""Three-way comparison: per-k  vs  mesh (frequency)  vs  time-domain.

Extends the mesh-vs-per-k study to the new (optimized) time-domain multi-frequency
engine, so all THREE perturbative paths are compared on the same footing:

  * per-k       — the old recursion ``rho_analytic.rho_order_s`` (per k-point,
                  ~7^(s-1) diagonalizations/k): the slow reference.
  * mesh        — ``harmonic_currents``: the vectorized closed form in frequency,
                  single-carrier ω, the PRODUCTION path for 1 laser.  Fastest.
  * time-domain — ``time_domain_currents``: integrates the same recursion in time
                  with the full E(t); the ONLY path that handles >1 laser.  Costs
                  Nt time steps, so it sits between mesh and per-k.

In the single-carrier (CW) limit all three must give the SAME harmonic |J^(s)(sω0)|
(they are the same physics); the study checks that (should overlap / agree to
~machine precision) and times each vs the k-grid so the speed trade-off is explicit.

    python tools/compare_three_methods.py --config inputs/inputParams.wsm.cfg
"""
from __future__ import annotations

import argparse
import time
from pathlib import Path
import sys

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from qxti.core.config import QXTIConfig
from qxti.core.simulation import QXTISimulation
from qxti.analytics.theory_response import _resolve_distribution
from qxti.analytics.mesh_response import (
    precompute_band_data, harmonic_currents, perk_harmonic_currents,
    time_domain_currents, uniform_mp_grid,
)


def _drive(drive, amp):
    axis = {"x": 0, "y": 1, "z": 2}[drive]
    E = np.zeros(3, dtype=np.complex128)
    E[axis] = amp
    return E, axis


def run_study(cfg_path, perk_grids, mesh_grids, time_grids, max_order, drive, amp, P, Q):
    cfg = QXTIConfig.from_file(cfg_path)
    sim = QXTISimulation(config=cfg)
    ham = sim.build_hamiltonian()
    H_func = ham._matrix_at
    bounds = ham.reciprocal_box_bounds()
    dim = int(ham.dimension)
    ccfg = cfg.susceptibility_solver
    mu, T_au = float(ccfg.fermi_level), float(ccfg.temperature)
    gamma = 0.0 if ccfg.coherence_time <= 0 else 1.0 / float(ccfg.coherence_time)
    dist = _resolve_distribution(ccfg.distribution)
    w0 = float(cfg.laser.omega)
    E_cw, axis = _drive(drive, amp)

    # CW field for the time-domain path: w0 lands on an FFT bin (P periods, Q/period).
    Nt = P * Q
    dt = (2 * np.pi / w0) / Q
    tt = np.arange(Nt) * dt
    E_t = np.zeros((Nt, 3))
    E_t[:, axis] = 2 * amp * np.cos(w0 * tt)          # = E_cw e^{-iw0 t} + c.c.
    orders = list(range(1, max_order + 1))

    print(f"# {cfg_path}  dist={ccfg.distribution}  w0={w0}  drive={drive}  "
          f"max_order={max_order}  (time-domain Nt={Nt})\n")
    res = {"perk": {}, "mesh": {}, "time": {}}

    def _grid(N):
        shape = tuple((N, N, N)[:3])
        kpts, wq = uniform_mp_grid(bounds, shape)
        return kpts, wq, shape

    print("== mesh (frequency, closed form) ==")
    for N in mesh_grids:
        kpts, wq, shape = _grid(N)
        t0 = time.perf_counter()
        band = precompute_band_data(H_func, kpts, shape, bounds, mu=mu, T_au=T_au,
                                    dimension=dim, distribution=dist)
        J = harmonic_currents(band, wq, E_cw, w0, max_order, gamma=gamma, gamma_pop=gamma)
        dtm = time.perf_counter() - t0
        res["mesh"][N] = {"t": dtm, "J": {s: np.abs(J[s]) for s in orders}}
        print(f"  N={N:>3} Nk={N**dim:>6} t={dtm:.3f}s")

    print("== time-domain (optimized) ==")
    for N in time_grids:
        kpts, wq, shape = _grid(N)
        t0 = time.perf_counter()
        band = precompute_band_data(H_func, kpts, shape, bounds, mu=mu, T_au=T_au,
                                    dimension=dim, distribution=dist)
        td = time_domain_currents(band, wq, E_t, dt, max_order, gamma=gamma, gamma_pop=gamma)
        dtt = time.perf_counter() - t0
        freq = td["freq"]
        Jmag = {}
        for s in orders:
            b = np.argmin(np.abs(freq + s * w0))            # +s*w0 harmonic bin
            Jmag[s] = np.abs(td["J_omega"][s][b, :dim]) / Nt
        res["time"][N] = {"t": dtt, "J": Jmag}
        print(f"  N={N:>3} Nk={N**dim:>6} t={dtt:.3f}s")

    print("== per-k (rho_order_s, slow reference) ==")
    for N in perk_grids:
        kpts, wq, shape = _grid(N)
        dk_grad = (float(bounds[0][1]) - float(bounds[0][0])) / N
        t0 = time.perf_counter()
        J = perk_harmonic_currents(H_func, kpts, wq, E_cw, w0, max_order, gamma=gamma,
                                   mu=mu, T_au=T_au, dimension=dim, dk_grad=dk_grad,
                                   distribution=dist)
        dtp = time.perf_counter() - t0
        res["perk"][N] = {"t": dtp, "J": {s: np.abs(J[s]) for s in orders}}
        print(f"  N={N:>3} Nk={N**dim:>6} t={dtp:.3f}s")

    # agreement of the three (magnitude of |J^(s)|) where all overlap
    print("\n== agreement |J^(s)| (mesh as reference) & speedups vs per-k ==")
    for N in sorted(set(perk_grids) & set(mesh_grids) & set(time_grids)):
        Jm, Jp, Jt = res["mesh"][N]["J"], res["perk"][N]["J"], res["time"][N]["J"]
        e_perk = [np.linalg.norm(Jp[s] - Jm[s]) / max(np.linalg.norm(Jm[s]), 1e-300) for s in orders]
        e_time = [np.linalg.norm(Jt[s] - Jm[s]) / max(np.linalg.norm(Jm[s]), 1e-300) for s in orders]
        sp_mesh = res["perk"][N]["t"] / max(res["mesh"][N]["t"], 1e-12)
        sp_time = res["perk"][N]["t"] / max(res["time"][N]["t"], 1e-12)
        print(f"  N={N}: err(perk)={['%.0e'%e for e in e_perk]} err(time)={['%.0e'%e for e in e_time]}"
              f"  | mesh {sp_mesh:.0f}x, time {sp_time:.0f}x faster than per-k")
    return res, orders, dim, ccfg.distribution


def make_figure(res, orders, dim, dist_name, out_path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    C = {"perk": "C3", "mesh": "C0", "time": "C2"}
    M = {"perk": "x", "mesh": "-o", "time": "-^"}
    L = {"perk": "per-k (old)", "mesh": "mesh (freq)", "time": "time-domain (new)"}
    nk = lambda meth: [n ** dim for n in sorted(res[meth])]

    fig, ax = plt.subplots(2, 3, figsize=(16, 9))
    fig.suptitle(f"per-k vs mesh vs time-domain  (distribution = {dist_name})",
                 fontsize=13, fontweight="bold")

    # Row 1: |J^(s)| vs Nk for s=1,2,3 (three methods overlapping = same physics)
    for j, s in enumerate(orders[:3]):
        a = ax[0, j]
        for meth in ("mesh", "time", "perk"):
            xs = nk(meth)
            ys = [np.linalg.norm(res[meth][n]["J"][s]) for n in sorted(res[meth])]
            if meth == "perk":
                a.plot(xs, ys, "x", color=C[meth], ms=10, mew=2.5, label=L[meth], zorder=4)
            else:
                a.plot(xs, ys, M[meth], color=C[meth], label=L[meth],
                       ms=6, alpha=0.9, zorder=2 if meth == "mesh" else 3)
        a.set_xscale("log")
        a.set_title(f"observable |J$^{{({s})}}$| vs $N_k$"); a.set_xlabel("$N_k$")
        a.set_ylabel(f"|J$^{{({s})}}$|"); a.grid(True, which="both", alpha=0.3)
        a.legend(fontsize=8)

    # Row 2, col 0: runtime vs Nk (three curves)
    a = ax[1, 0]
    for meth in ("perk", "time", "mesh"):
        a.plot(nk(meth), [res[meth][n]["t"] for n in sorted(res[meth])],
               M[meth].replace("-", "-"), color=C[meth], label=L[meth])
    a.set_xscale("log"); a.set_yscale("log")
    a.set_title("runtime vs $N_k$"); a.set_xlabel("$N_k$"); a.set_ylabel("time (s)")
    a.grid(True, which="both", alpha=0.3); a.legend(fontsize=9)

    # Row 2, col 1: speedup vs per-k
    a = ax[1, 1]
    common = sorted(set(res["perk"]) & set(res["mesh"]) & set(res["time"]))
    xs = [n ** dim for n in common]
    a.plot(xs, [res["perk"][n]["t"] / max(res["mesh"][n]["t"], 1e-12) for n in common],
           "-o", color=C["mesh"], label="mesh / per-k")
    a.plot(xs, [res["perk"][n]["t"] / max(res["time"][n]["t"], 1e-12) for n in common],
           "-^", color=C["time"], label="time-domain / per-k")
    a.set_xscale("log"); a.set_yscale("log")
    a.set_title("speedup vs per-k"); a.set_xlabel("$N_k$"); a.set_ylabel("x faster")
    a.grid(True, which="both", alpha=0.3); a.legend(fontsize=9)

    # Row 2, col 2: agreement (rel error vs mesh)
    a = ax[1, 2]
    for meth in ("perk", "time"):
        cc = sorted(set(res[meth]) & set(res["mesh"]))
        for s in orders[:3]:
            errs = [np.linalg.norm(res[meth][n]["J"][s] - res["mesh"][n]["J"][s])
                    / max(np.linalg.norm(res["mesh"][n]["J"][s]), 1e-300) for n in cc]
            a.plot([n ** dim for n in cc], errs,
                   ("x" if meth == "perk" else "-^"), color=C[meth],
                   label=f"{L[meth]} o{s}" if s == 1 else None, alpha=0.7)
    a.set_xscale("log"); a.set_yscale("log")
    a.axhline(1e-12, color="gray", ls="--", lw=1)
    a.set_title("rel. error of |J$^{(s)}$| vs mesh"); a.set_xlabel("$N_k$")
    a.set_ylabel("relative error"); a.grid(True, which="both", alpha=0.3)
    a.legend(fontsize=8)

    fig.tight_layout(rect=[0, 0, 1, 0.96])
    fig.savefig(out_path, dpi=140)
    print(f"\n[figura guardada] {out_path}")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--config", default="inputs/inputParams.wsm.cfg")
    p.add_argument("--perk-grids", type=int, nargs="+", default=[4, 6, 8, 10, 12])
    p.add_argument("--mesh-grids", type=int, nargs="+", default=[4, 6, 8, 10, 12, 16, 20, 24, 32])
    p.add_argument("--time-grids", type=int, nargs="+", default=[4, 6, 8, 10, 12, 16, 20])
    p.add_argument("--max-order", type=int, default=3)
    p.add_argument("--drive", choices=["x", "y", "z"], default="z")
    p.add_argument("--amp", type=float, default=1.0e-3)
    p.add_argument("--periods", type=int, default=8)
    p.add_argument("--samples-per-period", type=int, default=32)
    p.add_argument("--out", default="outputs/compare_three_methods.png")
    args = p.parse_args()

    res, orders, dim, dist = run_study(
        args.config, args.perk_grids, args.mesh_grids, args.time_grids,
        args.max_order, args.drive, args.amp, args.periods, args.samples_per_period)
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    make_figure(res, orders, dim, dist, args.out)


if __name__ == "__main__":
    main()
