#!/usr/bin/env python3
"""Mapa k-resuelto del integrando local de sigma^(1)_aa para a = x, y, z.

Genera una figura 3x2 (3 componentes diagonales × Re/Im) del integrando

    I^(1)_aa(k, omega) = Tr[ v_a(k) rho^(1)_a(k, omega) ]

donde sigma^(1)_aa(omega) = integral_BZ I^(1)_aa dk.

Uso:
    python tools/plot_bz_sigma1_contribution.py \
        --config inputs/inputParams.wsm_orenstein.cfg \
        --omega-ev 0.8 --plane kz --fixed 0.0
"""
from __future__ import annotations

import argparse
import importlib.util
import os
from pathlib import Path
import sys
import time
from typing import Any

import numpy as np
from numpy.typing import NDArray

os.environ.setdefault("MPLCONFIGDIR", "/private/tmp")
os.environ.setdefault("XDG_CACHE_HOME", "/private/tmp")

import matplotlib
matplotlib.use("Agg")
from matplotlib import pyplot as plt
from matplotlib.colors import TwoSlopeNorm

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from qxti.analytics.theory_response import _resolve_distribution
from qxti.core import QXTIConfig
from qxti.core.simulation import QXTISimulation
from qxti.graphics.custom_cmap import custom_cmap_div
from qxti.graphics.plot_susceptibility_tensor import apply_paper_style

AU_TO_EV = 27.211386245988
BOHR_INV_TO_ANGSTROM_INV = 1.8897259886
DEFAULT_OUTPUT_DIR = Path("outputs") / "bz_chi_contribution"
LABELS = ("x", "y", "z")

ComplexArray = NDArray[np.complex128]
FloatArray = NDArray[np.float64]


def _batched_hamiltonian(Hf, k_points: FloatArray) -> ComplexArray:
    return np.array([Hf(float(k[0]), float(k[1]), float(k[2])) for k in k_points],
                    dtype=np.complex128)


def _compute_data(Hf, k_points, velocity_step, distribution, mu, temperature):
    h0 = _batched_hamiltonian(Hf, k_points)
    energies, U = np.linalg.eigh(h0)
    Udag = np.conj(np.transpose(U, (0, 2, 1)))
    vel = {}
    for axis in range(3):
        shift = np.zeros(3); shift[axis] = velocity_step
        dH = (_batched_hamiltonian(Hf, k_points + shift)
              - _batched_hamiltonian(Hf, k_points - shift)) / (2.0 * velocity_step)
        vel[axis] = Udag @ dH @ U
    occ = np.asarray(distribution(energies, mu, temperature), dtype=np.float64)
    eps = energies[:, :, None] - energies[:, None, :]
    fmn = occ[:, None, :] - occ[:, :, None]
    nb = int(energies.shape[1])
    valid = (~np.eye(nb, dtype=bool))[None] & (np.abs(eps) > 1e-20)
    with np.errstate(divide="ignore", invalid="ignore"):
        inv_eps = np.where(valid, 1.0 / eps, 0.0)
    dfde = (-occ * (1.0 - occ) / temperature if temperature > 1e-15
            else np.zeros_like(occ))
    return {"vel": vel, "fmn": fmn, "eps": eps, "valid": valid,
            "inv_eps": inv_eps, "dfde": dfde, "nb": nb}


def _rho1(data, axis, omega_c):
    nb = data["nb"]
    vel = np.asarray(data["vel"][axis], dtype=np.complex128)
    inv_eps = np.asarray(data["inv_eps"], dtype=np.complex128)
    fmn = np.asarray(data["fmn"], dtype=np.float64)
    eps = np.asarray(data["eps"], dtype=np.float64)
    valid = np.asarray(data["valid"], dtype=bool)
    dfde = np.asarray(data["dfde"], dtype=np.float64)
    A = 1j * vel * inv_eps
    with np.errstate(divide="ignore", invalid="ignore"):
        rho = np.where(valid, (A * fmn) / (omega_c - eps), 0j)
    diag_src = (-1j) * dfde * np.real(np.diagonal(vel, axis1=1, axis2=2))
    rho[:, np.arange(nb), np.arange(nb)] += diag_src / omega_c
    return np.asarray(rho, dtype=np.complex128)


def _sigma1_integrand(data, axis, omega_c):
    """Tr[ v_a rho^(1)_a ] — local integrand of sigma^(1)_aa."""
    vel_a = np.asarray(data["vel"][axis], dtype=np.complex128)   # (Nk, nb, nb)
    rho = _rho1(data, axis, omega_c)                              # (Nk, nb, nb)
    # Tr[A B] = sum_mn A_mn B_nm
    return np.einsum("kmn,knm->k", vel_a, rho)                   # (Nk,) complex


def _pi_ticks(ax, axis_values, which="x"):
    import math
    lo, hi = float(axis_values[0]), float(axis_values[-1])
    step = np.pi / 2.0
    first = math.ceil((lo - 1e-9) / step) * step
    ticks = np.arange(first, hi + step * 0.5, step)
    ticks = ticks[(ticks >= lo - 1e-9) & (ticks <= hi + 1e-9)]
    _tex = {0.0: r"$0$", np.pi/2: r"$\pi/2$", np.pi: r"$\pi$",
            3*np.pi/2: r"$3\pi/2$", 2*np.pi: r"$2\pi$",
            -np.pi/2: r"$-\pi/2$", -np.pi: r"$-\pi$"}
    labels = [next((v for k2, v in _tex.items() if abs(t - k2) < 1e-9),
                   rf"${t/np.pi:.2g}\pi$") for t in ticks]
    if which == "x":
        ax.set_xticks(ticks); ax.set_xticklabels(labels, fontsize=17)
    else:
        ax.set_yticks(ticks); ax.set_yticklabels(labels, fontsize=17)


def _overlay_weyl_nodes(ax, module, params, plane_axis, fixed, unit_scale,
                         k_offset=0.0):
    if not hasattr(module, "weyl_nodes_with_chirality"):
        return
    col = {+1: "#E8000B", -1: "#1E64C8"}
    mrk = {+1: "+", -1: "-"}
    seen: set = set()
    try:
        nodes = module.weyl_nodes_with_chirality(params)
        plane_axes = [i for i in range(3) if i != plane_axis]
        for nd in nodes:
            k = nd["k"]; c = int(nd["chirality"])
            if abs(k[plane_axis] - fixed) > 0.35:
                continue
            kx_p = k[plane_axes[0]] * unit_scale + k_offset
            ky_p = k[plane_axes[1]] * unit_scale + k_offset
            lab = rf"Weyl $\chi={c:+d}$" if c not in seen else None
            seen.add(c)
            pass
    except Exception:
        pass


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Mapa k-resuelto del integrando sigma^(1)_aa (xx, yy, zz).")
    parser.add_argument("--config", default="inputs/inputParams.wsm_orenstein.cfg")
    parser.add_argument("--omega-ev", type=float, default=0.8)
    parser.add_argument("--plane", choices=("kx", "ky", "kz"), default="kz")
    parser.add_argument("--fixed", type=float, default=0.0)
    parser.add_argument("--points", type=int, default=180)
    parser.add_argument("--gamma-ev", type=float, default=0.05)
    parser.add_argument("--units", choices=("angstrom", "bohr"), default="angstrom")
    parser.add_argument("--output-dir", default=str(DEFAULT_OUTPUT_DIR))
    parser.add_argument("--dpi", type=int, default=220)
    parser.add_argument("--component", default=None,
                        help="Single component to plot: x, y, or z. Default: all three.")
    args = parser.parse_args()

    cfg = QXTIConfig.from_file(args.config)
    sim = QXTISimulation(config=cfg)
    ham = sim.build_hamiltonian()
    Hf = ham._matrix_at
    dim = int(ham.dimension)

    source = Path(str(cfg.hamiltonian.source_file))
    model_path = source if source.is_absolute() else PROJECT_ROOT / "models" / source
    spec = importlib.util.spec_from_file_location(f"model_{model_path.stem}", model_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    params = module.default_params() if hasattr(module, "default_params") else {}

    omega = float(args.omega_ev) / AU_TO_EV
    gamma = float(args.gamma_ev) / AU_TO_EV
    omega_c = complex(omega, gamma)

    distribution = _resolve_distribution(cfg.susceptibility_solver.distribution)
    mu = float(getattr(cfg.susceptibility_solver, "mu", 0.0))
    temperature = float(getattr(cfg.susceptibility_solver, "temperature", 1e-4))
    velocity_step = 1e-4

    # Build 2D k-grid on the slice
    plane_axis = {"kx": 0, "ky": 1, "kz": 2}[args.plane]
    plane_axes = [i for i in range(3) if i != plane_axis]
    kgrid_cfg = cfg.kgrid
    bounds_au = np.pi / float(getattr(kgrid_cfg, "lattice_constant", 1.0)) if hasattr(kgrid_cfg, "lattice_constant") else np.pi
    N = int(args.points)
    ax1 = np.linspace(-bounds_au, bounds_au, N)
    ax2 = np.linspace(-bounds_au, bounds_au, N)
    G1, G2 = np.meshgrid(ax1, ax2, indexing="ij")
    k_flat = np.zeros((N * N, 3), dtype=np.float64)
    k_flat[:, plane_axes[0]] = G1.ravel()
    k_flat[:, plane_axes[1]] = G2.ravel()
    k_flat[:, plane_axis] = float(args.fixed)

    a_lat = float(params.get("a", 1.0))
    unit_scale = a_lat        # k·a, BZ [-π, π] → display [0, 2π]
    k_offset = np.pi          # shift: nodes appear near π/2, 3π/2
    unit_label = r""

    t0 = time.perf_counter()
    print(f"[sigma1-bz] computing {N}x{N} grid, omega={args.omega_ev:.3f} eV, "
          f"{args.plane}={args.fixed:g}")
    data = _compute_data(Hf, k_flat, velocity_step, distribution, mu, temperature)

    # Compute integrand for each diagonal component
    maps = {}
    for axis in range(dim):
        integrand = _sigma1_integrand(data, axis, omega_c)
        maps[axis] = integrand.reshape(N, N)

    elapsed = time.perf_counter() - t0
    print(f"[sigma1-bz] done in {elapsed:.1f}s")

    # --- Select which components to plot ---
    comp_map = {"x": 0, "y": 1, "z": 2}
    if args.component is not None and args.component.lower() in comp_map:
        axes_to_plot = [comp_map[args.component.lower()]]
    else:
        axes_to_plot = list(range(min(dim, 3)))

    # --- Plot ---
    apply_paper_style()
    nrows = len(axes_to_plot)
    fig, axes = plt.subplots(nrows, 2, figsize=(14.0, 5.4 * nrows))
    if nrows == 1:
        axes = axes[None, :]

    x_plot = ax1 * unit_scale + k_offset
    y_plot = ax2 * unit_scale + k_offset
    x_grid, y_grid = np.meshgrid(x_plot, y_plot, indexing="ij")

    parts = [("real", r"\mathrm{Re}"), ("imag", r"\mathrm{Im}")]
    for row, axis in enumerate(axes_to_plot):
        label = LABELS[axis]
        chi_map = maps[axis]
        for col, (part_key, part_tex) in enumerate(parts):
            ax = axes[row, col]
            values = np.real(chi_map) if part_key == "real" else np.imag(chi_map)
            vmax = float(np.nanmax(np.abs(values))) if values.size else 1.0
            norm = (TwoSlopeNorm(vmin=-vmax, vcenter=0.0, vmax=vmax)
                    if np.isfinite(vmax) and vmax > 0.0 else None)
            im = ax.pcolormesh(x_grid, y_grid, values, shading="auto",
                               cmap=custom_cmap_div, norm=norm)
            _overlay_weyl_nodes(ax, module, params, plane_axis,
                                float(args.fixed), unit_scale, k_offset=k_offset)
            ax.set_xlabel(rf"$k_{LABELS[plane_axes[0]]}\,a$", fontsize=20)
            ax.set_ylabel(rf"$k_{LABELS[plane_axes[1]]}\,a$", fontsize=20)
            _pi_ticks(ax, x_plot, "x")
            _pi_ticks(ax, y_plot, "y")
            ax.tick_params(axis="both", which="major", labelsize=17)
            cbar_label = (rf"${part_tex}\,\mathcal{{I}}^{{(1)}}_{{{label}{label}}}"
                          rf"(\mathbf{{k}})$")
            cb = fig.colorbar(im, ax=ax, pad=0.02)
            cb.set_label(cbar_label, fontsize=18)
            cb.ax.tick_params(labelsize=15)
            handles, lbls = ax.get_legend_handles_labels()
            if handles:
                dedup: dict = {}
                for h, l in zip(handles, lbls):
                    dedup.setdefault(l, h)
                ax.legend(dedup.values(), dedup.keys(), loc="upper right",
                          frameon=True, fontsize=11)

    fig.tight_layout()
    out_dir = Path(args.output_dir) / "sigma1"
    out_dir.mkdir(parents=True, exist_ok=True)
    fixed_str = f"{args.fixed:g}".replace("-", "m").replace(".", "p")
    comp_tag = f"_{args.component.lower()}" if args.component else ""
    out_path = out_dir / f"sigma1_diag{comp_tag}_{args.plane}_{fixed_str}_both.png"
    fig.savefig(out_path, dpi=int(args.dpi), facecolor="white")
    plt.close(fig)
    print(f"[sigma1-bz] wrote {out_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
