#!/usr/bin/env python3
from __future__ import annotations

"""Paper-style sigma_xz plot split into positive/negative Weyl-node sectors.

The node-sector contribution is reconstructed from the existing mask outputs:

    positive chirality sector = full - no_positive_chirality
    negative chirality sector = full - no_negative_chirality

This is the contribution removed by each local node mask, not a new Hamiltonian.
"""

import argparse
import os
from pathlib import Path
import sys

import numpy as np

os.environ.setdefault("MPLCONFIGDIR", "/private/tmp")
os.environ.setdefault("XDG_CACHE_HOME", "/private/tmp")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import matplotlib

matplotlib.use("Agg")
import matplotlib as mpl
from matplotlib import pyplot as plt

from qxti.graphics.plot_susceptibility_tensor import apply_paper_style


DEFAULT_BASE_DIR = Path("outputs/wsm_orenstein_helicity_node_masks")
SECTOR_COLORS = {
    # User palette:
    # (89,129,158), (124,122,162), (246,126,125), (255,192,167), (108,194,189)
    "positive": {
        "real": "#F67E7D",
        "imag": "#FFC0A7",
    },
    "negative": {
        "real": "#59819E",
        "imag": "#7C7AA2",
    },
}
LABELS = {
    "real": r"$\Re\,\sigma^{(1)}_{xz}$",
    "imag": r"$\Im\,\sigma^{(1)}_{xz}$",
}
OUTPUT_NAMES = {
    "positive": "sigma1_xz_positive_chirality_sector_re_im_paper",
    "negative": "sigma1_xz_negative_chirality_sector_re_im_paper",
}


def _load_case(base_dir: Path, case: str) -> tuple[np.ndarray, np.ndarray]:
    path = base_dir / case / "data" / "sigma_node_mask_case.npz"
    if not path.exists():
        raise FileNotFoundError(f"No existe el dataset requerido: {path}")
    data = np.load(path, allow_pickle=True)
    return (
        np.asarray(data["omega_axis_ev"], dtype=np.float64),
        np.asarray(data["sigma_order_1_tensor"], dtype=np.complex128),
    )


def _load_xz_node_sectors(base_dir: Path) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    omega_ev, full = _load_case(base_dir, "full")
    omega_pos, no_positive = _load_case(base_dir, "no_positive_chirality")
    omega_neg, no_negative = _load_case(base_dir, "no_negative_chirality")
    if not (np.allclose(omega_ev, omega_pos) and np.allclose(omega_ev, omega_neg)):
        raise ValueError("Los ejes de frecuencia de los tres casos no coinciden.")

    x_index, z_index = 0, 2
    sigma_full_xz = full[:, x_index, z_index]
    sigma_no_positive_xz = no_positive[:, x_index, z_index]
    sigma_no_negative_xz = no_negative[:, x_index, z_index]
    positive_sector = sigma_full_xz - sigma_no_positive_xz
    negative_sector = sigma_full_xz - sigma_no_negative_xz
    return omega_ev, positive_sector, negative_sector


def _symmetric_ylim(*arrays: np.ndarray) -> tuple[float, float]:
    span = max(float(np.nanmax(np.abs(values))) for values in arrays)
    if not np.isfinite(span) or span <= 0.0:
        span = 1.0
    return -1.12 * span, 1.12 * span


def _save_square(fig, output_base: Path, *, dpi: int) -> list[Path]:
    output_base.parent.mkdir(parents=True, exist_ok=True)
    outputs = [output_base.with_suffix(".png"), output_base.with_suffix(".svg")]
    with mpl.rc_context({"savefig.bbox": "standard"}):
        fig.savefig(outputs[0], dpi=int(dpi), facecolor="white")
        fig.savefig(outputs[1], facecolor="white")
    return outputs


def plot_sigma_xz_chirality_parts(
    *,
    base_dir: Path,
    output_dir: Path,
    dpi: int,
) -> list[Path]:
    apply_paper_style()
    omega_ev, positive_sector, negative_sector = _load_xz_node_sectors(base_dir)
    sectors = {
        "positive": positive_sector,
        "negative": negative_sector,
    }
    outputs: list[Path] = []

    for sector_name, values in sectors.items():
        real = np.real(values)
        imag = np.imag(values)
        ylo, yhi = _symmetric_ylim(real, imag)
        colors = SECTOR_COLORS[sector_name]

        fig, ax = plt.subplots(figsize=(10.8, 10.8))
        ax.fill_between(omega_ev, 0.0, real, color=colors["real"], alpha=0.20, lw=0, zorder=2)
        ax.plot(omega_ev, real, color=colors["real"], lw=4.4, label=LABELS["real"], zorder=3)
        ax.fill_between(omega_ev, 0.0, imag, color=colors["imag"], alpha=0.23, lw=0, zorder=2)
        ax.plot(omega_ev, imag, color=colors["imag"], lw=4.4, label=LABELS["imag"], zorder=3)

        ax.axhline(0.0, color="#AEB7C2", lw=1.15, zorder=1)
        ax.set_xlim(float(omega_ev[0]), float(omega_ev[-1]))
        ax.set_ylim(ylo, yhi)
        ax.set_box_aspect(1.0)
        ax.set_xlabel(r"$\hbar\omega\;(\mathrm{eV})$", fontsize=48, labelpad=18)
        ax.set_ylabel(r"$\sigma^{(1)}_{xz}$", fontsize=52, labelpad=24)
        ax.tick_params(axis="both", which="major", labelsize=46, length=13, width=1.8)
        ax.tick_params(axis="both", which="minor", length=7, width=1.25)
        ax.ticklabel_format(axis="y", style="sci", scilimits=(-2, 3))
        ax.yaxis.get_offset_text().set_fontsize(38)
        ax.legend(
            frameon=False,
            fontsize=42,
            loc="upper right",
            handlelength=1.8,
            labelspacing=0.48,
        )
        for spine in ax.spines.values():
            spine.set_linewidth(1.8)

        fig.subplots_adjust(left=0.25, right=0.955, bottom=0.19, top=0.955)
        outputs.extend(_save_square(fig, output_dir / OUTPUT_NAMES[sector_name], dpi=dpi))
        plt.close(fig)

    return outputs


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Grafica Re e Im de sigma_xz separando las contribuciones de nodos "
            "Weyl de quiralidad positiva y negativa."
        )
    )
    parser.add_argument("--base-dir", default=str(DEFAULT_BASE_DIR))
    parser.add_argument(
        "--output-dir",
        default=str(DEFAULT_BASE_DIR / "comparison" / "cartesian_transverse"),
    )
    parser.add_argument("--dpi", type=int, default=340)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    outputs = plot_sigma_xz_chirality_parts(
        base_dir=Path(args.base_dir),
        output_dir=Path(args.output_dir),
        dpi=int(args.dpi),
    )
    for path in outputs:
        print(path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
