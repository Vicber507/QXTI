"""Same-physics convergence comparison: linear conductivity sigma^(1)(w0).

Compares QXTI (perturbative) and antelope (non-perturbative) on the ONE observable
where they MUST agree: the linear optical response sigma^(1)(w0).  Unlike the HHG
harmonic ratios (convention-dependent + non-perturbative at H3+), sigma^(1) is
exact to first order in both codes and convention-free (total current / field), so
it is the clean test that both reproduce the SAME physics (bands, velocities,
Berry curvature, dephasing).

Parameter compared:
    sigma_L(w0) = [J_total(w0) . E*(w0)] / |E(w0)|^2   (longitudinal, in the xy plane)
    sigma_H(w0) = [J x E*]_z(w0) / |E(w0)|^2           (transverse / Hall-like)

antelope: J_total(w) = FFT(J_intra) + (-i w) FFT(P_inter);  E from outlaserdata (Ex,Ey).
QXTI:     J_total(w0) = J^(1) from the mesh recursion (order 1), driven by the RCP E.

Usage:
    python tools/compare_sigma1_taas.py <antelope_run_dir> [<dir2> ...]
    (run dirs are outputs/GeneralModel/runs/g16, g24, ... each with a grid label gNN)
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import tools.fast_hhg_mesh_taas as mesh   # noqa: E402

W0 = 0.0114
DT = 0.5


def antelope_sigma1(run_dir: Path):
    intra = np.loadtxt(run_dir / "intraband_current_full_evol.dat")   # (Nt,3)
    inter = np.loadtxt(run_dir / "interband_dipole_full_evol.dat")    # (Nt,3)
    las = np.loadtxt(run_dir / "outlaserdata.dat")                     # (Nt, 1+3+3): t,Ex,Ey,Ez,Ax..
    nt = intra.shape[0]
    w = 2.0 * np.pi * np.fft.fftfreq(nt, d=DT)
    iw0 = int(np.argmin(np.abs(w - W0)))
    win = np.blackman(nt)

    def F(sig):
        return np.fft.fft(win * sig) * DT

    # total current J_total(w) = FFT(J_intra) + (-i w) FFT(P_inter)
    Jx = F(intra[:, 0]) + (-1j * w) * F(inter[:, 0])
    Jy = F(intra[:, 1]) + (-1j * w) * F(inter[:, 1])
    Ex = F(las[:, 1]); Ey = F(las[:, 2])
    J = np.array([Jx[iw0], Jy[iw0]])
    E = np.array([Ex[iw0], Ey[iw0]])
    e2 = np.vdot(E, E).real
    sigma_L = np.vdot(E, J) / e2                       # E*·J / |E|^2
    sigma_H = (J[0] * np.conj(E[1]) - J[1] * np.conj(E[0])) / e2
    return sigma_L, sigma_H


def qxti_sigma1(N: int):
    r = mesh.run_grid(N, num_valence=2)
    J1 = r["J"][1]                                     # linear current at w0 (3-vec)
    Evec = (mesh.E0 / np.sqrt(2.0)) * np.array([1.0, 1j, 0.0], dtype=np.complex128)
    E = Evec[:2]; J = J1[:2]
    e2 = np.vdot(E, E).real
    sigma_L = np.vdot(E, J) / e2
    sigma_H = (J[0] * np.conj(E[1]) - J[1] * np.conj(E[0])) / e2
    return sigma_L, sigma_H


def main():
    dirs = [Path(p) for p in sys.argv[1:]]
    print("SAME-PHYSICS CHECK: linear conductivity sigma^(1)(w0)")
    print("(exact in both perturbative & non-perturbative; convention-free)\n")

    print("QXTI (perturbativo, mesh) — convergencia:")
    print(f"{'grid':>6} {'Re sigma_L':>12} {'Im sigma_L':>12} {'|sigma_L|':>11} {'|sigma_H|':>11}")
    for N in [16, 24, 32, 48, 64]:
        sL, sH = qxti_sigma1(N)
        print(f"{N:>6} {sL.real:>12.4e} {sL.imag:>12.4e} {abs(sL):>11.4e} {abs(sH):>11.4e}")

    if dirs:
        print("\nantelope (no-perturbativo) — convergencia:")
        print(f"{'run':>8} {'Re sigma_L':>12} {'Im sigma_L':>12} {'|sigma_L|':>11} {'|sigma_H|':>11}")
        for d in dirs:
            if not (d / "intraband_current_full_evol.dat").exists() or \
               (d / "intraband_current_full_evol.dat").stat().st_size == 0:
                print(f"{d.name:>8}  (sin datos)")
                continue
            sL, sH = antelope_sigma1(d)
            print(f"{d.name:>8} {sL.real:>12.4e} {sL.imag:>12.4e} {abs(sL):>11.4e} {abs(sH):>11.4e}")

    print("\nSi ambos convergen al MISMO sigma_L(w0) -> reproducen la misma fisica lineal.")
    print("(La escala/fase absoluta puede diferir por convencion de signo de la corriente;")
    print(" lo robusto es que AMBOS converjan y coincidan en magnitud.)")


if __name__ == "__main__":
    main()
