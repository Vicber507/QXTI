#!/usr/bin/env python3
r"""Brute-force HHG ellipticity maps (HO 4-7) — ONE full simulation per (eps, orientation).

NO polynomial / monomial fit: for every (ellipticity, sample-orientation) point this runs
`harmonic_currents` once (the exact mesh-vectorized perturbative recursion) and reads ALL
harmonics 4-7 from that single solve.  This is the canonical, fully-explicit generator that
produced `outputs/hhg_harmonics_4to7/all_data.npz` (which tools/hhg_pulsed_experiment.py then
reuses).  The polynomial fast-path lives in tools/hhg_112_ellipticity_orientation.py instead.

Model: 2-band tetragonal Weyl (wsm_two_weyl, defaults M0=0.014, a2=12), irradiated along the
[001] c-axis.  Analyzer conventions per harmonic parity: EVEN (4,6) = co-rotating cross
analyzer (90 deg); ODD (5,7) = fixed analyzer (0) + ellipticity inverted.

Usage:
    python3 tools/hhg_bruteforce_maps.py                       # 61 x 19 @ 80^3 (full, ~20 min)
    python3 tools/hhg_bruteforce_maps.py --neps 31 --nori 13 --grid 60   # faster/coarser
"""
from __future__ import annotations

import argparse
import os
import sys
import time
from pathlib import Path

import numpy as np

os.environ.setdefault("MPLCONFIGDIR", "/private/tmp")
PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from qxti.core.config import QXTIConfig
from qxti.core.simulation import QXTISimulation
from qxti.analytics.theory_response import build_k_integration_weights, _resolve_distribution
from qxti.analytics.mesh_response import precompute_band_data, harmonic_currents
from tools.hhg_112_ellipticity_orientation import h_batch_for
from tools.replica_paper_4th import plot_paper, OMEGA, E0

HARMS = [4, 5, 6, 7]
E1 = np.array([1.0, 0.0, 0.0])          # [001] c-axis in-plane basis
E2 = np.array([0.0, 1.0, 0.0])


def main() -> int:
    ap = argparse.ArgumentParser(description="Brute-force HHG maps (one sim per eps/orientation).")
    ap.add_argument("--grid", type=int, default=80, help="k-grid (N^3)")
    ap.add_argument("--neps", type=int, default=61, help="ellipticity points in [-1,1]")
    ap.add_argument("--nori", type=int, default=19, help="orientation points in [-90,90] deg")
    ap.add_argument("--order", type=int, default=7, help="max harmonic order for the recursion")
    ap.add_argument("--config", default="inputs/inputParams.wsm.cfg", help="QXTI config (model+params)")
    ap.add_argument("--out", default="outputs/hhg_harmonics_4to7", help="output directory")
    args = ap.parse_args()
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)

    cfg = QXTIConfig.from_file(args.config)
    cfg.kgrid.k_points = (args.grid, args.grid, args.grid)
    sim = QXTISimulation(config=cfg)
    ham = sim.build_hamiltonian()
    print("params:", {k: ham.params[k] for k in ("a2", "M0", "gamma")}, flush=True)
    kg = sim.build_kgrid(ham)
    w = build_k_integration_weights(cfg, hamiltonian=ham, kgrid=kg)
    cc = cfg.susceptibility_solver
    g = 1.0 / cc.coherence_time
    t0 = time.perf_counter(); print(f"banda {args.grid}^3...", flush=True)
    band = precompute_band_data(
        ham._matrix_at, np.asarray(kg.points()),
        tuple(int(kg.shape[a]) for a in range(3)), ham.reciprocal_box_bounds(),
        mu=cc.fermi_level, T_au=cc.temperature, dimension=3,
        distribution=_resolve_distribution(cc.distribution),
        h_batch=h_batch_for("wsm_two_weyl", ham))
    print(f"banda {time.perf_counter()-t0:.0f}s. FUERZA BRUTA: "
          f"{args.neps}x{args.nori}={args.neps*args.nori} corridas orden-{args.order}...", flush=True)

    eps = np.linspace(-1, 1, args.neps)
    oris = np.linspace(-90, 90, args.nori)
    Jall = np.zeros((args.nori, args.neps, len(HARMS), 3), complex)   # raw J^(N) per run
    M = {N: np.zeros((args.nori, args.neps)) for N in HARMS}
    t0 = time.perf_counter()
    for io, ori in enumerate(oris):
        px = np.radians(ori)
        xd = np.cos(px) * E1 + np.sin(px) * E2
        yd = -np.sin(px) * E1 + np.cos(px) * E2
        epol_even = np.cos(px + np.pi / 2) * E1 + np.sin(px + np.pi / 2) * E2   # co-rot cross
        epol_odd = E1                                                          # fixed to crystal
        for ie, ep in enumerate(eps):
            E = E0 * (xd + 1j * ep * yd) / np.sqrt(1.0 + ep * ep)
            J = harmonic_currents(band, w, E, OMEGA, args.order, gamma=g, gamma_pop=g)
            for k, N in enumerate(HARMS):
                Jn = J[N][:3]; Jall[io, ie, k] = Jn
                ep_pol = epol_even if N % 2 == 0 else epol_odd
                M[N][io, ie] = np.abs(Jn @ ep_pol) ** 2
        if io % 3 == 0:
            print(f"  orient {io+1}/{args.nori}  ({time.perf_counter()-t0:.0f}s)", flush=True)
    print(f"fuerza bruta {time.perf_counter()-t0:.0f}s", flush=True)

    for N in HARMS:                              # odd harmonics: invert ellipticity
        if N % 2 == 1:
            M[N] = M[N][:, ::-1]

    np.savez(out / "all_data.npz", eps=eps, oris=oris, Jall=Jall,
             **{f"M{N}": M[N] for N in HARMS},
             params_a2=ham.params["a2"], params_M0=ham.params["M0"],
             grid=args.grid, omega=OMEGA, E0=E0)
    with open(out / "README.txt", "w") as f:
        f.write("HHG armonicos 4-7, wsm_two_weyl, FUERZA BRUTA (una sim por eps/orientacion, sin polinomio)\n")
        f.write(f"params: a2={ham.params['a2']}, M0={ham.params['M0']}, gamma={ham.params['gamma']}\n")
        f.write(f"grid={args.grid}^3, omega={OMEGA} (4um), E0={E0} (1e11 W/cm2), gamma_deph={g:.5f}\n")
        f.write(f"[001] eje-c; {args.neps} eps x {args.nori} orient = {args.neps*args.nori} corridas orden-{args.order}\n")
        f.write("convencion: PARES (4,6)=analizador co-rot cruzado 90; IMPARES (5,7)=fijo 0 + eps invertido\n")
        f.write("all_data.npz: eps, oris, Jall[ori,eps,harm(4,5,6,7),xyz] (currents crudos), M4..M7 (mapas)\n")

    titles = {4: "(a) 4th harmonic", 5: "(b) 5th harmonic",
              6: "(c) 6th harmonic", 7: "(d) 7th harmonic"}
    colors = {4: "#ee3b2d", 5: "#f7a01d", 6: "#3aae3a", 7: "#2a7fff"}
    for N in HARMS:
        plot_paper(M[N], eps, oris, str(out / f"harmonic_{N}.png"),
                   title=titles[N], color=colors[N])
        print(f"  map HO{N} -> harmonic_{N}.png", flush=True)
    print("LISTO ->", out, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
