"""Compare QXTI (perturbative theory) vs antelope (non-perturbative SBE) HHG for
the NatPhys_TaAs RCP run — first 3-4 harmonics.

antelope emission (following Analysis_Reader_RCP_LCP_Diff_Planes.py):
    FullRadiation_i(w) = -i w [ FFT(blackman * J_intra_i) + FFT(blackman * P_inter_i) ] dt
    S(w)               = sum_i |FullRadiation_i|^2
    helicity           = J_x +/- i J_y   (RCP/LCP), |.|^2

QXTI emission (analogous, from current_spectrum.npz):
    S(w) = |w * J_total(w)|^2 summed over components; helicity from Jx,Jy.

Absolute scales differ (perturbative vs full, dipole-vs-current conventions), so
we compare NORMALIZED harmonic intensities H_n / H_1 — i.e. the TRENDS / selection
rules — at the first 3-4 harmonics.

Usage:
    python tools/compare_taas_qxti_vs_antelope.py <qxti_current_spectrum.npz> [more.npz ...]
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

RCP = Path("/Users/victor/Library/Mobile Documents/com~apple~CloudDocs/Universidad/"
           "Tesis/TaAs_4WN/NatPhys_TaAs/RCP")
W0 = 0.0114          # laser frequency (a.u.), from RCP inputParam.cfg
DT = 0.5             # antelope timestep (a.u.)
N_HARM = 5           # look at harmonics 1..N_HARM


def _harmonic_values(freq, spectrum, n_harm=N_HARM, half_width_frac=0.4):
    """Peak spectral value in a window around each n*W0 (positive freq)."""
    out = []
    for n in range(1, n_harm + 1):
        target = n * W0
        win = half_width_frac * W0
        mask = (freq > target - win) & (freq < target + win)
        out.append(float(spectrum[mask].max()) if mask.any() else 0.0)
    return np.asarray(out)


def antelope_emission():
    """Total-current spectrum J_total(w) = FFT(J_intra) + (-i w) FFT(P_inter).

    P_inter is the interband DIPOLE, so the interband current is dP/dt -> -i w P(w).
    We compare |J_total|^2 (total current, the quantity both codes compute).
    """
    intra = np.loadtxt(RCP / "intraband_current_full_evol.dat")   # (Nt, 3) J_intra
    inter = np.loadtxt(RCP / "interband_dipole_full_evol.dat")    # (Nt, 3) P_inter
    nt = intra.shape[0]
    w = 2.0 * np.pi * np.fft.fftfreq(nt, d=DT)
    win = np.blackman(nt)
    J = np.zeros((nt, 3), dtype=complex)
    for i in range(3):
        fi = np.fft.fft(win * intra[:, i]) * DT
        fp = np.fft.fft(win * inter[:, i]) * DT
        J[:, i] = fi + (-1j * w) * fp
    pos = w > 0
    S = np.sum(np.abs(J) ** 2, axis=1)
    jp = np.abs(J[:, 0] + 1j * J[:, 1]) ** 2
    jm = np.abs(J[:, 0] - 1j * J[:, 1]) ** 2
    return w[pos], S[pos], jp[pos], jm[pos]


def qxti_emission(npz_path):
    d = np.load(npz_path)
    w = d["omega_axis"]
    J = d["current_spectrum"]           # (nw, 3) complex total current J(w)
    pos = w > 0
    S = np.sum(np.abs(J) ** 2, axis=1)
    jp = np.abs(J[:, 0] + 1j * J[:, 1]) ** 2
    jm = np.abs(J[:, 0] - 1j * J[:, 1]) ** 2
    return w[pos], S[pos], jp[pos], jm[pos]


def _norm(v):
    return v / v[0] if v[0] > 0 else v


def main():
    npz_paths = [Path(p) for p in sys.argv[1:]] or [
        Path("outputs/natphys_taas/cmd/data/current_spectrum.npz")
    ]

    fa, Sa, jpa, jma = antelope_emission()
    Ha = _harmonic_values(fa, Sa)
    Hpa = _harmonic_values(fa, jpa)
    Hma = _harmonic_values(fa, jma)

    print("\n=== HHG NatPhys_TaAs (RCP): QXTI (perturbativo) vs antelope (no-perturbativo) ===")
    print(f"antelope grid 300^3 (convergido). Armonicos 1..{N_HARM}, normalizados a H1.\n")
    print(f"{'H_n/H_1':<12} " + "  ".join(f"H{n}" for n in range(1, N_HARM + 1)))
    print(f"{'antelope':<12} " + "  ".join(f"{x:8.2e}" for x in _norm(Ha)))
    for p in npz_paths:
        if not p.exists():
            print(f"  (falta {p})")
            continue
        fq, Sq, jpq, jmq = qxti_emission(p)
        Hq = _harmonic_values(fq, Sq)
        label = p.parts[-4] if len(p.parts) >= 4 else p.stem
        print(f"{'QXTI:'+label:<12} " + "  ".join(f"{x:8.2e}" for x in _norm(Hq)))

    # helicity contrast (RCP vs LCP) per harmonic — the key circular-drive trend
    print(f"\n{'helicidad':<12} " + "  ".join(f"H{n}" for n in range(1, N_HARM + 1)))
    print(f"{'ant J+/(J++J-)':<14}" + " ".join(
        f"{a/(a+b+1e-300):6.2f}" for a, b in zip(Hpa, Hma)))
    for p in npz_paths:
        if not p.exists():
            continue
        fq, Sq, jpq, jmq = qxti_emission(p)
        Hpq = _harmonic_values(fq, jpq); Hmq = _harmonic_values(fq, jmq)
        label = p.parts[-4] if len(p.parts) >= 4 else p.stem
        print(f"{'qxti '+label:<14}" + " ".join(
            f"{a/(a+b+1e-300):6.2f}" for a, b in zip(Hpq, Hmq)))

    # plot
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig, ax = plt.subplots(figsize=(9, 5))
        ax.semilogy(fa / W0, Sa / Sa[np.argmin(np.abs(fa - W0))], "k-", lw=1.5,
                    label="antelope 300³ (no-pert.)")
        for p in npz_paths:
            if not p.exists():
                continue
            fq, Sq, jpq, jmq = qxti_emission(p)
            ref = Sq[np.argmin(np.abs(fq - W0))]
            label = p.parts[-4] if len(p.parts) >= 4 else p.stem
            ax.semilogy(fq / W0, Sq / ref, lw=1.2, label=f"QXTI {label}")
        for n in range(1, N_HARM + 1):
            ax.axvline(n, color="gray", ls=":", alpha=0.4)
        ax.set_xlim(0, N_HARM + 0.5)
        ax.set_xlabel("orden armónico  ω/ω₀")
        ax.set_ylabel("emisión S(ω) normalizada a H1")
        ax.set_title("NatPhys_TaAs RCP — QXTI (perturbativo) vs antelope (no-perturbativo)")
        ax.legend(fontsize=8)
        ax.grid(True, alpha=0.3)
        out = Path("outputs/taas_qxti_vs_antelope.png")
        out.parent.mkdir(parents=True, exist_ok=True)
        fig.tight_layout(); fig.savefig(out, dpi=150)
        print(f"\n  → figura: {out}")
    except Exception as e:
        print(f"  (plot omitido: {e})")


if __name__ == "__main__":
    main()
