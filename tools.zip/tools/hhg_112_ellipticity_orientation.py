"""4th-harmonic HHG vs (MIR ellipticity, sample orientation) on the TaAs (112).

Replicates the experimental pair of plots (waterfall + 2D map) for the 4th harmonic
only, comparing three TaAs models by irradiating the PHYSICAL (112) plane of the
real tetragonal crystal:

  * irradiation direction ∝ (1/a, 1/a, 2/c) with real TaAs a=3.4348, c=11.641 Å,
    i.e. propagation along the tetragonal [112] (θz≈67.36°, φz=45°).  For the CUBIC
    models (orenstein, two_weyl) this is the tetragonal (112) mapped into their
    cubic k-frame; for the tetragonal taas_tb it is its native (112).
  * ellipticity ε ∈ [-1, 1] and sample orientation φx ∈ [-90°, 90°] via the Laser
    in-plane basis: E = E0 (xdir + i ε ydir)/√(1+ε²), with xdir/ydir rotated by φx.
  * 4th harmonic intensity I = |J^(4)(4ω)|² (total emitted yield).

Efficiency (makes 150³ feasible): J^(4)(4ω) is an EXACT degree-4 homogeneous
polynomial in the complex drive E (the 4ω top channel is all +ω, no conjugates).
Since E lies in the 2D (112) plane, J^(4) is a degree-4 form in two complex
amplitudes (a, b) — 5 coefficients per Cartesian output.  So FIVE mesh runs per
model fix it exactly; the whole ε×φx grid is then free tensor contractions.

    python tools/hhg_112_ellipticity_orientation.py --grid 30 --model wsm_orenstein
"""
from __future__ import annotations

import argparse
import time
from pathlib import Path
import sys

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from qxti.core.config import QXTIConfig
from qxti.core.simulation import QXTISimulation
from qxti.physics.laser import Laser
from qxti.analytics.theory_response import _resolve_distribution
from qxti.analytics.mesh_response import precompute_band_data, harmonic_currents

# Real TaAs tetragonal lattice (Å) — sets the physical (112) direction.
A_TET, C_TET = 3.4348, 11.641


def _hbatch_orenstein(params):
    """Vectorized (nk,4,4) H for wsm_orenstein (skips the per-k Python loop)."""
    import models.wsm_orenstein as m
    p = dict(m.DEFAULT_PARAMS); p.update(params or {})     # honor config overrides
    t, my, mz, dl, a = (float(p["t"]), float(p["my"]), float(p["mz"]),
                        float(p["Delta"]), float(p["a"]))
    SX, SYI, SYSX, SZSX = m._SIGX_I, m._SIGY_I, m._SIGY_SX, m._SIGZ_SX

    def hb(kpts):
        kxa, kya, kza = a * kpts[:, 0], a * kpts[:, 1], a * kpts[:, 2]
        fx = np.cos(kxa) + my * (1 - np.cos(kya)) + mz * (1 - np.cos(kza))
        return t * (fx[:, None, None] * SX + np.sin(kya)[:, None, None] * SYI
                    + dl * np.cos(kya)[:, None, None] * SYSX
                    + np.sin(kza)[:, None, None] * SZSX)
    return hb


def _hbatch_two_weyl(params):
    """Vectorized (nk,2,2) H for wsm_two_weyl."""
    import models.wsm_two_weyl as m
    p = dict(m.DEFAULT_PARAMS); p.update(params or {})     # honor config overrides
    gm, tx, ty, tz, M0 = (float(p["gamma"]), float(p["tx"]), float(p["ty"]),
                          float(p["tz"]), float(p["M0"]))
    a0, a1, a2 = float(p["a0"]), float(p["a1"]), float(p["a2"])
    kw = m._kw_internal(p)
    s0, sx, sy, sz = m.sigma_0, m.sigma_x, m.sigma_y, m.sigma_z

    def hb(kpts):
        kx, ky, kz = kpts[:, 0], kpts[:, 1], kpts[:, 2]
        ck0 = np.cos(a0 * kw)
        b0 = gm * (np.cos(2 * a0 * kx) - ck0) * (np.cos(a2 * kz) - ck0)
        b1 = -(M0 * (1 - np.cos(a2 * kz) - np.cos(a1 * ky)) + 2 * tx * (np.cos(a0 * kx) - ck0))
        b2 = -2 * ty * np.sin(a1 * ky)
        b3 = -2 * tz * np.cos(a2 * kz)
        return (b0[:, None, None] * s0 + b1[:, None, None] * sx
                + b2[:, None, None] * sy + b3[:, None, None] * sz)
    return hb


def h_batch_for(model_key, ham):
    params = dict(getattr(ham, "params", {}) or {})        # config-resolved params
    if model_key == "wsm_orenstein":
        return _hbatch_orenstein(params)
    if model_key == "wsm_two_weyl":
        return _hbatch_two_weyl(params)
    return None    # taas_tb (8-band SOC): fall back to the scalar per-k loop


def plane_112():
    """(112) propagation direction (θz, φz) and in-plane basis ê1, ê2 (φx=0)."""
    d = np.array([1.0 / A_TET, 1.0 / A_TET, 2.0 / C_TET])
    d /= np.linalg.norm(d)
    thetaz = float(np.arccos(d[2]))
    phiz = float(np.arctan2(d[1], d[0]))
    L = Laser(omega=1.0, E0=1.0, ellip=0.0, thetaz=thetaz, phiz=phiz, phix=0.0)
    return thetaz, phiz, L.xdir.copy(), L.ydir.copy(), L.zdir.copy()


def _monomials(a, b):
    """Degree-4 symmetric monomials [a^4, a^3 b, a^2 b^2, a b^3, b^4]."""
    return np.array([a**4, a**3 * b, a**2 * b**2, a * b**3, b**4], dtype=np.complex128)


# 5 drive directions (a,b) with an invertible monomial matrix.
_FIT_AB = np.array([[1, 0], [0, 1], [1, 1], [1, 2], [2, 1]], dtype=np.complex128)


def fit_order4(band, weights, omega, e1, e2, E0, gamma):
    """Five order-4 recursions -> exact degree-4 coefficients C[i, 5] for J^(4)_i(a,b).

    Identical math to five ``harmonic_currents`` calls, but the band, the Wilson
    links and the field-independent order-1 sources are precomputed ONCE and shared
    across the five drives (the closed-form path recomputes the links on every call,
    which is prohibitive at 150³).  The physical drive is E = a ê1 + b ê2 with (a,b)
    carrying E0, matching the ε×φx sweep.
    """
    nb, nk, dim, diag = band.nb, band.nk, band.dim, band.diag
    eps, valid, A, vel = band.eps, band.valid, band.A, band.vel
    f, dfde = band.f, band.dfde
    shape, U_mesh, Udag, dks = band.shape, band.U_mesh, band.Udag, band.dks
    fmn = f[:, None, :] - f[:, :, None]
    w_k = np.asarray(weights, dtype=np.float64).reshape(nk)
    ow_coh = complex(omega + 1j * gamma)

    # field-independent order-1 source operators r_c (one per Cartesian direction)
    r_c = []
    for c in range(dim):
        with np.errstate(divide="ignore", invalid="ignore"):
            r = np.where(valid, (A[c] * fmn) / (ow_coh - eps), 0.0 + 0.0j)
        r[:, diag, diag] += (-1j) * dfde * np.real(vel[c][:, diag, diag]) / ow_coh
        r_c.append(r)
    band.A = None                                                     # free A (2.6 GB@150³)
    Gamma = np.full((nb, nb), gamma); np.fill_diagonal(Gamma, gamma)
    iGamma = 1j * Gamma
    # Wilson links per direction, precomputed ONCE (shared across all 5 drives).
    # Store only wp, wm (daggers built inline in cov_grad) to halve the link memory.
    links = []
    for b in range(dim):
        Up = np.roll(U_mesh, -1, axis=b).reshape(nk, nb, nb)
        Un = np.roll(U_mesh, +1, axis=b).reshape(nk, nb, nb)
        links.append((Udag @ Up, Udag @ Un))
    del Up, Un
    vwT = [(vel[i] * w_k[:, None, None]).swapaxes(1, 2).copy() for i in range(dim)]

    def cov_grad(R, b):
        wp, wm = links[b]
        Rm = R.reshape(*shape, nb, nb)
        Rp = np.roll(Rm, -1, axis=b).reshape(nk, nb, nb)
        Rn = np.roll(Rm, +1, axis=b).reshape(nk, nb, nb)
        return (wp @ Rp @ np.conj(np.swapaxes(wp, -1, -2))
                - wm @ Rn @ np.conj(np.swapaxes(wm, -1, -2))) / (2.0 * dks[b])

    AB = E0 * _FIT_AB
    M = np.array([_monomials(ab[0], ab[1]) for ab in AB])
    Jfit = np.empty((5, 3), dtype=np.complex128)
    for kdrive, (a, b) in enumerate(AB):
        E = a * e1 + b * e2                                            # 3-vector drive
        rho = sum(E[c] * r_c[c] for c in range(dim) if abs(E[c]) > 1e-40)
        for s in range(2, 5):
            src = np.zeros((nk, nb, nb), dtype=np.complex128)
            for bb in range(dim):
                if abs(E[bb]) > 1e-40:
                    src += E[bb] * cov_grad(rho, bb)
            with np.errstate(divide="ignore", invalid="ignore"):
                denom = s * omega + iGamma - eps
                rho = np.where(np.abs(denom) > 0, src / denom, 0.0)
        for i in range(dim):
            Jfit[kdrive, i] = np.tensordot(vwT[i], rho, axes=([0, 1, 2], [0, 1, 2]))
    Minv = np.linalg.inv(M)
    return np.array([Minv @ Jfit[:, i] for i in range(3)])


def sweep_intensity(C, eps_grid, phix_grid, e1, e2, E0, observable="inplane",
                    orient_offset=0.0, pol_angle=0.0, pol_corotate=False):
    """I(φx, ε) over the grid, from the fitted coefficients (free).

    ``observable``:
      * ``polarizer``: |J·ê_pol|² — the emitted harmonic passes a LINEAR polarizer
        (analyzer) before the spectrometer, so only one transverse component is
        detected.  ``pol_angle`` (rad) sets ê_pol in the (ê1,ê2) plane; if
        ``pol_corotate`` the analyzer rotates WITH the sample orientation (fixed
        angle to the drive frame), else it is fixed in the crystal (ê1,ê2) frame.
      * ``inplane`` (physical, no analyzer): transverse yield |J·ê1|²+|J·ê2|².
      * ``total``: |J^(4)|² over all Cartesian components.
    ``orient_offset`` (rad): shifts the field rotation vs the PLOTTED orientation.
    """
    I = np.empty((phix_grid.size, eps_grid.size), dtype=np.float64)
    for ip, px0 in enumerate(phix_grid):
        px = px0 + orient_offset                # actual field rotation
        c, s = np.cos(px), np.sin(px)
        if observable == "polarizer":
            pa = pol_angle + (px if pol_corotate else 0.0)
            e_pol = np.cos(pa) * e1 + np.sin(pa) * e2
        for ie, ep in enumerate(eps_grid):
            N = np.sqrt(1.0 + ep * ep)
            a = E0 * (c - 1j * ep * s) / N        # E·ê1 (complex amplitude)
            b = E0 * (s + 1j * ep * c) / N        # E·ê2
            J = _monomials(a, b) @ C.T            # (3,) complex J^(4)
            if observable == "total":
                I[ip, ie] = float(np.sum(np.abs(J) ** 2))
            elif observable == "polarizer":
                I[ip, ie] = float(np.abs(J @ e_pol) ** 2)
            else:
                I[ip, ie] = float(np.abs(J @ e1) ** 2 + np.abs(J @ e2) ** 2)
    return I


def compute_model(model_key, grid, n_eps, n_phix, progress=True, params_override=None,
                  observable="inplane", orient_offset_deg=0.0, omega=None, E0=None,
                  pol_angle_deg=0.0, pol_corotate=False):
    cfg_map = {"wsm_orenstein": "inputs/inputParams.wsm_orenstein.cfg",
               "wsm_two_weyl": "inputs/inputParams.wsm.cfg",
               "taas_tb": "inputs/inputParams.taas_tb.cfg"}
    cfg = QXTIConfig.from_file(cfg_map[model_key])
    cfg.kgrid.k_points = (grid, grid, grid)
    sim = QXTISimulation(config=cfg)
    ham = sim.build_hamiltonian()
    if params_override:                                    # e.g. tetragonal a2 for two_weyl
        ham.params.update(params_override)
    kg = sim.build_kgrid(ham)
    from qxti.analytics.theory_response import build_k_integration_weights
    weights = build_k_integration_weights(cfg, hamiltonian=ham, kgrid=kg)
    ccfg = cfg.susceptibility_solver
    mu, T_au = float(ccfg.fermi_level), float(ccfg.temperature)
    gamma = 0.0 if ccfg.coherence_time <= 0 else 1.0 / float(ccfg.coherence_time)
    dist = _resolve_distribution(ccfg.distribution)
    omega = float(cfg.laser.omega) if omega is None else float(omega)
    E0 = (float(cfg.laser.E0) or 1e-4) if E0 is None else float(E0)
    thetaz, phiz, e1, e2, zdir = plane_112()

    kpts = np.asarray(kg.points()); shape = tuple(int(kg.shape[a]) for a in range(3))
    bounds = ham.reciprocal_box_bounds()
    t0 = time.perf_counter()
    if progress:
        print(f"[{model_key}] grid {grid}^3 = {grid**3} k-points, nb={ham.basis_size}, "
              f"omega={omega}, (112): θz={np.degrees(thetaz):.2f}°, φz={np.degrees(phiz):.2f}° ...",
              flush=True)
    band = precompute_band_data(ham._matrix_at, kpts, shape, bounds, mu=mu, T_au=T_au,
                                dimension=int(ham.dimension), distribution=dist,
                                h_batch=h_batch_for(model_key, ham))
    if progress:
        print(f"[{model_key}] band data ready ({time.perf_counter()-t0:.1f}s); "
              "5 mesh runs for the order-4 coefficients ...", flush=True)
    C = fit_order4(band, weights, omega, e1, e2, E0, gamma)
    del band
    eps_grid = np.linspace(-1.0, 1.0, n_eps)
    phix_grid = np.linspace(-np.pi / 2, np.pi / 2, n_phix)
    I = sweep_intensity(C, eps_grid, phix_grid, e1, e2, E0, observable=observable,
                        orient_offset=np.radians(orient_offset_deg),
                        pol_angle=np.radians(pol_angle_deg), pol_corotate=pol_corotate)
    if progress:
        print(f"[{model_key}] done in {time.perf_counter()-t0:.1f}s. "
              f"I range [{I.min():.2e}, {I.max():.2e}]", flush=True)
    return {"I": I, "eps": eps_grid, "phix": np.degrees(phix_grid), "grid": grid,
            "nb": int(ham.basis_size), "omega": omega, "C": C, "e1": e1, "e2": e2, "E0": E0,
            "gamma": gamma}


def validate_poly(model_key, grid=16):
    """Check the degree-4 polynomial == direct harmonic_currents at a few configs."""
    res = compute_model(model_key, grid, 5, 5, progress=False)
    cfg = QXTIConfig.from_file({"wsm_orenstein": "inputs/inputParams.wsm_orenstein.cfg",
                                "wsm_two_weyl": "inputs/inputParams.wsm.cfg",
                                "taas_tb": "inputs/inputParams.taas_tb.cfg"}[model_key])
    cfg.kgrid.k_points = (grid, grid, grid)
    sim = QXTISimulation(config=cfg); ham = sim.build_hamiltonian(); kg = sim.build_kgrid(ham)
    from qxti.analytics.theory_response import build_k_integration_weights
    w = build_k_integration_weights(cfg, hamiltonian=ham, kgrid=kg)
    band = precompute_band_data(ham._matrix_at, np.asarray(kg.points()),
                                tuple(int(kg.shape[a]) for a in range(3)),
                                ham.reciprocal_box_bounds(), mu=float(cfg.susceptibility_solver.fermi_level),
                                T_au=float(cfg.susceptibility_solver.temperature), dimension=3,
                                distribution=_resolve_distribution(cfg.susceptibility_solver.distribution))
    C, e1, e2, E0 = res["C"], res["e1"], res["e2"], res["E0"]
    gamma = res["gamma"]; omega = res["omega"]
    print(f"  validate {model_key}: poly vs direct harmonic_currents")
    for ep, px in [(0.3, 20 * np.pi / 180), (-0.7, -50 * np.pi / 180), (1.0, 0.0)]:
        c, s = np.cos(px), np.sin(px); N = np.sqrt(1 + ep * ep)
        a = E0 * (c - 1j * ep * s) / N; b = E0 * (s + 1j * ep * c) / N
        Jpoly = _monomials(a, b) @ C.T
        xd = np.cos(px) * e1 + np.sin(px) * e2; yd = -np.sin(px) * e1 + np.cos(px) * e2
        E = E0 * (xd + 1j * ep * yd) / N
        Jdir = harmonic_currents(band, w, E, omega, 4, gamma=gamma, gamma_pop=gamma)[4][:3]
        err = np.linalg.norm(Jpoly - Jdir) / max(np.linalg.norm(Jdir), 1e-300)
        print(f"    ε={ep:+.2f} φx={np.degrees(px):+.0f}°: rel err = {err:.2e}")


MODELS = ["wsm_orenstein", "wsm_two_weyl", "taas_tb"]
NICE = {"wsm_orenstein": "Orenstein (cubic 4-band)",
        "wsm_two_weyl": "2-band Weyl (cubic)",
        "taas_tb": "TaAs real (tetragonal 8-band)"}


def plot_all(results, out_path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    names = [m for m in MODELS if m in results]
    fig, axes = plt.subplots(2, len(names), figsize=(5.0 * len(names), 8.6),
                             gridspec_kw={"height_ratios": [1.25, 1.0]})
    if len(names) == 1:
        axes = axes.reshape(2, 1)
    fig.suptitle("HHG 4th harmonic on TaAs (112): MIR ellipticity vs sample orientation",
                 fontsize=13, fontweight="bold")
    im = None
    for col, name in enumerate(names):
        r = results[name]
        I = np.asarray(r["I"]); eps = np.asarray(r["eps"]); phix = np.asarray(r["phix"])
        Inorm = I / (I.max() if I.max() > 0 else 1.0)

        # --- waterfall (top): traces vs ellipticity, stacked by orientation ---
        ax = axes[0, col]
        step = 0.55
        cmap = plt.get_cmap("viridis")
        for j, px in enumerate(phix):
            bold = (abs(px) < 4) or (abs(abs(px) - 90) < 4)
            ax.plot(eps, Inorm[j] + j * step, lw=2.0 if bold else 0.7,
                    color=cmap(j / max(len(phix) - 1, 1)), alpha=0.95 if bold else 0.8)
        for lab, jj in [("-90°", 0), ("0°", len(phix) // 2), ("90°", len(phix) - 1)]:
            ax.text(-1.05, jj * step + 0.1, lab, fontsize=8, va="bottom")
        ax.set_title(f"{NICE[name]}\n{int(r['grid'])}³, nb={int(r['nb'])}", fontsize=10)
        ax.set_xlabel("MIR ellipticity"); ax.set_ylabel("HHG count (norm., offset)")
        ax.set_xlim(-1.05, 1.05); ax.set_yticks([])
        ax.axvline(0, color="0.7", lw=0.6, ls="--")

        # --- 2D map (bottom): orientation vs ellipticity ---
        ax2 = axes[1, col]
        im = ax2.imshow(Inorm, extent=[eps.min(), eps.max(), phix.min(), phix.max()],
                        aspect="auto", origin="lower", cmap="magma", vmin=0, vmax=1)
        ax2.set_xlabel("MIR ellipticity"); ax2.set_ylabel("Sample orientation (deg)")
        ax2.set_yticks([-90, -45, 0, 45, 90])
    fig.tight_layout(rect=[0, 0, 0.92, 0.95])
    if im is not None:
        cax = fig.add_axes([0.94, 0.08, 0.012, 0.36])
        fig.colorbar(im, cax=cax, label="HHG 4th harmonic (norm.)")
    fig.savefig(out_path, dpi=150)
    print(f"[figura guardada] {out_path}")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--model", default="wsm_orenstein",
                   choices=["wsm_orenstein", "wsm_two_weyl", "taas_tb"])
    p.add_argument("--grid", type=int, default=30)
    p.add_argument("--n-eps", type=int, default=41)
    p.add_argument("--n-phix", type=int, default=37)
    p.add_argument("--validate", action="store_true")
    p.add_argument("--all", action="store_true",
                   help="compute all 3 models (per-model grids fit to RAM) and plot")
    p.add_argument("--grids", type=int, nargs=3, default=[150, 150, 100],
                   help="per-model grids: orenstein two_weyl taas_tb")
    p.add_argument("--out", default="outputs/hhg112_4th_harmonic_3models.png")
    args = p.parse_args()
    if args.validate:
        validate_poly(args.model, grid=args.grid)
        return
    if args.all:
        gmap = {"wsm_orenstein": args.grids[0], "wsm_two_weyl": args.grids[1],
                "taas_tb": args.grids[2]}
        results = {}
        for m in MODELS:
            results[m] = compute_model(m, gmap[m], args.n_eps, args.n_phix)
            np.savez(Path(f"outputs/hhg112_{m}_g{gmap[m]}.npz"),
                     I=results[m]["I"], eps=results[m]["eps"], phix=results[m]["phix"],
                     grid=results[m]["grid"], nb=results[m]["nb"], omega=results[m]["omega"])
        plot_all(results, Path(args.out))
        return
    res = compute_model(args.model, args.grid, args.n_eps, args.n_phix)
    out = Path(f"outputs/hhg112_{args.model}_g{args.grid}.npz")
    out.parent.mkdir(parents=True, exist_ok=True)
    np.savez(out, I=res["I"], eps=res["eps"], phix=res["phix"], grid=res["grid"],
             nb=res["nb"], omega=res["omega"])
    plot_all({args.model: res}, Path(f"outputs/hhg112_{args.model}_g{args.grid}.png"))
    print(f"saved {out}")


if __name__ == "__main__":
    main()
