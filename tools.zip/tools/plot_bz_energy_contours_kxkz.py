#!/usr/bin/env python3
"""Fermi surface contours E_n(kx, kz) at ky=0 for all four bands.

Plots iso-energy lines (contours) of each band in the kx-kz plane.
One figure per Delta value; contour levels spaced evenly across the band range.

Usage:
    python tools/plot_bz_energy_contours_kxkz.py [--points N] [--dpi D]
"""
from __future__ import annotations

import importlib.util
import os
import sys
from pathlib import Path

import numpy as np

os.environ.setdefault("MPLCONFIGDIR", "/private/tmp")
os.environ.setdefault("XDG_CACHE_HOME", "/private/tmp")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker

from qxti.graphics.plot_susceptibility_tensor import apply_paper_style

_EV   = 27.211386245988
OUT   = Path("outputs/bz_chi_contribution/energy_contours_kxkz")
DELTAS = (0.5, 0.375, 0.25, 0.125)

BAND_COLORS = ["#1E64C8", "#2A9D8F", "#F4A261", "#E8000B"]
BAND_LABELS = ["Band 1", "Band 2", "Band 3", "Band 4"]

# plane definitions: (plane_axis, fixed_val, xlabel, ylabel, horiz_ax, vert_ax)
PLANES = [
    ("ky", 0.0,  r"$k_x\,a$", r"$k_z\,a$", 0, 2),   # kx-kz, ky=0
    ("kz", 0.0,  r"$k_x\,a$", r"$k_y\,a$", 0, 1),   # kx-ky, kz=0
    ("kx", -np.pi/2, r"$k_y\,a$", r"$k_z\,a$", 1, 2), # ky-kz, kx=-pi/2
]


def _pi_ticks(ax, which="x"):
    ticks = [-np.pi, -np.pi/2, 0, np.pi/2, np.pi]
    labels = [r"$-\pi$", r"$-\pi/2$", r"$0$", r"$\pi/2$", r"$\pi$"]
    if which == "x":
        ax.set_xticks(ticks); ax.set_xticklabels(labels, fontsize=14)
    else:
        ax.set_yticks(ticks); ax.set_yticklabels(labels, fontsize=14)


def _overlay_nodes(ax, nodes, plane_axis_idx, fixed, horiz_ax, vert_ax, a):
    col = {+1: "#E8000B", -1: "#1E64C8"}
    mrk = {+1: "+",       -1: "-"}
    seen: set = set()
    for nd in nodes:
        k = nd["k"]; c = int(nd["chirality"])
        if abs(k[plane_axis_idx] - fixed / a) > 0.05:
            continue
        kh = k[horiz_ax] * a
        kv = k[vert_ax]  * a
        lab = rf"$\chi={c:+d}$" if c not in seen else None
        seen.add(c)
        ax.scatter([kh], [kv], s=180, facecolors=col.get(c, "grey"),
                   edgecolors="white", linewidths=1.5, zorder=7, label=lab)
        ax.text(kh, kv, mrk.get(c, "?"), color="white", ha="center",
                va="center", fontsize=11, fontweight="bold", zorder=8)


def _make_contour_plot(ax, KA, KB, E, nlevels, nodes,
                        plane_axis_idx, fixed, horiz_ax, vert_ax, a,
                        xlabel, ylabel, title):
    from matplotlib.lines import Line2D

    for nb in range(4):
        Eband = E[:, :, nb]
        emin, emax = float(Eband.min()), float(Eband.max())
        levels = np.linspace(emin, emax, nlevels)
        cs = ax.contour(KA, KB, Eband, levels=levels,
                        colors=BAND_COLORS[nb], linewidths=0.9, alpha=0.85)
        ax.clabel(cs, levels[::3], inline=True, fontsize=7,
                  fmt=lambda v: f"{v:.2f}", colors=BAND_COLORS[nb])
        if Eband.min() < 0 < Eband.max():
            ax.contour(KA, KB, Eband, levels=[0.0],
                       colors="white", linewidths=2.0,
                       linestyles="--", zorder=5)

    _overlay_nodes(ax, nodes, plane_axis_idx, fixed, horiz_ax, vert_ax, a)

    handles = [Line2D([0],[0], color=BAND_COLORS[nb], lw=2,
                      label=BAND_LABELS[nb]) for nb in range(4)]
    handles.append(Line2D([0],[0], color="white", lw=2,
                           linestyle="--", label="$E=0$"))
    if nodes:
        from matplotlib.lines import Line2D as L2
        handles += [
            plt.scatter([],[], s=80, facecolors="#E8000B",
                        edgecolors="white", label=r"$\chi=+1$"),
            plt.scatter([],[], s=80, facecolors="#1E64C8",
                        edgecolors="white", label=r"$\chi=-1$"),
        ]
    ax.legend(handles=handles, fontsize=10, loc="upper right",
              frameon=True, framealpha=0.55)

    ax.set_xlabel(xlabel, fontsize=18)
    ax.set_ylabel(ylabel, fontsize=18)
    _pi_ticks(ax, "x"); _pi_ticks(ax, "y")
    ax.tick_params(labelsize=13)
    ax.set_xlim(-np.pi, np.pi); ax.set_ylim(-np.pi, np.pi)
    ax.set_facecolor("#0e1117")
    for spine in ax.spines.values(): spine.set_edgecolor("white")
    ax.tick_params(colors="white")
    ax.xaxis.label.set_color("white"); ax.yaxis.label.set_color("white")
    ax.set_title(title, fontsize=13, pad=6, color="white")


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--points",  type=int, default=300)
    ap.add_argument("--dpi",     type=int, default=280)
    ap.add_argument("--nlevels", type=int, default=18)
    args = ap.parse_args()

    spec = importlib.util.spec_from_file_location(
        "wsm_o", PROJECT_ROOT / "models" / "wsm_orenstein.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    p_base = mod.default_params()
    a = float(p_base["a"])

    N = args.points
    k1d = np.linspace(-np.pi/a, np.pi/a, N)
    OUT.mkdir(parents=True, exist_ok=True)

    for delta in DELTAS:
        p = dict(p_base); p["Delta"] = float(delta)
        nodes = mod.weyl_nodes_with_chirality(p) if hasattr(mod, "weyl_nodes_with_chirality") else []

        for plane_name, fixed, xlabel, ylabel, horiz_ax, vert_ax in PLANES:
            plane_axis_idx = {"kx":0,"ky":1,"kz":2}[plane_name]
            print(f"[contours] Δ={delta}  {plane_name}={fixed/np.pi:.3g}π  "
                  f"computing {N}x{N} ...", flush=True)

            E = np.empty((N, N, 4))
            for i, ka in enumerate(k1d):
                for j, kb in enumerate(k1d):
                    kpt = [0., 0., 0.]
                    kpt[horiz_ax]      = ka
                    kpt[vert_ax]       = kb
                    kpt[plane_axis_idx] = fixed / a
                    E[i, j, :] = np.linalg.eigvalsh(
                        mod.H(kpt[0], kpt[1], kpt[2], p)) * _EV

            KA, KB = np.meshgrid(k1d * a, k1d * a, indexing="ij")

            apply_paper_style()
            fig, ax = plt.subplots(figsize=(7.2, 6.4))
            fig.patch.set_facecolor("#0e1117")

            fixed_tex  = (f"{fixed/np.pi:.3g}pi" if fixed != 0.0 else "0")
            pax        = plane_name[-1]
            title      = (rf"$E_n(k_x,k_z)$ plane,  "
                          f"$k_{{{pax}}}\\,a={fixed_tex}$,  $\\Delta={delta}$")

            _make_contour_plot(ax, KA, KB, E, args.nlevels, nodes,
                               plane_axis_idx, fixed, horiz_ax, vert_ax, a,
                               xlabel, ylabel, title)
            fig.tight_layout()

            delta_str  = f"{delta:.3f}".replace(".", "p")
            fixed_str  = f"{fixed:.4f}".replace("-","m").replace(".","p")
            fname = OUT / f"energy_contours_{plane_name}{fixed_str}_delta{delta_str}.png"
            fig.savefig(fname, dpi=args.dpi, facecolor=fig.get_facecolor(),
                        bbox_inches="tight")
            plt.close(fig)
            print(f"  -> {fname}", flush=True)

    print("[done]", flush=True)


if __name__ == "__main__":
    main()
