"""Replica del panel (a) — 4to armonico HHG vs (elipticidad, orientacion) estilo paper.

Reproduce la figura experimental de TaAs: waterfall rojo (HHG count vs elipticidad,
apilado por orientacion) + heatmap (orientacion x elipticidad) con colormap batlow.

FISICA (todo perturbativo, chi^(4), valido a 1e11 W/cm2):
  * J^(4)(4w) es un polinomio homogeneo de grado 4 en el campo complejo E -> 5
    corridas del mesh (`fit_order4`) lo fijan EXACTO; luego el barrido eps x orient
    es contraccion gratis.
  * Campo: HWP+QWP -> elipse de elipticidad eps y orientacion phix en el plano de
    irradiacion.  E = E0 (xhat(phix) + i*eps*yhat(phix)) / sqrt(1+eps^2).
  * DOBLE-PICO en eps=+-0.5 (en orientacion +-90) <- componente CRUZADA del
    polarizador (analizador) antes del espectrometro.
  * S / diagonal en el heatmap <- dicroismo circular (quiralidad de Weyl), fuerte
    irradiando a lo largo del eje-c [001].
  * Modelo: 2-band de Weyl hecho TETRAGONAL (a2 != a0).  Mejores parametros del
    barrido fino (S conectada, verticales RECTAS en eps~+-0.5): M0=0.014, a2=12.
    (M0>=0.015 aplana la traza de 0 grados; M0<0.012 ondula las verticales; el
    tilt gamma y tx/ty/tz solo empeoran.)  Estos valores son ahora tambien los
    DEFAULT del modelo (models/wsm_two_weyl.py) y del cfg (inputParams.wsm.cfg).

Parametros experimentales: 4 um -> omega=0.0114 a.u.;  1e11 W/cm2 -> E0=1.7e-3 a.u.

Uso:
    python tools/replica_paper_4th.py                     # mejores params
    python tools/replica_paper_4th.py --a2 12 --M0 0.0164 # otros params
    python tools/replica_paper_4th.py --grid 100 --n-orient 19
    python tools/replica_paper_4th.py --replot outputs/bestparam_M.npz   # solo re-plotear
"""
from __future__ import annotations

import argparse
import time
from pathlib import Path
import sys

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from qxti.core.config import QXTIConfig
from qxti.core.simulation import QXTISimulation
from qxti.analytics.theory_response import build_k_integration_weights, _resolve_distribution
from qxti.analytics.mesh_response import precompute_band_data
from tools.hhg_112_ellipticity_orientation import fit_order4, _monomials, h_batch_for

# --- parametros experimentales (4 um, 1e11 W/cm2) ---------------------------
OMEGA = 0.0114          # 4 um  -> hbar*omega = 0.31 eV
E0 = 1.7e-3             # 1e11 W/cm2 = E0^2 * 3.51e16  -> E0 = sqrt(I/3.51e16)

# colormap "batlow" (Crameri) aproximado: navy -> teal -> verde -> tan -> rosa
BATLOW = LinearSegmentedColormap.from_list("batlow", [
    "#011959", "#103567", "#275160", "#45694f", "#6b7d3d",
    "#a08d41", "#d5a06f", "#f5b3a9", "#fdccf5"])


def compute_heatmap(a2, M0, gamma_tilt, grid, n_eps, n_orient,
                    e1, e2, pol_deg, corot, progress=True):
    """Devuelve M[orient, eps] = |J^(4)_pol|^2 para el 2-band tetragonal."""
    cfg = QXTIConfig.from_file("inputs/inputParams.wsm.cfg")
    cfg.kgrid.k_points = (grid, grid, grid)
    sim = QXTISimulation(config=cfg)
    ham = sim.build_hamiltonian()
    ham.params.update({"a2": float(a2), "M0": float(M0), "gamma": float(gamma_tilt)})
    kg = sim.build_kgrid(ham)
    w = build_k_integration_weights(cfg, hamiltonian=ham, kgrid=kg)
    cc = cfg.susceptibility_solver
    gamma_deph = 1.0 / cc.coherence_time              # 1/T2 (broadening)
    t0 = time.perf_counter()
    if progress:
        print(f"[replica] banda 2-band tetragonal {grid}^3  (a2={a2}, M0={M0}) ...", flush=True)
    band = precompute_band_data(
        ham._matrix_at, np.asarray(kg.points()),
        tuple(int(kg.shape[a]) for a in range(3)), ham.reciprocal_box_bounds(),
        mu=cc.fermi_level, T_au=cc.temperature, dimension=3,
        distribution=_resolve_distribution(cc.distribution),
        h_batch=h_batch_for("wsm_two_weyl", ham))
    C = fit_order4(band, w, OMEGA, e1, e2, E0, gamma_deph)   # <-- coeficientes exactos
    del band
    if progress:
        print(f"[replica] fit listo ({time.perf_counter()-t0:.0f}s), barrido eps x orient ...", flush=True)

    eps = np.linspace(-1.0, 1.0, n_eps)
    oris = np.linspace(-90.0, 90.0, n_orient)
    M = np.zeros((oris.size, eps.size))
    for io, ori in enumerate(oris):
        px = np.radians(ori)
        pa = np.radians(pol_deg) + (px if corot else 0.0)   # polarizador (analizador)
        e_pol = np.cos(pa) * e1 + np.sin(pa) * e2
        for ie, ep in enumerate(eps):
            N = np.sqrt(1.0 + ep * ep)
            a = E0 * (np.cos(px) - 1j * ep * np.sin(px)) / N   # E . e1
            b = E0 * (np.sin(px) + 1j * ep * np.cos(px)) / N   # E . e2
            J = _monomials(a, b) @ C.T                         # J^(4) (3-vector)
            M[io, ie] = float(np.abs(J @ e_pol) ** 2)          # tras el polarizador
    return M, eps, oris


def plot_paper(M, eps, oris, out_path, title="(a) 4th harmonic", color="#ee3b2d"):
    """Figura estilo paper 1:1: waterfall rojo (arriba) + heatmap batlow (abajo).

    CLAVE: la normalizacion es POR ORIENTACION (min-max de cada fila).  La misma
    matriz normalizada alimenta las trazas del waterfall Y el heatmap — asi cada
    fila del mapa va de navy (minimo) a rosa (maximo) y las franjas claras siguen
    el pico de cada traza: eso dibuja la S.  Con normalizacion global la S se
    pierde (solo se ven los lobulos absolutos mas intensos).
    """
    try:                                   # colormap batlow exacto si esta instalado
        from cmcrameri import cm as _cmc
        cmap = _cmc.batlow
    except Exception:
        cmap = BATLOW

    M = np.asarray(M, float); eps = np.asarray(eps, float); oris = np.asarray(oris, float)
    n = oris.size
    mx = M.max(axis=1, keepdims=True)
    Mn = M / np.where(mx > 0, mx, 1.0)        # I/I_max por fila (NO min-max: las
    # trazas poco moduladas quedan planas y el mapa conserva los tonos medios)

    # proporciones del paper: ~443x989 px -> alto/ancho ~2.23; waterfall/heatmap ~1.4
    fig = plt.figure(figsize=(3.6, 8.0))

    # ------------------------------ waterfall -------------------------------
    ax = fig.add_axes([0.215, 0.455, 0.745, 0.465])
    step, amp, base0 = 0.31, 0.68, 0.42       # offset UNIFORME entre trazas
    red = color
    for i, o in enumerate(oris):
        bold = np.isclose(abs(o), 0.0) or np.isclose(abs(o), 90.0)
        ax.plot(eps, base0 + i * step + amp * Mn[i], color=red,
                lw=3.4 if bold else 1.05, solid_capstyle="round",
                zorder=3 if bold else 2)
    j0 = int(np.argmin(np.abs(oris)))
    i0 = int(np.argmin(np.abs(eps)))
    ax.text(-0.30, base0 + (n - 1) * step + amp * Mn[-1, i0] + 0.10, r"$90^{\circ}$", fontsize=10)
    ax.text(-0.07, base0 + j0 * step + amp * Mn[j0, i0] + 0.12, r"$0^{\circ}$", fontsize=10)
    ax.text(-0.52, base0 + 0.10, r"$-90^{\circ}$", fontsize=10)
    ax.set_xlim(-1.07, 1.07)
    ax.set_ylim(0, base0 + (n - 1) * step + amp + 0.22)
    ax.set_xlabel("MIR ellipticity", fontsize=11)
    ax.set_ylabel("HHG count (norm.)", fontsize=11)
    ax.set_xticks([-1, -0.5, 0, 0.5, 1])
    ax.set_xticklabels(["-1", "-0.5", "0", "0.5", "1"])
    ax.set_yticks(range(0, 7))
    ax.tick_params(labelsize=9)
    for x in (-1, -0.5, 0, 0.5, 1):           # punteadas en TODOS los ticks
        ax.axvline(x, color="0.45", ls=(0, (1, 3)), lw=0.8, zorder=1)
    ax.set_title(title, fontsize=12)

    # ------------------------------- heatmap --------------------------------
    axm = fig.add_axes([0.215, 0.065, 0.745, 0.33])
    stride = max(1, (eps.size - 1) // 20)     # ~21 columnas: look pixelado del paper
    axm.imshow(Mn[:, ::stride], extent=[-1, 1, -90, 90], aspect="auto",
               origin="lower", cmap=cmap, vmin=0, vmax=1, interpolation="nearest")
    axm.set_xlabel("MIR ellipticity", fontsize=11)
    axm.set_ylabel("Sample orientation (deg)", fontsize=11)
    axm.set_yticks([-90, -45, 0, 45, 90])
    axm.set_xticks([-1, -0.5, 0, 0.5, 1])
    axm.set_xticklabels(["-1", "-0.5", "0", "0.5", "1"])
    axm.tick_params(labelsize=9)

    fig.savefig(out_path, dpi=180, facecolor="white")
    print(f"[replica] figura guardada: {out_path}")


def main():
    p = argparse.ArgumentParser()
    # parametros del Hamiltoniano (mejores del barrido por defecto)
    p.add_argument("--a2", type=float, default=12.0, help="distorsion tetragonal (a2 != a0)")
    p.add_argument("--M0", type=float, default=0.014, help="masa/gap")
    p.add_argument("--gamma-tilt", type=float, default=0.0, help="tilt de los conos")
    p.add_argument("--grid", type=int, default=120, help="k-grid (memoria: 2-band ok a 120^3)")
    p.add_argument("--n-eps", type=int, default=161)
    p.add_argument("--n-orient", type=int, default=19)
    # geometria de irradiacion (default [001] eje-c -> plano ab; e1=[100], e2=[010])
    p.add_argument("--e1", type=float, nargs=3, default=[1.0, 0.0, 0.0])
    p.add_argument("--e2", type=float, nargs=3, default=[0.0, 1.0, 0.0])
    # polarizador / analizador
    p.add_argument("--pol-deg", type=float, default=90.0, help="angulo del polarizador (90=cruzado)")
    p.add_argument("--pol-fixed", action="store_true", help="polarizador fijo al cristal (default: co-rota)")
    p.add_argument("--replot", default=None, metavar="M_NPZ",
                   help="re-plotea desde un *_M.npz guardado (sin re-simular)")
    p.add_argument("--title", default="(a) 4th harmonic")
    p.add_argument("--color", default="#ee3b2d", help="color de las trazas (paper: 4to rojo, 5to naranja)")
    p.add_argument("--out", default="outputs/REPLICA_bestparams.png")
    args = p.parse_args()

    if args.replot:                       # solo diseño: usa M guardada
        d = np.load(args.replot)
        Path(args.out).parent.mkdir(parents=True, exist_ok=True)
        plot_paper(d["M"], d["eps"], d["oris"], Path(args.out),
                   title=args.title, color=args.color)
        return

    e1 = np.asarray(args.e1, float); e1 /= np.linalg.norm(e1)
    e2 = np.asarray(args.e2, float); e2 /= np.linalg.norm(e2)
    M, eps, oris = compute_heatmap(
        args.a2, args.M0, args.gamma_tilt, args.grid, args.n_eps, args.n_orient,
        e1, e2, args.pol_deg, not args.pol_fixed)
    # reporta el doble-pico en +-90
    for o in (90.0, -90.0):
        io = int(np.argmin(np.abs(oris - o))); t = M[io] / M[io].max()
        f = lambda x: t[int(np.argmin(np.abs(eps - x)))]
        print(f"[replica] {o:+.0f}deg: I(-0.5)={f(-0.5):.2f} I(0)={f(0):.2f} "
              f"I(+0.5)={f(0.5):.2f} I(+-1)={f(-1):.2f}/{f(1):.2f}")
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    np.savez(args.out.replace(".png", "_M.npz"), M=M, eps=eps, oris=oris)
    plot_paper(M, eps, oris, Path(args.out))


if __name__ == "__main__":
    main()
