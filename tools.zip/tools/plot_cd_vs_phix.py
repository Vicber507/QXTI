#!/usr/bin/env python3
"""Circular dichroism (CD) of HHG harmonics as a function of the
in-plane laser-polarization angle phi_x.

Loads a pre-computed phi_x sweep (one CMD run per angle, each with a
fixed ellipticity) and plots:

  Panel (a)  Helicity-resolved yield of the second harmonic (2omega):
             sigma+ (RCP component, J_x + i J_y) and sigma- (LCP) vs phi_x.

  Panel (b)  Normalized circular dichroism
             CD_n = (Y^+_n - Y^-_n) / (Y^+_n + Y^-_n)
             for n = 1 (omega, gray) and n = 2 (2omega, color) vs phi_x.

The phi_x angle rotates the ellipse of the driving laser within the
crystal plane (the normal of the polarization plane is fixed by thetaz
and phiz). A sign reversal in CD_H2 as phi_x is swept indicates that
the chirality of the second-harmonic emission flips, which is a
topological fingerprint of the Weyl-node sector arrangement.

Usage
-----
    python tools/plot_cd_vs_phix.py                         # default data
    python tools/plot_cd_vs_phix.py --data PATH/harmonic_yield_vs_phix.npz
    python tools/plot_cd_vs_phix.py --out outputs/cd_phix_plot
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

import numpy as np

os.environ.setdefault("MPLCONFIGDIR", "/private/tmp")
os.environ.setdefault("XDG_CACHE_HOME", "/private/tmp")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# ── defaults ──────────────────────────────────────────────────────────────────
_DEFAULT_DATA = (
    PROJECT_ROOT / "outputs" / "sweeps" / "orenstein_112_phix"
    / "harmonic_yield_vs_phix.npz"
)
_DEFAULT_OUT = PROJECT_ROOT / "outputs" / "cd_phix_plot"

# Wong colour-blind safe palette
_C_RPLUS  = "#0072B2"   # blue  – sigma+
_C_RMINUS = "#D55E00"   # red-orange – sigma-
_C_H2     = "#009E73"   # green – CD H2
_C_H1     = "#888888"   # grey  – CD H1
_C_ZERO   = "0.70"


# ── helpers ───────────────────────────────────────────────────────────────────

def _fit_sin2(phix_deg: np.ndarray, cd: np.ndarray):
    """Least-squares fit  A*sin(2*phi + phi0) + C  to CD data."""
    phi = np.deg2rad(phix_deg)
    # linear fit in  [sin2phi, cos2phi, 1]
    X = np.column_stack([np.sin(2 * phi), np.cos(2 * phi), np.ones_like(phi)])
    coeffs, *_ = np.linalg.lstsq(X, cd, rcond=None)
    a, b, c = coeffs
    amplitude = np.hypot(a, b)
    phase_deg = np.rad2deg(np.arctan2(b, a)) / 2   # divide by 2 for sin(2phi+phi0)
    phi_fine = np.linspace(0, 360, 720)
    phi_r = np.deg2rad(phi_fine)
    fit_fine = a * np.sin(2 * phi_r) + b * np.cos(2 * phi_r) + c
    return phi_fine, fit_fine, amplitude, phase_deg, c


# ── main ──────────────────────────────────────────────────────────────────────

def main() -> int:
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument("--data", default=str(_DEFAULT_DATA),
                    help="Path to harmonic_yield_vs_phix.npz")
    ap.add_argument("--out", default=str(_DEFAULT_OUT),
                    help="Output directory for figures and .npz")
    ap.add_argument("--harmonic", type=int, default=2,
                    help="Primary harmonic to highlight in panel (a) (default: 2)")
    ap.add_argument("--no-fit", action="store_true",
                    help="Skip the sin(2phi) fit overlay")
    args = ap.parse_args()

    data_path = Path(args.data)
    out_dir   = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    # ── load ──────────────────────────────────────────────────────────────────
    if not data_path.exists():
        print(f"[CD-phix] data file not found: {data_path}")
        return 1

    d = np.load(data_path, allow_pickle=True)
    phix  = np.asarray(d["phix"],   dtype=float)   # degrees
    h2_R  = np.asarray(d["h2_R"],   dtype=float)
    h2_L  = np.asarray(d["h2_L"],   dtype=float)
    h1_R  = np.asarray(d["h1_R"],   dtype=float)
    h1_L  = np.asarray(d["h1_L"],   dtype=float)
    cd_h2 = np.asarray(d["cd_h2"],  dtype=float)
    cd_h1 = np.asarray(d["cd_h1"],  dtype=float)
    print(f"[CD-phix] loaded {len(phix)} phi_x points from {data_path.name}")
    print(f"[CD-phix]   CD_H2  range: [{cd_h2.min():.3f}, {cd_h2.max():.3f}]")
    print(f"[CD-phix]   CD_H1  range: [{cd_h1.min():.3f}, {cd_h1.max():.3f}]")

    # ── sin(2phi) fits ────────────────────────────────────────────────────────
    phi_fine, fit_h2, amp_h2, ph_h2, off_h2 = _fit_sin2(phix, cd_h2)
    _,        fit_h1, amp_h1, ph_h1, off_h1 = _fit_sin2(phix, cd_h1)
    print(f"[CD-phix]   fit CD_H2: A={amp_h2:.3f}, offset={off_h2:.3f}, "
          f"phase={ph_h2:.1f} deg")
    print(f"[CD-phix]   fit CD_H1: A={amp_h1:.3f}, offset={off_h1:.3f}, "
          f"phase={ph_h1:.1f} deg")

    # ── normalize yields for panel (a) ────────────────────────────────────────
    h2_max = max(h2_R.max(), h2_L.max())
    h2_R_n = h2_R / h2_max
    h2_L_n = h2_L / h2_max

    # ── matplotlib ────────────────────────────────────────────────────────────
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D

    try:
        from qxti.graphics.plot_susceptibility_tensor import apply_paper_style
        apply_paper_style()
    except Exception:
        pass

    fig, axes = plt.subplots(
        2, 1, figsize=(5.0, 7.2),
        gridspec_kw={"height_ratios": [1, 1], "hspace": 0.10},
    )
    ax_yield, ax_cd = axes

    # ── panel (a): helicity-resolved H2 yield ─────────────────────────────────
    ax_yield.fill_between(phix, h2_R_n, alpha=0.18, color=_C_RPLUS)
    ax_yield.fill_between(phix, h2_L_n, alpha=0.18, color=_C_RMINUS)
    ax_yield.plot(phix, h2_R_n, "o-", color=_C_RPLUS,  ms=5, lw=1.8,
                  label=r"$\sigma^+$ ($Y^+_{2\omega}$)")
    ax_yield.plot(phix, h2_L_n, "s-", color=_C_RMINUS, ms=5, lw=1.8,
                  label=r"$\sigma^-$ ($Y^-_{2\omega}$)")

    ax_yield.set_xlim(0, 360)
    ax_yield.set_ylim(bottom=0)
    ax_yield.set_ylabel(r"Yield $Y_{2\omega}$ (normalized)", fontsize=13)
    ax_yield.set_xticklabels([])
    ax_yield.legend(loc="upper right", fontsize=11)
    ax_yield.text(-0.12, 1.02, "(a)", transform=ax_yield.transAxes,
                  fontsize=14, fontweight="bold")

    # shade regions where sigma+ > sigma- (positive CD) vs sigma- > sigma+
    ax_yield.fill_between(
        phix, h2_R_n, h2_L_n,
        where=(h2_R_n >= h2_L_n),
        alpha=0.22, color=_C_RPLUS, label=None,
    )
    ax_yield.fill_between(
        phix, h2_L_n, h2_R_n,
        where=(h2_L_n > h2_R_n),
        alpha=0.22, color=_C_RMINUS, label=None,
    )

    # ── panel (b): CD vs phi_x ────────────────────────────────────────────────
    # zero reference
    ax_cd.axhline(0.0, color=_C_ZERO, lw=1.0, zorder=0)

    # CD H1 (background, grey)
    ax_cd.plot(phix, cd_h1, "^-", color=_C_H1, ms=4.5, lw=1.4,
               alpha=0.7, label=r"$\mathrm{CD}_\omega$", zorder=2)

    # CD H2 (foreground, colour)
    ax_cd.plot(phix, cd_h2, "o-", color=_C_H2, ms=5.5, lw=2.0,
               label=r"$\mathrm{CD}_{2\omega}$", zorder=3)

    # sin(2phi) fit overlays
    if not args.no_fit:
        ax_cd.plot(phi_fine, fit_h2, "--", color=_C_H2, lw=1.3, alpha=0.75,
                   label=(rf"$A\sin(2\phi_x+\phi_0)$,"
                          rf" $A={amp_h2:.2f}$"))
        ax_cd.plot(phi_fine, fit_h1, ":", color=_C_H1, lw=1.2, alpha=0.6,
                   label=None)

    # annotate sign-change regions
    for cross in _zero_crossings(phix, cd_h2):
        ax_cd.axvline(cross, color=_C_H2, lw=0.8, ls=":", alpha=0.55)

    ax_cd.set_xlim(0, 360)
    ax_cd.set_ylim(-1.15, 1.15)
    ax_cd.set_xlabel(r"$\phi_x$ (deg)", fontsize=13)
    ax_cd.set_ylabel(
        r"$\mathrm{CD}(\phi_x) = \dfrac{Y^+ - Y^-}{Y^+ + Y^-}$", fontsize=12
    )
    ax_cd.set_xticks([0, 90, 180, 270, 360])
    ax_cd.legend(loc="lower right", fontsize=10, ncol=1)
    ax_cd.text(-0.12, 1.02, "(b)", transform=ax_cd.transAxes,
               fontsize=14, fontweight="bold")

    # horizontal guidance lines at ±1
    for y in (-1, 1):
        ax_cd.axhline(y, color="0.55", lw=0.7, ls="--")

    fig.suptitle(
        r"Circular dichroism vs in-plane angle $\phi_x$"
        "\n"
        r"WSM (TaAs model, $\Delta=0.5$, (112) plane, $\varepsilon=0.5$)",
        fontsize=12, y=0.995,
    )

    # ── save ──────────────────────────────────────────────────────────────────
    png = out_dir / "cd_vs_phix.png"
    pdf = out_dir / "cd_vs_phix.pdf"
    fig.savefig(png, dpi=300, facecolor="white", bbox_inches="tight")
    fig.savefig(pdf,           facecolor="white", bbox_inches="tight")
    plt.close(fig)
    print(f"[CD-phix] wrote {png}")
    print(f"[CD-phix] wrote {pdf}")

    # ── save summary npz ──────────────────────────────────────────────────────
    np.savez_compressed(
        out_dir / "cd_vs_phix.npz",
        phix=phix,
        cd_h1=cd_h1, cd_h2=cd_h2,
        h1_R=h1_R, h1_L=h1_L,
        h2_R=h2_R, h2_L=h2_L,
        fit_phi=phi_fine, fit_cd_h2=fit_h2, fit_cd_h1=fit_h1,
        amp_h2=amp_h2, amp_h1=amp_h1,
        offset_h2=off_h2, offset_h1=off_h1,
    )
    print(f"[CD-phix] wrote {out_dir/'cd_vs_phix.npz'}")
    return 0


def _zero_crossings(x: np.ndarray, y: np.ndarray) -> list[float]:
    """Linear interpolation of zero crossings in y(x)."""
    crossings = []
    for i in range(len(y) - 1):
        if y[i] * y[i + 1] < 0:
            t = -y[i] / (y[i + 1] - y[i])
            crossings.append(float(x[i] + t * (x[i + 1] - x[i])))
    return crossings


if __name__ == "__main__":
    raise SystemExit(main())
