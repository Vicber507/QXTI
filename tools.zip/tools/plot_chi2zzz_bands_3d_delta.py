#!/usr/bin/env python3
"""3D band structure E(ky, kz) at kx*a=pi/2 for each Delta — two central bands only.

One figure per Delta value, saved individually.
Axes: kya (x), kza (y), E in eV (z).
"""
from __future__ import annotations

import os, sys, importlib.util
from pathlib import Path

import numpy as np

os.environ.setdefault("MPLCONFIGDIR", "/private/tmp")
os.environ.setdefault("XDG_CACHE_HOME", "/private/tmp")
PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

_EV = 27.211386245988
OUT = Path("outputs/susceptibility_maps/wsm_orenstein/bands_3d_delta")

PALETTE = (
    "#59819E",
    "#7C7AA2",
    "#F67E7D",
    "#FFC0A7",
    "#6CC2BD",
    "#4A4A4A",
)
DELTAS = (0.5, 0.375, 0.25, 0.125, 0.0)


def main():
    spec = importlib.util.spec_from_file_location(
        "wsm_o", PROJECT_ROOT / "models" / "wsm_orenstein.py")
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from qxti.graphics.plot_susceptibility_tensor import apply_paper_style

    p_base = mod.default_params()
    a = float(p_base["a"])
    kx_fixed = np.pi / (2.0 * a)   # kx*a = pi/2

    N = 80   # grid per axis — enough for smooth surface
    ky_vals = np.linspace(-np.pi/4 / a, np.pi/4 / a, N)
    kz_vals = np.linspace(-np.pi/4 / a, np.pi/4 / a, N)
    KYA, KZA = np.meshgrid(ky_vals * a, kz_vals * a, indexing="ij")   # (N, N)

    OUT.mkdir(parents=True, exist_ok=True)

    for delta, color in zip(DELTAS, PALETTE):
        p = dict(p_base); p["Delta"] = float(delta)
        print(f"[bands-3d] Delta={delta} ...", flush=True)

        E_lower = np.empty((N, N))
        E_upper = np.empty((N, N))
        for i, ky in enumerate(ky_vals):
            for j, kz in enumerate(kz_vals):
                e = np.linalg.eigvalsh(mod.H(kx_fixed, ky, kz, p)) * _EV
                E_lower[i, j] = e[1]   # band 2 (lower crossing)
                E_upper[i, j] = e[2]   # band 3 (upper crossing)

        apply_paper_style()
        fig = plt.figure(figsize=(9.5, 8.0))
        ax = fig.add_subplot(111, projection="3d")

        # Semi-transparent surfaces
        alpha_surf = 0.72
        ax.plot_surface(KYA, KZA, E_lower, color=color, alpha=alpha_surf,
                        linewidth=0, antialiased=True, shade=True)
        ax.plot_surface(KYA, KZA, E_upper, color=color, alpha=alpha_surf,
                        linewidth=0, antialiased=True, shade=True)

        # E=0 reference plane
        Z0 = np.zeros_like(KYA)
        ax.plot_surface(KYA, KZA, Z0, color="0.60", alpha=0.12,
                        linewidth=0, shade=False)

        ax.set_xlabel(r"$k_y a$", fontsize=17, labelpad=10)
        ax.set_ylabel(r"$k_z a$", fontsize=17, labelpad=10)
        ax.set_zlabel(r"$E\;(\mathrm{eV})$", fontsize=17, labelpad=8)
        ax.set_title(rf"$\Delta={delta:g}$,  $k_x a=\pi/2$", fontsize=19, pad=8)
        ax.tick_params(labelsize=13)

        # pi-fraction ticks
        pi4_ticks = [-np.pi/4, 0.0, np.pi/4]
        pi4_labels = [r"$-\pi/4$", r"$0$", r"$\pi/4$"]
        ax.set_xticks(pi4_ticks); ax.set_xticklabels(pi4_labels, fontsize=12)
        ax.set_yticks(pi4_ticks); ax.set_yticklabels(pi4_labels, fontsize=12)
        ax.set_zlim(-0.5, 0.5)

        # clean panes
        for axis in (ax.xaxis, ax.yaxis, ax.zaxis):
            axis.pane.set_facecolor((1, 1, 1, 0.0))
            axis.pane.set_edgecolor((0.8, 0.8, 0.8, 1.0))
            axis._axinfo["grid"].update(color=(0.82, 0.82, 0.86),
                                        linewidth=0.5, linestyle="-")

        ax.view_init(elev=22, azim=-55)
        fig.tight_layout()

        delta_str = f"{delta:g}".replace(".", "p")
        f = OUT / f"bands_3d_delta_{delta_str}.png"
        fig.savefig(f, dpi=200, facecolor="white", bbox_inches="tight")
        plt.close(fig)
        print(f"[bands-3d] wrote {f}")


if __name__ == "__main__":
    main()
