"""Fast mesh-vectorized perturbative HHG for NatPhys_TaAs — enables 120^3 at T2=110.

The per-k analytic recursion (rho_order_s) costs ~7^(s-1) diagonalizations PER
k-point, so order 4 at 120^3 is ~12 h.  This does the SAME length-gauge recursion
but VECTORIZED over the whole k-mesh: build rho^(1) on all k at once, take ONE
Wilson-link covariant mesh gradient (np.roll between neighbours) per order to get
rho^(2), rho^(3), rho^(4) -> cost O(orders * Nk), feasible at 120^3 in minutes.

Covariant derivative D_k rho = grad_k rho - i[A, rho] is obtained IN ONE SHOT from
the Wilson-transported finite difference (Wp @ rho(k') @ Wp^dag), so NO separate
commutator is added (matches the rho_order_s / CMD fix; avoids the double-count
that cancels the intraband/population channel).

Uses antelope's own broadening (T2=110, T1 off) and the RCP field.  Sweeps k-grids
to show convergence of harmonics 1..4 toward antelope's 300^3 result.

Usage:
    python tools/fast_hhg_mesh_taas.py 24 48 72 96 120
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# ---- model + run parameters (match RCP/inputParam.cfg) ----------------------
_AU = 0.529177210903
A0 = 3.4 / _AU
T, MY, MZ, DELTA = 0.03, 1.0, 5.0, 0.5
W0 = 0.0114
E0 = 0.0005
T1 = np.inf          # antelope T1 = -1 -> infinite (no population decay)
T2 = 110.0           # antelope T2 = 110 (coherence dephasing only)
GAMMA_COH = 1.0 / T2
GAMMA_POP = 0.0 if not np.isfinite(T1) else 1.0 / T1
GAMMA = GAMMA_COH    # (kept for the header print)
MU = 0.0
TEMP = 0.0
MAX_ORDER = 4
NB = 4
DIM = 3
KMAX = np.pi / A0
DKVEL = 1e-4


def H_batch(kx, ky, kz):
    """Vectorized 4x4 H over arrays kx,ky,kz -> (..., 4, 4)."""
    sy = np.sin(ky * A0); cy = np.cos(ky * A0); sz = np.sin(kz * A0)
    M = T * np.cos(kx * A0) + T * MY * (1 - np.cos(ky * A0)) + T * MZ * (1 - np.cos(kz * A0))
    dc = DELTA * T * cy
    z = np.zeros_like(M, dtype=np.complex128)
    Hm = np.empty(M.shape + (4, 4), dtype=np.complex128)
    Hm[..., 0, 0] = z; Hm[..., 0, 1] = T * sz; Hm[..., 0, 2] = M - 1j * T * sy; Hm[..., 0, 3] = -1j * dc
    Hm[..., 1, 0] = T * sz; Hm[..., 1, 1] = z; Hm[..., 1, 2] = -1j * dc; Hm[..., 1, 3] = M - 1j * T * sy
    Hm[..., 2, 0] = M + 1j * T * sy; Hm[..., 2, 1] = 1j * dc; Hm[..., 2, 2] = z; Hm[..., 2, 3] = -T * sz
    Hm[..., 3, 0] = 1j * dc; Hm[..., 3, 1] = M + 1j * T * sy; Hm[..., 3, 2] = -T * sz; Hm[..., 3, 3] = z
    return Hm


def _fermi(E):
    if TEMP < 1e-15:
        return (E <= MU + 1e-14).astype(float)
    return 1.0 / (np.exp((E - MU) / TEMP) + 1.0)


def run_grid(N, num_valence=2, field=None):
    """Return dict with harmonic currents J^(s)(s*w0) (3-vectors) for s=1..MAX_ORDER."""
    t0 = time.perf_counter()
    shifted = (np.arange(N) + 0.5) / N - 0.5      # Monkhorst-Pack shifted, in [-.5,.5)
    kax = shifted * 2.0 * KMAX
    KX, KY, KZ = np.meshgrid(kax, kax, kax, indexing="ij")     # (N,N,N)
    shape = (N, N, N)
    nk = N ** 3
    dk_grid = 2.0 * KMAX / N
    w_k = (2.0 * KMAX) ** DIM / nk                # BZ quadrature weight (uniform)

    # band data on the mesh
    Hm = H_batch(KX, KY, KZ).reshape(nk, NB, NB)
    E, U = np.linalg.eigh(Hm)                      # E:(nk,NB) U:(nk,NB,NB)
    Udag = np.conj(np.swapaxes(U, -1, -2))
    del Hm

    # velocities in band basis (central FD), Berry connection
    vel = []
    for a in range(DIM):
        sh = [np.zeros_like(KX) for _ in range(3)]
        sh[a] = np.full_like(KX, DKVEL)
        Hp = H_batch(KX + sh[0], KY + sh[1], KZ + sh[2]).reshape(nk, NB, NB)
        Hmn = H_batch(KX - sh[0], KY - sh[1], KZ - sh[2]).reshape(nk, NB, NB)
        vel.append(Udag @ ((Hp - Hmn) / (2 * DKVEL)) @ U)
        del Hp, Hmn
    f = _fermi(E)
    # override occupation by band INDEX to match antelope UniformValence (Nval bands)
    if num_valence is not None:
        f = np.zeros_like(E)
        f[:, :num_valence] = 1.0
    eps = E[:, :, None] - E[:, None, :]           # eps_mn = E_m - E_n
    fmn = f[:, None, :] - f[:, :, None]           # f_n - f_m  (index [.,m,n])
    offdiag = ~np.eye(NB, dtype=bool)
    valid = offdiag[None] & (np.abs(eps) > 1e-12)
    with np.errstate(divide="ignore", invalid="ignore"):
        inv_eps = np.where(valid, 1.0 / eps, 0.0)
        dfde = (-f * (1.0 - f) / TEMP) if TEMP > 1e-15 else np.zeros_like(f)
    A = [1j * vel[a] * inv_eps for a in range(DIM)]

    # element-wise relaxation Gamma_mn: population decay 1/T1 on the diagonal,
    # coherence decay 1/T2 off-diagonal (antelope uses T1=inf, T2=110).
    Gamma_mat = np.full((NB, NB), GAMMA_COH)
    np.fill_diagonal(Gamma_mat, GAMMA_POP)          # (NB,NB)
    iGamma = 1j * Gamma_mat[None]                    # (1,NB,NB)

    # RCP field: complex e^{-iwt} amplitude, |E| = E0, circular in xy-plane
    if field is None:
        Evec = (E0 / np.sqrt(2.0)) * np.array([1.0, 1j, 0.0], dtype=np.complex128)  # RCP default
    else:
        Evec = np.asarray(field, dtype=np.complex128)   # arbitrary drive (e.g. [0,0,Ez])

    diag = np.arange(NB)
    U_mesh = U.reshape(*shape, NB, NB)   # kept for on-the-fly Wilson links (saves ~5 GB)

    # ---- rho^(1)(w0): field-contracted source E . D_k rho^(0) --------------
    ow1_coh = W0 + 1j * GAMMA_COH
    ow1_pop = W0 + 1j * GAMMA_POP
    rho1 = np.zeros((nk, NB, NB), dtype=np.complex128)
    for c in range(DIM):
        if abs(Evec[c]) < 1e-40:
            continue
        r = np.where(valid, (A[c] * fmn) * inv_denom(ow1_coh, eps, valid), 0.0)
        diag_src = (-1j) * dfde * np.real(vel[c][:, diag, diag])
        r[:, diag, diag] += diag_src / ow1_pop
        rho1 += Evec[c] * r
    rhos = {1: rho1}
    del A   # only needed for rho^(1); the covariant mesh gradient handles the connection

    # ---- rho^(s)(s*w0), s>=2: mesh covariant gradient recursion ------------
    def cov_grad(R, b):
        # recompute Wilson links inline (avoids storing 12 (nk,4,4) arrays)
        Up = np.roll(U_mesh, -1, axis=b).reshape(nk, NB, NB)
        Un = np.roll(U_mesh, +1, axis=b).reshape(nk, NB, NB)
        wp = Udag @ Up; wm = Udag @ Un
        Rm = R.reshape(*shape, NB, NB)
        Rp = np.roll(Rm, -1, axis=b).reshape(nk, NB, NB)
        Rn = np.roll(Rm, +1, axis=b).reshape(nk, NB, NB)
        # Wilson-transported central difference = full covariant derivative D_b R
        return (wp @ Rp @ np.conj(np.swapaxes(wp, -1, -2))
                - wm @ Rn @ np.conj(np.swapaxes(wm, -1, -2))) / (2.0 * dk_grid)

    for s in range(2, MAX_ORDER + 1):
        src = np.zeros((nk, NB, NB), dtype=np.complex128)
        for b in range(DIM):
            if abs(Evec[b]) < 1e-40:
                continue
            src += Evec[b] * cov_grad(rhos[s - 1], b)     # NO extra -i[A,rho]!
        with np.errstate(divide="ignore", invalid="ignore"):
            denom = s * W0 + iGamma - eps                  # Gamma_mn per element (T1 vs T2)
            rhos[s] = np.where(np.abs(denom) > 0, src / denom, 0.0)

    # ---- harmonic currents J^(s)_i = sum_k w_k Tr[(-v_i) rho^(s)] ----------
    J = {}
    for s in range(1, MAX_ORDER + 1):
        Js = np.zeros(3, dtype=np.complex128)
        for i in range(DIM):
            tr = np.einsum("kmn,knm->k", -vel[i], rhos[s], optimize=True)
            Js[i] = np.sum(tr) * w_k
        J[s] = Js
    dt = time.perf_counter() - t0
    return {"N": N, "nk": nk, "J": J, "seconds": dt, "dk_grid": dk_grid}


def inv_denom(ow, eps, valid):
    with np.errstate(divide="ignore", invalid="ignore"):
        return np.where(valid, 1.0 / (ow - eps), 0.0)


def main():
    grids = [int(x) for x in sys.argv[1:]] or [24, 48, 72]
    print(f"NatPhys_TaAs RCP — fast mesh HHG (T2={T2}, gamma={GAMMA:.4f}, E0={E0}, RCP)")
    print(f"BZ half-width pi/a0 = {KMAX:.4f}, w0 = {W0}\n")
    print(f"{'grid':>6} {'Nk':>10} {'t(s)':>7}  |  " + "  ".join(f"H{s}/H1" for s in range(1, MAX_ORDER + 1)))
    rows = []
    for N in grids:
        res = run_grid(N)
        J = res["J"]
        # harmonic intensity = |J^(s)|^2 (total current)
        H = np.array([np.sum(np.abs(J[s]) ** 2) for s in range(1, MAX_ORDER + 1)])
        ratios = H / H[0]
        rows.append((N, ratios, J))
        print(f"{N:>6} {res['nk']:>10} {res['seconds']:>7.1f}  |  "
              + "  ".join(f"{x:8.2e}" for x in ratios))
    # antelope reference (from tools/compare_taas_qxti_vs_antelope.py, |J|^2)
    print("\nantelope 300^3 (T2=110, no-pert.):  " +
          "  ".join(f"{x:8.2e}" for x in [1.0, 5.11e-7, 1.84e-05, 1.11e-10]))
    print("\nConvergencia: mira si H2/H1, H3/H1 se ESTABILIZAN al subir N y se")
    print("acercan a antelope. (N>=~100 resuelve el ancho gamma cerca de los nodos.)")


if __name__ == "__main__":
    main()
