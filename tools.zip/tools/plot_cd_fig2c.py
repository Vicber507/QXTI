#!/usr/bin/env python3
"""Reproduce Wu/Orenstein (Nat. Phys. 2017) Fig. 2c: SHG circular dichroism
vs analyzer angle on the TaAs (112) surface, using CMD theory runs.

The script:
  1. Loads J(2w) from two CW-limit CMD runs (ellip=+1 and ellip=-1, ncycles=50).
  2. Computes CD(theta2) = I_+(theta2) - I_-(theta2) by analytically projecting
     J(2w) onto the rotating analyzer direction a(theta2) in the (112) plane.
  3. Shows a Fourier decomposition into sin(2theta2) and cos(2theta2) to
     expose the symmetry of the model.
  4. Explains why the result differs from the pure sin(2theta2) of Fig. 2c.

Key physics: Wu et al. SI Eq. 7 predicts CD ∝ Im{d15 d33*} sin(2theta2)
assuming 4mm point-group symmetry (chi_zxx = chi_zyy). Our model has mm2
symmetry (a SUBSET of 4mm, as noted in the paper), so chi_zxx != chi_zyy.
This introduces a cos(2theta2) component alongside the sin(2theta2) term.
To obtain the pure sin(2theta2) of the real crystal, the model would need
mz = my (isotropic xy hopping), which enforces chi_zxx = chi_zyy.
"""
from __future__ import annotations
import os, sys
from pathlib import Path
import configparser
import numpy as np

os.environ.setdefault("MPLCONFIGDIR", "/private/tmp")
os.environ.setdefault("XDG_CACHE_HOME", "/private/tmp")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# Crystal axes of the (112) surface (paper convention)
E1 = np.array([1.,  1., -1.]) / np.sqrt(3.)   # [1,1,-1]  theta2=0
E2 = np.array([1., -1.,  0.]) / np.sqrt(2.)   # [1,-1,0]  theta2=90 deg
AU_TO_EV = 27.211386245988

_CW_DIR = PROJECT_ROOT / "outputs/sweeps/orenstein_112_cd_cw"
_OUT    = PROJECT_ROOT / "outputs/cd_fig2c"


def _load_J2(run_dir: Path) -> tuple[np.ndarray, float]:
    cfg = configparser.ConfigParser(inline_comment_prefixes=("#",))
    cfg.optionxform = str
    cfg.read(run_dir / "input.cfg")
    omega0 = float(cfg["laser"]["omega"])
    d = np.load(run_dir / "cmd/data/current_spectrum.npz", allow_pickle=True)
    omega = np.asarray(d["omega_axis"], dtype=float)
    spec  = np.asarray(d["current_spectrum"], dtype=complex)
    idx   = int(np.argmin(np.abs(omega - 2.0 * omega0)))
    return spec[idx], omega0


def _cd_curve(Jp, Jm, theta):
    ct, st = np.cos(theta), np.sin(theta)
    ap = ct * np.dot(E1, Jp) + st * np.dot(E2, Jp)
    am = ct * np.dot(E1, Jm) + st * np.dot(E2, Jm)
    return np.abs(ap)**2 - np.abs(am)**2


def _fourier_components(theta_rad, y):
    """Return (A_sin, A_cos, A, phase_deg) of the 2-theta Fourier component."""
    s2 = np.sin(2 * theta_rad)
    c2 = np.cos(2 * theta_rad)
    X  = np.column_stack([s2, c2])
    coeff, *_ = np.linalg.lstsq(X, y, rcond=None)
    a_s, a_c = coeff
    A = float(np.hypot(a_s, a_c))
    phase = float(np.degrees(np.arctan2(a_c, a_s)))
    return a_s, a_c, A, phase


def main() -> int:
    out_dir = _OUT
    out_dir.mkdir(parents=True, exist_ok=True)

    # ── load J(2w) from CW runs ───────────────────────────────────────────────
    Jp, omega0 = _load_J2(_CW_DIR / "001_ellip=1")
    Jm, _      = _load_J2(_CW_DIR / "000_ellip=-1")

    print(f"[fig2c] omega0 = {omega0*AU_TO_EV:.4f} eV")
    print(f"[fig2c] J(2w) ellip=+1 : {Jp}")
    print(f"[fig2c] J(2w) ellip=-1 : {Jm}")
    print()

    # ── CW symmetry check ─────────────────────────────────────────────────────
    print("=== CW symmetry check ===")
    print(f"  Jz(+) = {Jp[2]:.4e}   Jz(-) = {Jm[2]:.4e}")
    print(f"  4mm predicts Jz(+) = Jz(-) -> satisfied? "
          f"{np.allclose(Jp[2], Jm[2], rtol=0.05)}")
    print(f"  mm2 allows Jz(+) != Jz(-): diff = "
          f"{abs(Jp[2]-Jm[2])/abs(Jp[2]):.1%}")
    print()

    # ── CD curve ──────────────────────────────────────────────────────────────
    theta     = np.linspace(0, 2*np.pi, 721)
    theta_deg = np.degrees(theta)
    cd_raw    = _cd_curve(Jp, Jm, theta)
    norm      = float(np.max(np.abs(cd_raw))) or 1.0
    cd_n      = cd_raw / norm

    a_sin, a_cos, amp, phase = _fourier_components(theta, cd_n)
    phi_fine   = np.linspace(0, 2*np.pi, 1440)
    fit_fine   = a_sin*np.sin(2*phi_fine) + a_cos*np.cos(2*phi_fine)
    sin_only   = a_sin * np.sin(2*phi_fine)
    cos_only   = a_cos * np.cos(2*phi_fine)

    print("=== Fourier decomposition of CD(theta2)/|peak| ===")
    print(f"  Total amplitude  A = sqrt(Asin²+Acos²) = {amp:.4f}")
    print(f"  sin(2theta2) amplitude A_sin = {a_sin:.4f}")
    print(f"  cos(2theta2) amplitude A_cos = {a_cos:.4f}")
    print(f"  Phase phi0  = {phase:.1f} deg")
    print()
    print(f"  Paper (4mm): pure sin(2theta2),  A_cos = 0")
    print(f"  Our model (mm2): A_sin={a_sin:.3f}, A_cos={a_cos:.3f}")
    print(f"  -> cos component is {abs(a_cos/a_sin):.1f}x the sin component")
    print()

    # ── plot ──────────────────────────────────────────────────────────────────
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    try:
        from qxti.graphics.plot_susceptibility_tensor import apply_paper_style
        apply_paper_style()
    except Exception:
        pass

    C_DATA  = "#5B4A9B"   # purple  – full CD
    C_SIN   = "#009E73"   # green   – sin component
    C_COS   = "#D55E00"   # orange  – cos component
    C_FIT   = "#CC79A7"   # pink    – total fit

    fig, (ax_main, ax_fourier) = plt.subplots(
        2, 1, figsize=(5.5, 7.2),
        gridspec_kw={"height_ratios": [1.4, 1], "hspace": 0.10},
    )

    # ── panel (a): full CD curve ──────────────────────────────────────────────
    ax_main.axhline(0, color="0.65", lw=0.9, zorder=0)
    for y in (-1, 1):
        ax_main.axhline(y, color="0.75", lw=0.55, ls="--", zorder=0)

    ax_main.plot(theta_deg, cd_n, "-", color=C_DATA, lw=2.2,
                 label=r"$\mathrm{CD}(\theta_2)$  [simulation, mm2]")
    ax_main.plot(np.degrees(phi_fine), fit_fine, ":", color=C_FIT, lw=1.5,
                 label=rf"$A_s\sin 2\theta_2 + A_c\cos 2\theta_2$  ($A={amp:.2f}$)")

    # Mark zero crossings
    for i in range(len(cd_n)-1):
        if cd_n[i]*cd_n[i+1] < 0:
            xc = theta_deg[i] - cd_n[i]*(theta_deg[i+1]-theta_deg[i])/(cd_n[i+1]-cd_n[i])
            ax_main.axvline(xc, color=C_DATA, lw=0.8, ls=":", alpha=0.5)

    ax_main.set_xlim(0, 360)
    ax_main.set_ylim(-1.25, 1.25)
    ax_main.set_xticklabels([])
    ax_main.set_ylabel(
        r"$\mathrm{CD}(\theta_2)\;/\;|\mathrm{peak}|$", fontsize=12)
    ax_main.legend(fontsize=10, loc="lower right")
    ax_main.text(-0.12, 1.02, "(a)", transform=ax_main.transAxes,
                 fontsize=14, fontweight="bold")

    # Annotation: mm2 vs 4mm
    ax_main.text(0.03, 0.97,
        r"$\mathbf{mm2}$ model: $\chi_{zxx}\neq\chi_{zyy}$" "\n"
        r"$\Rightarrow$ CD has cos$(2\theta_2)$ component",
        transform=ax_main.transAxes, fontsize=9,
        va="top", ha="left",
        bbox=dict(fc="white", ec="0.75", pad=3, alpha=0.85))

    # ── panel (b): Fourier components ────────────────────────────────────────
    ax_fourier.axhline(0, color="0.65", lw=0.9, zorder=0)

    ax_fourier.plot(np.degrees(phi_fine), sin_only, "-", color=C_SIN, lw=2.0,
                    label=rf"$A_s\sin 2\theta_2$  ($A_s={a_sin:+.3f}$)"
                          "\n" r"(Wu et al. Fig. 2c term)")
    ax_fourier.plot(np.degrees(phi_fine), cos_only, "-", color=C_COS, lw=2.0,
                    label=rf"$A_c\cos 2\theta_2$  ($A_c={a_cos:+.3f}$)"
                          "\n" r"(absent in 4mm, present in mm2)")

    ax_fourier.set_xlim(0, 360)
    ax_fourier.set_ylim(-1.05, 1.05)
    ax_fourier.set_xticks([0, 90, 180, 270, 360])
    ax_fourier.set_xticklabels(
        [r"$0°$"+"\n"+r"$[1,1,\bar{1}]$",
         r"$90°$"+"\n"+r"$[1,\bar{1},0]$",
         r"$180°$", r"$270°$", r"$360°$"], fontsize=9)
    ax_fourier.set_xlabel(r"analyzer angle $\theta_2$ in (112) plane", fontsize=12)
    ax_fourier.set_ylabel("Fourier components", fontsize=12)
    ax_fourier.legend(fontsize=9.5, loc="lower right", ncol=1)
    ax_fourier.text(-0.12, 1.02, "(b)", transform=ax_fourier.transAxes,
                    fontsize=14, fontweight="bold")

    for xv in [0, 90, 180, 270, 360]:
        ax_main.axvline(xv, color="0.80", lw=0.6, ls=":", zorder=0)
        ax_fourier.axvline(xv, color="0.80", lw=0.6, ls=":", zorder=0)

    fig.suptitle(
        r"SHG circular dichroism  vs  analyzer angle $\theta_2$  —  TaAs (112)"
        "\n"
        r"CMD theory (ncycles=50, CW limit), $\gamma=124$ meV, $\Delta=0.5$",
        fontsize=10.5, y=0.998)

    png = out_dir / "cd_fig2c.png"
    pdf = out_dir / "cd_fig2c.pdf"
    fig.savefig(png, dpi=300, facecolor="white", bbox_inches="tight")
    fig.savefig(pdf,           facecolor="white", bbox_inches="tight")
    plt.close(fig)
    print(f"[fig2c] wrote {png}")
    print(f"[fig2c] wrote {pdf}")

    np.savez_compressed(out_dir / "cd_fig2c.npz",
        theta2_deg=theta_deg, cd_normalized=cd_n,
        a_sin=a_sin, a_cos=a_cos, amplitude=amp, phase_deg=phase)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
