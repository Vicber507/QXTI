#!/usr/bin/env python3
"""Interactive 3D band structure HTML — two crossing bands E(ky,kz) at kxa=pi/2.

One HTML file per Delta, fully self-contained and rotatable in the browser.
Uses Plotly for interactive 3D surfaces.
"""
from __future__ import annotations

import os, sys, importlib.util
from pathlib import Path

import numpy as np

os.environ.setdefault("MPLCONFIGDIR", "/private/tmp")
os.environ.setdefault("XDG_CACHE_HOME", "/private/tmp")
PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

_EV = 27.211386245988
OUT = Path("outputs/susceptibility_maps/wsm_orenstein/bands_3d_delta")

PALETTE = (
    "#59819E",
    "#7C7AA2",
    "#F67E7D",
    "#FFC0A7",
    "#6CC2BD",
    "#4A4A4A",
)
DELTAS = (0.5, 0.375, 0.25, 0.125, 0.0)


def hex_to_rgba(hex_color: str, alpha: float = 0.75) -> str:
    h = hex_color.lstrip("#")
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return f"rgba({r},{g},{b},{alpha})"


def main():
    spec = importlib.util.spec_from_file_location(
        "wsm_o", PROJECT_ROOT / "models" / "wsm_orenstein.py")
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)

    import plotly.graph_objects as go

    p_base = mod.default_params()
    a = float(p_base["a"])
    kx_fixed = np.pi / (2.0 * a)

    N = 100
    ky_vals = np.linspace(-np.pi/4 / a, np.pi/4 / a, N)
    kz_vals = np.linspace(-np.pi/4 / a, np.pi/4 / a, N)
    KYA, KZA = np.meshgrid(ky_vals * a, kz_vals * a, indexing="ij")

    OUT.mkdir(parents=True, exist_ok=True)

    for delta, color in zip(DELTAS, PALETTE):
        p = dict(p_base); p["Delta"] = float(delta)
        print(f"[bands-3d-html] Delta={delta} ...", flush=True)

        E_lower = np.empty((N, N))
        E_upper = np.empty((N, N))
        for i, ky in enumerate(ky_vals):
            for j, kz in enumerate(kz_vals):
                e = np.linalg.eigvalsh(mod.H(kx_fixed, ky, kz, p)) * _EV
                E_lower[i, j] = e[1]
                E_upper[i, j] = e[2]

        surf_color = hex_to_rgba(color, 0.80)
        surf_color_dark = hex_to_rgba(color, 0.40)

        traces = [
            go.Surface(
                x=KYA, y=KZA, z=E_lower,
                colorscale=[[0, surf_color_dark], [1, surf_color]],
                showscale=False,
                opacity=0.82,
                name=f"Band 2 (Δ={delta})",
                contours=dict(
                    z=dict(show=True, usecolormap=False,
                           color="white", width=1, highlightwidth=1)
                ),
            ),
            go.Surface(
                x=KYA, y=KZA, z=E_upper,
                colorscale=[[0, surf_color_dark], [1, surf_color]],
                showscale=False,
                opacity=0.82,
                name=f"Band 3 (Δ={delta})",
                contours=dict(
                    z=dict(show=True, usecolormap=False,
                           color="white", width=1, highlightwidth=1)
                ),
            ),
            # E=0 reference plane
            go.Surface(
                x=KYA, y=KZA,
                z=np.zeros_like(KYA),
                colorscale=[[0, "rgba(160,160,160,0.12)"],
                            [1, "rgba(160,160,160,0.12)"]],
                showscale=False,
                opacity=0.15,
                name="E = 0",
            ),
        ]

        pi4 = np.pi / 4
        layout = go.Layout(
            title=dict(
                text=f"Weyl bands  Δ={delta},  k<sub>x</sub>a = π/2",
                font=dict(size=22),
                x=0.5,
            ),
            scene=dict(
                xaxis=dict(
                    title=dict(text="k<sub>y</sub>a", font=dict(size=18)),
                    tickvals=[-pi4, 0, pi4],
                    ticktext=["-π/4", "0", "π/4"],
                    tickfont=dict(size=14),
                    range=[-pi4, pi4],
                ),
                yaxis=dict(
                    title=dict(text="k<sub>z</sub>a", font=dict(size=18)),
                    tickvals=[-pi4, 0, pi4],
                    ticktext=["-π/4", "0", "π/4"],
                    tickfont=dict(size=14),
                    range=[-pi4, pi4],
                ),
                zaxis=dict(
                    title=dict(text="E (eV)", font=dict(size=18)),
                    tickfont=dict(size=14),
                    range=[-0.5, 0.5],
                ),
                bgcolor="white",
                camera=dict(eye=dict(x=1.6, y=-1.6, z=0.9)),
                aspectmode="cube",
            ),
            paper_bgcolor="white",
            plot_bgcolor="white",
            width=850,
            height=750,
            margin=dict(l=20, r=20, t=60, b=20),
        )

        fig = go.Figure(data=traces, layout=layout)

        delta_str = f"{delta:g}".replace(".", "p")
        f = OUT / f"bands_3d_delta_{delta_str}.html"
        fig.write_html(str(f), include_plotlyjs="cdn", full_html=True)
        print(f"[bands-3d-html] wrote {f}")


if __name__ == "__main__":
    main()
