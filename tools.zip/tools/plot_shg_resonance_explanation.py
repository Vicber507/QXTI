#!/usr/bin/env python3
"""Physical explanation plot for the giant SHG in TaAs Weyl semimetal.

Shows THREE panels:
  (a) sigma^(1)_zz(omega) — linear absorption; peaks at the optical gap
  (b) |chi^(2)_zzz(omega_drive)| — SHG; peaks when 2*omega_drive = optical gap
  (c) Band gap distribution rho(epsilon) = JDOS — shows the optical gap peak

The key: chi^(2) peaks when 2*omega_drive falls on the same optical resonance
that sigma^(1) peaks at. This is the TWO-PHOTON OUTPUT RESONANCE.
"""
from __future__ import annotations

import os, sys
from dataclasses import replace
from pathlib import Path

import numpy as np

os.environ.setdefault("MPLCONFIGDIR", "/private/tmp")
os.environ.setdefault("XDG_CACHE_HOME", "/private/tmp")
PROJECT_ROOT = Path(__file__).resolve().parents[1]
for _p in (PROJECT_ROOT, PROJECT_ROOT / "tools"):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

_EV = 27.211386245988
OUT = Path("outputs/susceptibility_maps/wsm_orenstein")

# same palette
COL_SIG1 = "#59819E"
COL_CHI2 = "#F67E7D"
COL_JDOS = "#7C7AA2"


def main():
    from qxti.core.config import QXTIConfig
    from qxti.core.simulation import QXTISimulation
    from qxti.analytics.theory_response import (
        build_k_integration_weights, compute_linear_response_spectrum)
    from _shg_tensor_gridbased import order2_full_tensor_spectrum
    import importlib.util

    cfg = QXTIConfig.from_file("inputs/inputParams.wsm_orenstein.cfg")
    cfg = replace(cfg, kgrid=replace(cfg.kgrid, k_points=(40, 40, 40)))

    nw = 250
    omega = np.linspace(0.05/_EV, 2.5/_EV, nw)
    e_ev  = omega * _EV

    print("[shg-expl] sigma1 ...")
    res = compute_linear_response_spectrum(cfg, omega, progress=False)
    sigma1_zz = np.abs(res["sigma"][:, 2, 2])

    print("[shg-expl] chi2 ...")
    sim = QXTISimulation(config=cfg)
    ham = sim.build_hamiltonian(); kg = sim.build_kgrid(ham)
    wts = build_k_integration_weights(cfg, hamiltonian=ham, kgrid=kg)
    sigma2 = order2_full_tensor_spectrum(ham, kg, omega, wts,
                                          cfg.susceptibility_solver, progress=False)
    chi2_zzz = np.abs(sigma2[:, 2, 2, 2] / (2j * omega))

    # JDOS: histogram of all interband gaps at every k-point
    print("[shg-expl] JDOS ...")
    spec = importlib.util.spec_from_file_location(
        "wsm_o", PROJECT_ROOT / "models" / "wsm_orenstein.py")
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    p = mod.default_params()
    N_jdos = 30
    kvals = np.linspace(-np.pi, np.pi, N_jdos, endpoint=False) + np.pi/N_jdos
    gaps = []
    for kx in kvals:
        for ky in kvals:
            for kz in kvals:
                e = np.linalg.eigvalsh(mod.H(kx, ky, kz, p)) * _EV
                # all interband gaps
                for i in range(4):
                    for j in range(i+1, 4):
                        gaps.append(e[j] - e[i])
    gaps = np.array(gaps)
    jdos_bins = np.linspace(0.0, 2.6, 120)
    jdos, jdos_e = np.histogram(gaps, bins=jdos_bins, density=True)
    jdos_e_mid = 0.5*(jdos_e[:-1] + jdos_e[1:])

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from qxti.graphics.plot_susceptibility_tensor import apply_paper_style
    apply_paper_style()

    fig, axes = plt.subplots(1, 3, figsize=(19, 7.5))

    # ── find peaks ─────────────────────────────────────────────────────────
    idx1   = int(np.argmax(sigma1_zz))
    idx2   = int(np.argmax(chi2_zzz))
    e_sig1 = e_ev[idx1]       # ~1.88 eV
    e_chi2 = e_ev[idx2]       # ~0.92 eV  (drive freq)
    e_2chi2 = 2 * e_chi2      # ~1.85 eV  ← hits sigma1 peak!

    # ── Panel (a): sigma1_zz ───────────────────────────────────────────────
    ax = axes[0]
    ax.fill_between(e_ev, sigma1_zz/sigma1_zz.max(), color=COL_SIG1, alpha=0.25, lw=0)
    ax.plot(e_ev, sigma1_zz/sigma1_zz.max(), color=COL_SIG1, lw=3.5)
    ax.axvline(e_sig1, color=COL_SIG1, lw=2.0, ls="--", alpha=0.8)
    ax.text(e_sig1 + 0.04, 0.92,
            rf"$\omega_\mathrm{{res}} = {e_sig1:.2f}$ eV",
            fontsize=17, color=COL_SIG1)
    ax.set_xlabel(r"$\hbar\omega$ (eV)", fontsize=26, labelpad=10)
    ax.set_ylabel(r"$|\sigma^{(1)}_{zz}(\omega)|$  (norm.)", fontsize=22, labelpad=10)
    ax.set_title("(a)  Linear absorption", fontsize=22, pad=8)
    ax.set_xlim(0.0, 2.6); ax.set_ylim(0, 1.12)
    ax.tick_params(labelsize=20)
    ax.text(0.5, -0.18,
            "Single photon absorbed\nwhen $\\hbar\\omega$ = band gap",
            ha="center", transform=ax.transAxes, fontsize=16, color="0.4",
            style="italic")

    # ── Panel (b): chi2_zzz — drive freq axis AND 2*omega axis ─────────────
    ax = axes[1]
    ax.fill_between(e_ev, chi2_zzz/chi2_zzz.max(), color=COL_CHI2, alpha=0.25, lw=0)
    ax.plot(e_ev, chi2_zzz/chi2_zzz.max(), color=COL_CHI2, lw=3.5)
    ax.axvline(e_chi2, color=COL_CHI2, lw=2.0, ls="--", alpha=0.8)
    ax.text(e_chi2 + 0.04, 0.92,
            rf"$\omega_\mathrm{{drive}} = {e_chi2:.2f}$ eV",
            fontsize=17, color=COL_CHI2)
    # show 2*omega on top axis
    ax2 = ax.twiny()
    ax2.set_xlim(0.0, 5.2)
    ax2.set_xlabel(r"$2\hbar\omega_\mathrm{drive}$ (eV)", fontsize=20, labelpad=8,
                   color=COL_SIG1)
    ax2.tick_params(labelsize=18, colors=COL_SIG1)
    # mark where 2*omega = sigma1 peak
    ax2.axvline(e_2chi2, color=COL_SIG1, lw=2.5, ls=":", alpha=0.9)
    ax2.text(e_2chi2 + 0.05, 0.75,
             rf"$2\omega={e_2chi2:.2f}$ eV$\approx\omega_\mathrm{{res}}$",
             fontsize=16, color=COL_SIG1, transform=ax2.get_xaxis_transform())

    ax.set_xlabel(r"$\hbar\omega_\mathrm{drive}$ (eV)", fontsize=26, labelpad=10)
    ax.set_ylabel(r"$|\chi^{(2)}_{zzz}(2\omega)|$  (norm.)", fontsize=22, labelpad=10)
    ax.set_title("(b)  SHG susceptibility", fontsize=22, pad=8)
    ax.set_xlim(0.0, 2.6); ax.set_ylim(0, 1.12)
    ax.tick_params(labelsize=20)
    ax.text(0.5, -0.18,
            "Two photons at $\\omega_{\\rm drive}$ emit one at $2\\omega$\nPeak when $2\\omega_{\\rm drive}$ = band gap",
            ha="center", transform=ax.transAxes, fontsize=16, color="0.4",
            style="italic")

    # ── Panel (c): JDOS ────────────────────────────────────────────────────
    ax = axes[2]
    ax.fill_between(jdos_e_mid, jdos/jdos.max(), color=COL_JDOS, alpha=0.25, lw=0)
    ax.plot(jdos_e_mid, jdos/jdos.max(), color=COL_JDOS, lw=3.5)
    # mark resonance energy
    ax.axvline(e_sig1, color=COL_SIG1, lw=2.5, ls="--", alpha=0.9,
               label=rf"$\omega_\mathrm{{res}}={e_sig1:.2f}$ eV ($\sigma^{{(1)}}$ peak)")
    ax.axvline(e_2chi2, color=COL_CHI2, lw=2.5, ls=":", alpha=0.9,
               label=rf"$2\omega_\mathrm{{drive}}={e_2chi2:.2f}$ eV ($\chi^{{(2)}}$ peak)")
    ax.set_xlabel(r"$\varepsilon$ (eV)", fontsize=26, labelpad=10)
    ax.set_ylabel(r"JDOS (norm.)", fontsize=22, labelpad=10)
    ax.set_title("(c)  Joint density of states", fontsize=22, pad=8)
    ax.set_xlim(0.0, 2.6); ax.set_ylim(0, 1.12)
    ax.tick_params(labelsize=20)
    ax.legend(fontsize=15, frameon=False, loc="upper right")
    ax.text(0.5, -0.18,
            "JDOS peak = most available transitions\nBoth $\\omega$ and $2\\omega$ hit the same peak",
            ha="center", transform=ax.transAxes, fontsize=16, color="0.4",
            style="italic")

    for ax in axes:
        for spine in ax.spines.values():
            spine.set_linewidth(1.4)

    fig.suptitle(
        r"Giant SHG in TaAs Weyl semimetal: two-photon output resonance",
        fontsize=22, y=1.02)
    fig.subplots_adjust(left=0.07, right=0.97, bottom=0.22, top=0.93, wspace=0.32)

    OUT.mkdir(parents=True, exist_ok=True)
    f = OUT / "wsm_orenstein_shg_resonance_explanation.png"
    fig.savefig(f, dpi=220, facecolor="white", bbox_inches="tight")
    plt.close(fig)
    print(f"[shg-expl] wrote {f}")


if __name__ == "__main__":
    main()
