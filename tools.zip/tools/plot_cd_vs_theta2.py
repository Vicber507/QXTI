#!/usr/bin/env python3
r"""SHG circular dichroism vs analyzer angle theta2 — TaAs (112) surface.

Reproduces the geometry of Fig. 2c of Wu/Orenstein et al. (Nat. Phys. 2017):

  * Light incident along [112] (normal to the (112) surface).
  * Generator: right- (sigma+, RCP) and left-circularly polarized (sigma-, LCP).
  * Analyzer at angle theta2 rotating in the (112) plane,
        theta2 = 0  ->  [1,1,-1] axis,
        theta2 = 90 ->  [1,-1,0] axis.
  * Detected SHG intensity:  I(theta2) = |a(theta2) . J(2omega)|^2.
  * Circular dichroism:  CD(theta2) = I_sigma+(theta2) - I_sigma-(theta2).

Panel (a): Helicity-resolved SHG intensity I_sigma+ and I_sigma- vs theta2,
           normalized to the sigma+ peak (log scale shows the full Malus-law
           modulation).  The strong modulation of I_sigma+ (factor ~1300) shows
           that the RCP-generated SHG is nearly linearly polarized.

Panel (b): Normalized CD(theta2) = [I_sigma+(theta2) - I_sigma-(theta2)] / norm
           for two values of the dephasing rate gamma: solid = 50 meV (room
           temperature), dashed = near-zero (no broadening).  Both curves
           oscillate with period 180 deg, consistent with the sin(2*theta2)
           prediction of the 4mm point group (SI Eq. 7 of Wu et al.).
           The experimental amplitude is ~6% of the peak linear SHG; our
           room-temperature value (gamma = 50 meV) gives ~7%.

Usage
-----
    python tools/plot_cd_vs_theta2.py            # uses saved .npz files
    python tools/plot_cd_vs_theta2.py --out DIR  # choose output dir
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

import numpy as np

os.environ.setdefault("MPLCONFIGDIR", "/private/tmp")
os.environ.setdefault("XDG_CACHE_HOME", "/private/tmp")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

_DATA_GAMMA    = PROJECT_ROOT / "outputs/sweeps/orenstein_112_cd/shg_circular_dichroism_analyzer.npz"
_DATA_NOGAMMA  = PROJECT_ROOT / "outputs/sweeps/orenstein_112_cd_nogamma/shg_circular_dichroism_analyzer.npz"
_DEFAULT_OUT   = PROJECT_ROOT / "outputs/cd_theta2_plot"

# Crystal axes labels (paper convention)
_AXIS0 = r"$[1,1,\bar{1}]$"   # theta2 = 0
_AXIS1 = r"$[1,\bar{1},0]$"   # theta2 = 90

# Colors (Wong colour-blind palette)
_C_PLUS   = "#0072B2"   # blue   – sigma+
_C_MINUS  = "#D55E00"   # orange – sigma-
_C_GAMMA  = "#009E73"   # green  – with broadening
_C_NOGAM  = "#CC79A7"   # pink   – without broadening


def _sin2_fit(theta_rad: np.ndarray, y: np.ndarray):
    """Return the sin(2θ) Fourier projection as a (amplitude, phase_deg, fine_fit) tuple."""
    phi_f = np.linspace(0, 2 * np.pi, 720)
    # Project y onto sin(2θ) and cos(2θ) simultaneously
    s2 = np.sin(2 * theta_rad)
    c2 = np.cos(2 * theta_rad)
    X = np.column_stack([s2, c2])
    coeff, *_ = np.linalg.lstsq(X, y, rcond=None)
    a_sin, a_cos = coeff
    amplitude = float(np.hypot(a_sin, a_cos))
    phase_rad = np.arctan2(a_cos, a_sin)   # phase: y ≈ A sin(2θ + φ)
    phase_deg = float(np.degrees(phase_rad))
    fit_fine  = a_sin * np.sin(2 * phi_f) + a_cos * np.cos(2 * phi_f)
    return amplitude, phase_deg, phi_f, fit_fine


def main() -> int:
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument("--gamma",   default=str(_DATA_GAMMA),
                    help="NPZ with gamma=50meV CD analyzer data")
    ap.add_argument("--nogamma", default=str(_DATA_NOGAMMA),
                    help="NPZ with no-broadening CD analyzer data")
    ap.add_argument("--out",     default=str(_DEFAULT_OUT))
    args = ap.parse_args()

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    # ── load ──────────────────────────────────────────────────────────────────
    dg  = np.load(args.gamma,   allow_pickle=True)
    dng = np.load(args.nogamma, allow_pickle=True)

    theta_deg = np.asarray(dg["theta2_deg"], dtype=float)
    theta_rad = np.deg2rad(theta_deg)

    Ip   = np.asarray(dg["I_sigma_plus"],  dtype=float)
    Im   = np.asarray(dg["I_sigma_minus"], dtype=float)
    cdn  = np.asarray(dg["cd_normalized"], dtype=float)   # with gamma
    cdnn = np.asarray(dng["cd_normalized"], dtype=float)  # no gamma

    # Normalize intensities to sigma+ peak
    Ip_n = Ip / Ip.max()
    Im_n = Im / Im.max()

    # ── fits ──────────────────────────────────────────────────────────────────
    amp_g,  phi_g,  phi_f, fit_g  = _sin2_fit(theta_rad, cdn)
    amp_ng, phi_ng, _,     fit_ng = _sin2_fit(theta_rad, cdnn)
    print(f"[CD-theta2] gamma:   A = {amp_g:.4f},  phase = {phi_g:+.1f} deg")
    print(f"[CD-theta2] no-gam:  A = {amp_ng:.4f},  phase = {phi_ng:+.1f} deg")

    # ── matplotlib ────────────────────────────────────────────────────────────
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    try:
        from qxti.graphics.plot_susceptibility_tensor import apply_paper_style
        apply_paper_style()
    except Exception:
        pass

    fig, (ax_int, ax_cd) = plt.subplots(
        2, 1, figsize=(5.0, 7.4),
        gridspec_kw={"height_ratios": [1, 1.1], "hspace": 0.08},
    )
    phi_fdeg = np.degrees(phi_f)

    # ── panel (a): I_sigma+ and I_sigma- ─────────────────────────────────────
    ax_int.semilogy(theta_deg, Ip_n, "-", color=_C_PLUS,  lw=2.0,
                    label=r"$I_{\sigma^+}(\theta_2)$ (RCP gen.)")
    ax_int.semilogy(theta_deg, Im_n, "--", color=_C_MINUS, lw=2.0,
                    label=r"$I_{\sigma^-}(\theta_2)$ (LCP gen.)")

    ax_int.fill_between(theta_deg, Ip_n, Im_n,
                        where=(Ip_n >= Im_n), alpha=0.15, color=_C_PLUS)
    ax_int.fill_between(theta_deg, Im_n, Ip_n,
                        where=(Im_n >  Ip_n), alpha=0.15, color=_C_MINUS)

    ax_int.set_xlim(0, 360)
    ax_int.set_ylim(5e-4, 3.0)
    ax_int.set_ylabel(r"$I(\theta_2)$ / $I_{\sigma^+}^{\rm max}$  (log scale)", fontsize=12)
    ax_int.set_xticklabels([])
    ax_int.legend(loc="upper center", fontsize=11, ncol=2)
    ax_int.text(-0.13, 1.02, "(a)", transform=ax_int.transAxes,
                fontsize=14, fontweight="bold")

    # crystal-axis tick labels at theta2 = 0, 90, 180, 270
    for xv, lbl in [(0, _AXIS0), (90, _AXIS1), (180, _AXIS0), (270, _AXIS1)]:
        ax_int.axvline(xv, color="0.75", lw=0.7, ls=":")

    # ── panel (b): CD(theta2) ─────────────────────────────────────────────────
    ax_cd.axhline(0.0, color="0.65", lw=0.9, zorder=0)
    for y in (-1, 1):
        ax_cd.axhline(y, color="0.65", lw=0.6, ls="--", zorder=0)

    ax_cd.plot(theta_deg, cdn,  "-",  color=_C_GAMMA, lw=2.2,
               label=rf"$\gamma = 50\,\mathrm{{meV}}$")
    ax_cd.plot(theta_deg, cdnn, "--", color=_C_NOGAM, lw=1.8,
               label=r"$\gamma \to 0$")

    # fit overlay (gamma case)
    ax_cd.plot(phi_fdeg, fit_g,  ":", color=_C_GAMMA, lw=1.3, alpha=0.80,
               label=rf"$A\sin(2\theta_2+\varphi_0)$,  $A={amp_g:.2f}$")

    # mark sign-change positions with vertical dotted lines
    for cross in _zero_crossings(theta_deg, cdn):
        ax_cd.axvline(cross, color=_C_GAMMA, lw=0.8, ls=":", alpha=0.55)

    # crystal-axis labels at top
    ax_cd.set_xticks([0, 90, 180, 270, 360])
    ax_cd.set_xticklabels(
        [f"0°\n{_AXIS0}", f"90°\n{_AXIS1}", f"180°\n{_AXIS0}",
         f"270°\n{_AXIS1}", "360°"],
        fontsize=9.5,
    )
    ax_cd.set_xlim(0, 360)
    ax_cd.set_ylim(-1.22, 1.22)
    ax_cd.set_ylabel(
        r"$\mathrm{CD}(\theta_2) = \dfrac{I_{\sigma^+}-I_{\sigma^-}}{|{\rm peak}|}$",
        fontsize=12,
    )
    ax_cd.legend(loc="lower center", fontsize=10, ncol=1)
    ax_cd.text(-0.13, 1.02, "(b)", transform=ax_cd.transAxes,
               fontsize=14, fontweight="bold")

    # vertical axes labels (crystal axes)
    for xv in [0, 90, 180, 270]:
        ax_cd.axvline(xv, color="0.75", lw=0.7, ls=":")

    fig.suptitle(
        r"SHG circular dichroism on TaAs (112) surface"
        "\n"
        r"Generator: RCP / LCP  $\parallel [112]$,  analyzer angle $\theta_2$ in (112) plane",
        fontsize=11, y=0.998,
    )

    # ── save ──────────────────────────────────────────────────────────────────
    png = out_dir / "cd_vs_theta2.png"
    pdf = out_dir / "cd_vs_theta2.pdf"
    fig.savefig(png, dpi=300, facecolor="white", bbox_inches="tight")
    fig.savefig(pdf,           facecolor="white", bbox_inches="tight")
    plt.close(fig)
    print(f"[CD-theta2] wrote {png}")
    print(f"[CD-theta2] wrote {pdf}")

    np.savez_compressed(
        out_dir / "cd_vs_theta2.npz",
        theta2_deg=theta_deg,
        I_sigma_plus_norm=Ip_n, I_sigma_minus_norm=Im_n,
        cd_gamma=cdn, cd_nogamma=cdnn,
        fit_phi_deg=phi_fdeg, fit_cd_gamma=fit_g,
        amplitude_gamma=amp_g, phase_gamma=phi_g,
        amplitude_nogamma=amp_ng, phase_nogamma=phi_ng,
    )
    return 0


def _zero_crossings(x: np.ndarray, y: np.ndarray) -> list[float]:
    crossings = []
    for i in range(len(y) - 1):
        if y[i] * y[i + 1] < 0:
            t = -y[i] / (y[i + 1] - y[i])
            crossings.append(float(x[i] + t * (x[i + 1] - x[i])))
    return crossings


if __name__ == "__main__":
    raise SystemExit(main())
