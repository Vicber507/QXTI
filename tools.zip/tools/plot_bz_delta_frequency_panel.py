#!/usr/bin/env python3
from __future__ import annotations

"""BZ local-response panel with frequency increasing right and Delta decreasing down.

The default figure is a paper-style amplitude panel for the Orenstein WSM:

    columns: increasing laser frequency
    rows: decreasing inversion-breaking Delta, ending at Delta = 0

For second order, chi^(2) and sigma^(2) are computed from the same local
sigma^(2) integrand, so the tool can export both without duplicate work.
"""

import argparse
import copy
import os
from pathlib import Path
import sys
import time
from typing import Any

import numpy as np
from numpy.typing import NDArray

os.environ.setdefault("MPLCONFIGDIR", "/private/tmp")
os.environ.setdefault("XDG_CACHE_HOME", "/private/tmp")

import matplotlib

matplotlib.use("Agg")
from matplotlib import pyplot as plt
from matplotlib.colors import Normalize, TwoSlopeNorm

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
if str(PROJECT_ROOT / "tools") not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT / "tools"))

from qxti.analytics.theory_response import _resolve_distribution
from qxti.core import QXTIConfig
from qxti.core.simulation import QXTISimulation
from qxti.graphics.plot_susceptibility_tensor import apply_paper_style
from qxti.utils.progress import format_duration

from plot_bz_chi_contribution import (
    AXES,
    LABELS,
    _axis_values,
    _band_data,
    _component_indices,
    _component_label,
    _load_model_module,
    _overlay_weyl_nodes,
    _pi_ticks,
    _rho1,
    _sigma2_integrand,
)

AU_TO_EV = 27.211386245988
DEFAULT_OUTPUT_DIR = Path("outputs") / "bz_chi_contribution" / "delta_frequency_panel"

ComplexArray = NDArray[np.complex128]
FloatArray = NDArray[np.float64]


def _parse_csv_floats(text: str) -> np.ndarray:
    values = [float(item.strip()) for item in str(text).replace(";", ",").split(",") if item.strip()]
    if not values:
        raise ValueError("Expected at least one numeric value.")
    return np.asarray(values, dtype=np.float64)


def _sanitize_values(values: np.ndarray) -> str:
    return "_".join(f"{float(value):g}".replace("-", "m").replace(".", "p") for value in values)


def _load_model_params(config: QXTIConfig, module: Any, *, delta: float) -> dict[str, Any]:
    params: dict[str, Any] = {}
    if module is not None and hasattr(module, "default_params"):
        try:
            params.update(dict(module.default_params()))
        except Exception:
            pass
    params.update(dict(config.hamiltonian.params))
    params["Delta"] = float(delta)
    return params


def _config_with_delta(config: QXTIConfig, delta: float) -> QXTIConfig:
    cfg = copy.deepcopy(config)
    cfg.hamiltonian.params["Delta"] = float(delta)
    return cfg


def _sigma1_integrand(
    data: dict[str, Any],
    *,
    component: tuple[int, int],
    omega: float,
    gamma: float,
) -> ComplexArray:
    output_axis, input_axis = component
    rho = _rho1(data, input_axis, complex(float(omega), float(gamma)))
    current = -np.asarray(data["vel"][output_axis], dtype=np.complex128)
    return np.conj(np.einsum("kmn,knm->k", current, rho, optimize=True))


def _vmax(values: FloatArray, robust_percentile: float | None) -> float:
    finite = np.asarray(values[np.isfinite(values)], dtype=np.float64)
    if finite.size == 0:
        return 1.0
    if robust_percentile is not None and 0.0 < robust_percentile < 100.0:
        return max(float(np.nanpercentile(np.abs(finite), robust_percentile)), 1.0e-30)
    return max(float(np.nanmax(np.abs(finite))), 1.0e-30)


def _values_for_part(values: ComplexArray, part: str) -> FloatArray:
    key = part.strip().lower()
    if key in {"abs", "amplitude", "amp"}:
        return np.abs(values)
    if key in {"real", "re"}:
        return np.real(values)
    if key in {"imag", "im"}:
        return np.imag(values)
    if key in {"phase", "arg"}:
        return np.angle(values)
    raise ValueError("--part must be abs, real, imag, or phase.")


def _norm_for_part(values: FloatArray, part: str, robust_percentile: float | None):
    key = part.strip().lower()
    if key in {"abs", "amplitude", "amp"}:
        return Normalize(vmin=0.0, vmax=_vmax(values, robust_percentile))
    if key in {"phase", "arg"}:
        return Normalize(vmin=-np.pi, vmax=np.pi)
    vmax = _vmax(values, robust_percentile)
    return TwoSlopeNorm(vmin=-vmax, vcenter=0.0, vmax=vmax)


def _cmap_for_part(part: str):
    key = part.strip().lower()
    if key in {"abs", "amplitude", "amp"}:
        return "magma"
    if key in {"phase", "arg"}:
        return "twilight_shifted"
    from plot_bz_chi_contribution import _signed_cmap

    return _signed_cmap()


def _cbar_label(quantity: str, component_label: str, part: str) -> str:
    key = part.strip().lower()
    if quantity == "chi2":
        base = rf"\mathcal{{I}}^{{\chi^{{(2)}}}}_{{{component_label}}}(\mathbf{{k}})"
    elif quantity == "sigma2":
        base = rf"\mathcal{{I}}^{{\sigma^{{(2)}}}}_{{{component_label}}}(\mathbf{{k}})"
    else:
        base = rf"\mathcal{{I}}^{{\sigma^{{(1)}}}}_{{{component_label}}}(\mathbf{{k}})"
    if key in {"abs", "amplitude", "amp"}:
        return rf"$\left|{base}\right|$"
    if key in {"phase", "arg"}:
        return rf"$\arg\,{base}$"
    if key in {"real", "re"}:
        return rf"$\mathrm{{Re}}\,{base}$"
    return rf"$\mathrm{{Im}}\,{base}$"


def _quantity_title(quantity: str, component_label: str, part: str, plane_name: str, fixed: float) -> str:
    prefix = {
        "chi2": rf"$\chi^{{(2)}}_{{{component_label}}}$",
        "sigma2": rf"$\sigma^{{(2)}}_{{{component_label}}}$",
        "sigma1": rf"$\sigma^{{(1)}}_{{{component_label}}}$",
    }[quantity]
    part_name = {
        "abs": "amplitude",
        "amplitude": "amplitude",
        "amp": "amplitude",
        "real": "real part",
        "re": "real part",
        "imag": "imaginary part",
        "im": "imaginary part",
        "phase": "phase",
        "arg": "phase",
    }[part.strip().lower()]
    return rf"Local BZ {part_name} of {prefix} on ${plane_name}={fixed:g}$"


def _compute_second_order_maps(
    *,
    config: QXTIConfig,
    module: Any,
    deltas: FloatArray,
    omega_axis: FloatArray,
    component: tuple[int, int, int],
    plane_axis: int,
    fixed: float,
    points: int,
    shifted: bool,
    normal_points_override: int | None,
    gradient_step_override: float | None,
    velocity_step: float,
) -> tuple[ComplexArray, ComplexArray, FloatArray, FloatArray, list[dict[str, Any]], float, float]:
    ndelta = int(deltas.size)
    nfreq = int(omega_axis.size)
    chi2_maps: ComplexArray | None = None
    sigma2_maps: ComplexArray | None = None
    x_plot: FloatArray | None = None
    y_plot: FloatArray | None = None
    params_by_delta: list[dict[str, Any]] = []
    unit_scale = 1.0
    k_offset = np.pi

    ccfg = config.susceptibility_solver
    distribution = _resolve_distribution(ccfg.distribution)
    mu = float(ccfg.fermi_level)
    temperature = float(ccfg.temperature)
    gamma = 0.0 if ccfg.coherence_time <= 0 else 1.0 / float(ccfg.coherence_time)
    gradient_axes = tuple(sorted({component[1], component[2]}))
    axes_needed = tuple(sorted(set(component)))

    for row, delta in enumerate(deltas):
        cfg_delta = _config_with_delta(config, float(delta))
        hamiltonian = QXTISimulation(config=cfg_delta).build_hamiltonian()
        if int(hamiltonian.dimension) < 3:
            raise SystemExit("This tool needs a 3D Hamiltonian.")
        bounds = hamiltonian.reciprocal_box_bounds()
        plane_axes = [axis for axis in range(3) if axis != plane_axis]
        x_internal = _axis_values(bounds[plane_axes[0]], points, shifted=shifted)
        y_internal = _axis_values(bounds[plane_axes[1]], points, shifted=shifted)
        x_grid, y_grid = np.meshgrid(x_internal, y_internal, indexing="ij")
        k_points = np.zeros((x_grid.size, 3), dtype=np.float64)
        k_points[:, plane_axis] = float(fixed)
        k_points[:, plane_axes[0]] = x_grid.reshape(-1)
        k_points[:, plane_axes[1]] = y_grid.reshape(-1)

        normal_points = (
            int(normal_points_override)
            if normal_points_override is not None
            else int(cfg_delta.kgrid.k_points[plane_axis])
        )
        normal_points = max(normal_points, 2)
        gradient_step = (
            float(gradient_step_override)
            if gradient_step_override is not None
            else (float(bounds[plane_axis][1]) - float(bounds[plane_axis][0])) / float(normal_points)
        )

        current_data = _band_data(
            Hf=hamiltonian._matrix_at,
            k_points=k_points,
            axes_needed=axes_needed,
            distribution=distribution,
            mu=mu,
            temperature=temperature,
            velocity_step=float(velocity_step),
        )
        shifted_data_by_axis: dict[int, tuple[dict[str, Any], dict[str, Any]]] = {}
        for gradient_axis in gradient_axes:
            shift = np.zeros(3, dtype=np.float64)
            shift[gradient_axis] = float(gradient_step)
            shifted_data_by_axis[gradient_axis] = (
                _band_data(
                    Hf=hamiltonian._matrix_at,
                    k_points=k_points + shift,
                    axes_needed=axes_needed,
                    distribution=distribution,
                    mu=mu,
                    temperature=temperature,
                    velocity_step=float(velocity_step),
                ),
                _band_data(
                    Hf=hamiltonian._matrix_at,
                    k_points=k_points - shift,
                    axes_needed=axes_needed,
                    distribution=distribution,
                    mu=mu,
                    temperature=temperature,
                    velocity_step=float(velocity_step),
                ),
            )

        if chi2_maps is None:
            chi2_maps = np.zeros((ndelta, nfreq, points, points), dtype=np.complex128)
            sigma2_maps = np.zeros_like(chi2_maps)
            params0 = _load_model_params(cfg_delta, module, delta=float(delta))
            unit_scale = float(params0.get("a", 1.0))
            x_plot = x_internal * unit_scale + k_offset
            y_plot = y_internal * unit_scale + k_offset

        params_by_delta.append(_load_model_params(cfg_delta, module, delta=float(delta)))
        for col, omega in enumerate(omega_axis):
            sigma2_flat = _sigma2_integrand(
                current_data=current_data,
                shifted_data_by_axis=shifted_data_by_axis,
                component=component,
                omega=float(omega),
                gamma=float(gamma),
                gradient_step=float(gradient_step),
            )
            assert sigma2_maps is not None and chi2_maps is not None
            sigma2_maps[row, col] = sigma2_flat.reshape(points, points)
            chi2_maps[row, col] = (sigma2_flat / (-1j * 2.0 * float(omega))).reshape(points, points)
        print(f"[delta-panel] Delta {row + 1}/{ndelta}: {float(delta):g}", flush=True)

    assert chi2_maps is not None and sigma2_maps is not None and x_plot is not None and y_plot is not None
    return chi2_maps, sigma2_maps, x_plot, y_plot, params_by_delta, unit_scale, k_offset


def _compute_sigma1_maps(
    *,
    config: QXTIConfig,
    module: Any,
    deltas: FloatArray,
    omega_axis: FloatArray,
    component: tuple[int, int],
    plane_axis: int,
    fixed: float,
    points: int,
    shifted: bool,
    velocity_step: float,
) -> tuple[ComplexArray, FloatArray, FloatArray, list[dict[str, Any]], float, float]:
    ndelta = int(deltas.size)
    nfreq = int(omega_axis.size)
    maps: ComplexArray | None = None
    x_plot: FloatArray | None = None
    y_plot: FloatArray | None = None
    params_by_delta: list[dict[str, Any]] = []
    unit_scale = 1.0
    k_offset = np.pi

    ccfg = config.susceptibility_solver
    distribution = _resolve_distribution(ccfg.distribution)
    mu = float(ccfg.fermi_level)
    temperature = float(ccfg.temperature)
    gamma = 0.0 if ccfg.coherence_time <= 0 else 1.0 / float(ccfg.coherence_time)
    axes_needed = tuple(sorted(set(component)))

    for row, delta in enumerate(deltas):
        cfg_delta = _config_with_delta(config, float(delta))
        hamiltonian = QXTISimulation(config=cfg_delta).build_hamiltonian()
        bounds = hamiltonian.reciprocal_box_bounds()
        plane_axes = [axis for axis in range(3) if axis != plane_axis]
        x_internal = _axis_values(bounds[plane_axes[0]], points, shifted=shifted)
        y_internal = _axis_values(bounds[plane_axes[1]], points, shifted=shifted)
        x_grid, y_grid = np.meshgrid(x_internal, y_internal, indexing="ij")
        k_points = np.zeros((x_grid.size, 3), dtype=np.float64)
        k_points[:, plane_axis] = float(fixed)
        k_points[:, plane_axes[0]] = x_grid.reshape(-1)
        k_points[:, plane_axes[1]] = y_grid.reshape(-1)
        data = _band_data(
            Hf=hamiltonian._matrix_at,
            k_points=k_points,
            axes_needed=axes_needed,
            distribution=distribution,
            mu=mu,
            temperature=temperature,
            velocity_step=float(velocity_step),
        )
        if maps is None:
            maps = np.zeros((ndelta, nfreq, points, points), dtype=np.complex128)
            params0 = _load_model_params(cfg_delta, module, delta=float(delta))
            unit_scale = float(params0.get("a", 1.0))
            x_plot = x_internal * unit_scale + k_offset
            y_plot = y_internal * unit_scale + k_offset
        params_by_delta.append(_load_model_params(cfg_delta, module, delta=float(delta)))
        for col, omega in enumerate(omega_axis):
            maps[row, col] = _sigma1_integrand(
                data,
                component=component,
                omega=float(omega),
                gamma=float(gamma),
            ).reshape(points, points)
        print(f"[delta-panel] Delta {row + 1}/{ndelta}: {float(delta):g}", flush=True)

    assert maps is not None and x_plot is not None and y_plot is not None
    return maps, x_plot, y_plot, params_by_delta, unit_scale, k_offset


def _plot_panel(
    *,
    maps: ComplexArray,
    quantity: str,
    component_label: str,
    part: str,
    deltas: FloatArray,
    frequencies_ev: FloatArray,
    x_axis: FloatArray,
    y_axis: FloatArray,
    module: Any,
    params_by_delta: list[dict[str, Any]],
    plane_axis: int,
    fixed: float,
    unit_scale: float,
    k_offset: float,
    output_base: Path,
    dpi: int,
    robust_percentile: float | None,
    colorbar_mode: str,
) -> list[Path]:
    apply_paper_style()
    ndelta, nfreq = int(deltas.size), int(frequencies_ev.size)
    fig, axes = plt.subplots(
        ndelta,
        nfreq,
        figsize=(3.95 * nfreq, 3.45 * ndelta),
        squeeze=False,
        sharex=True,
        sharey=True,
    )
    x_grid, y_grid = np.meshgrid(x_axis, y_axis, indexing="ij")
    plane_axes = [axis for axis in range(3) if axis != plane_axis]
    cmap = _cmap_for_part(part)
    image_grid: list[list[Any]] = [[None for _ in range(nfreq)] for _ in range(ndelta)]
    colorbar_mode = str(colorbar_mode).strip().lower()

    for row, delta in enumerate(deltas):
        for col, frequency_ev in enumerate(frequencies_ev):
            ax = axes[row, col]
            values = _values_for_part(maps[row, col], part)
            norm = _norm_for_part(values, part, robust_percentile)
            image = ax.pcolormesh(x_grid, y_grid, values, shading="auto", cmap=cmap, norm=norm)
            image_grid[row][col] = image
            _overlay_weyl_nodes(
                ax,
                module,
                params_by_delta[row],
                plane_axis,
                fixed,
                unit_scale,
                k_offset=k_offset,
            )
            if row == 0:
                ax.set_title(rf"$\hbar\omega={float(frequency_ev):g}\,\mathrm{{eV}}$", fontsize=18, pad=7)
            if col == 0:
                ax.set_ylabel(rf"$\Delta={float(delta):g}$" + "\n" + rf"$k_{LABELS[plane_axes[1]]}a$", fontsize=17)
            if row == ndelta - 1:
                ax.set_xlabel(rf"$k_{LABELS[plane_axes[0]]}a$", fontsize=18)
            _pi_ticks(ax, x_axis, "x")
            _pi_ticks(ax, y_axis, "y")
            ax.tick_params(axis="both", which="major", labelsize=14)
            if row != ndelta - 1:
                ax.set_xlabel("")
            if col != 0:
                ax.set_ylabel("")

            if colorbar_mode == "panel":
                cbar = fig.colorbar(image, ax=ax, fraction=0.044, pad=0.012)
                if row == 0 and col == nfreq - 1:
                    cbar.set_label(_cbar_label(quantity, component_label, part), fontsize=14, labelpad=6)
                cbar.ax.tick_params(labelsize=10)
                if part.strip().lower() in {"phase", "arg"}:
                    cbar.set_ticks([-np.pi, 0.0, np.pi])
                    cbar.set_ticklabels([r"$-\pi$", r"$0$", r"$\pi$"])

    if colorbar_mode == "none":
        fig.subplots_adjust(left=0.075, right=0.985, bottom=0.065, top=0.90, wspace=0.08, hspace=0.14)
    elif colorbar_mode == "panel":
        fig.subplots_adjust(left=0.075, right=0.975, bottom=0.065, top=0.90, wspace=0.30, hspace=0.16)
    else:
        raise ValueError("--colorbar-mode must be panel or none.")

    plane_name = f"k_{LABELS[plane_axis]}"
    fig.suptitle(_quantity_title(quantity, component_label, part, plane_name, fixed), fontsize=22, y=0.975)
    output_base.parent.mkdir(parents=True, exist_ok=True)
    outputs = [output_base.with_suffix(".png"), output_base.with_suffix(".svg")]
    fig.savefig(outputs[0], dpi=int(dpi), facecolor="white")
    fig.savefig(outputs[1], facecolor="white")
    plt.close(fig)
    return outputs


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="inputs/inputParams.wsm_orenstein.cfg")
    parser.add_argument("--deltas", default="0.5,0.375,0.25,0.125,0.0")
    parser.add_argument("--frequencies-ev", default="0.3,0.8,1.3,1.8")
    parser.add_argument("--quantity", choices=("chi2", "sigma2", "both2", "sigma1"), default="both2")
    parser.add_argument("--component", default="zzz")
    parser.add_argument("--part", choices=("abs", "real", "imag", "phase"), default="abs")
    parser.add_argument("--points", type=int, default=140)
    parser.add_argument("--plane", choices=("kx", "ky", "kz"), default="kz")
    parser.add_argument("--fixed", type=float, default=0.0)
    parser.add_argument("--normal-points", type=int, default=None)
    parser.add_argument("--gradient-step", type=float, default=None)
    parser.add_argument("--velocity-step", type=float, default=1.0e-4)
    parser.add_argument("--robust-percentile", type=float, default=99.5)
    parser.add_argument("--output-dir", default=str(DEFAULT_OUTPUT_DIR))
    parser.add_argument("--dpi", type=int, default=320)
    parser.add_argument("--colorbar-mode", choices=("panel", "none"), default="panel")
    parser.add_argument("--unshifted", action="store_true")
    args = parser.parse_args()

    t0 = time.perf_counter()
    deltas = _parse_csv_floats(args.deltas)
    deltas = np.asarray(sorted((float(v) for v in deltas), reverse=True), dtype=np.float64)
    frequencies_ev = _parse_csv_floats(args.frequencies_ev)
    frequencies_ev = np.asarray(sorted((float(v) for v in frequencies_ev)), dtype=np.float64)
    if np.any(frequencies_ev <= 0.0):
        raise SystemExit("All frequencies must be positive.")
    omega_axis = frequencies_ev / AU_TO_EV
    robust_percentile = None if float(args.robust_percentile) >= 100.0 else float(args.robust_percentile)

    config = QXTIConfig.from_file(Path(args.config))
    module = _load_model_module(config)
    plane_axis = AXES[args.plane[-1]]
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    print(
        "[delta-panel] "
        f"quantity={args.quantity}, component={args.component}, part={args.part}, "
        f"deltas={','.join(f'{d:g}' for d in deltas)}, "
        f"freqs={','.join(f'{w:g}' for w in frequencies_ev)} eV, "
        f"grid={int(args.points)}x{int(args.points)}",
        flush=True,
    )

    outputs: list[Path] = []
    if args.quantity in {"chi2", "sigma2", "both2"}:
        component = _component_indices(args.component)
        component_label = _component_label(component)
        chi2_maps, sigma2_maps, x_plot, y_plot, params_by_delta, unit_scale, k_offset = _compute_second_order_maps(
            config=config,
            module=module,
            deltas=deltas,
            omega_axis=omega_axis,
            component=component,
            plane_axis=plane_axis,
            fixed=float(args.fixed),
            points=int(args.points),
            shifted=not args.unshifted,
            normal_points_override=args.normal_points,
            gradient_step_override=args.gradient_step,
            velocity_step=float(args.velocity_step),
        )
        tag = (
            f"{args.plane}_{float(args.fixed):g}_{component_label}_"
            f"delta_{_sanitize_values(deltas)}_omega_{_sanitize_values(frequencies_ev)}"
        ).replace(".", "p")
        np.savez_compressed(
            output_dir / f"bz_delta_frequency_{tag}.npz",
            deltas=deltas,
            frequencies_ev=frequencies_ev,
            omega_axis=omega_axis,
            component=component_label,
            plane=str(args.plane),
            fixed=float(args.fixed),
            x_axis_plot=x_plot,
            y_axis_plot=y_plot,
            chi2_integrand=chi2_maps,
            sigma2_integrand=sigma2_maps,
        )
        if args.quantity in {"chi2", "both2"}:
            outputs.extend(
                _plot_panel(
                    maps=chi2_maps,
                    quantity="chi2",
                    component_label=component_label,
                    part=str(args.part),
                    deltas=deltas,
                    frequencies_ev=frequencies_ev,
                    x_axis=x_plot,
                    y_axis=y_plot,
                    module=module,
                    params_by_delta=params_by_delta,
                    plane_axis=plane_axis,
                    fixed=float(args.fixed),
                    unit_scale=unit_scale,
                    k_offset=k_offset,
                    output_base=output_dir / f"chi2_{component_label}_{args.part}_delta_frequency_panel",
                    dpi=int(args.dpi),
                    robust_percentile=robust_percentile,
                    colorbar_mode=str(args.colorbar_mode),
                )
            )
        if args.quantity in {"sigma2", "both2"}:
            outputs.extend(
                _plot_panel(
                    maps=sigma2_maps,
                    quantity="sigma2",
                    component_label=component_label,
                    part=str(args.part),
                    deltas=deltas,
                    frequencies_ev=frequencies_ev,
                    x_axis=x_plot,
                    y_axis=y_plot,
                    module=module,
                    params_by_delta=params_by_delta,
                    plane_axis=plane_axis,
                    fixed=float(args.fixed),
                    unit_scale=unit_scale,
                    k_offset=k_offset,
                    output_base=output_dir / f"sigma2_{component_label}_{args.part}_delta_frequency_panel",
                    dpi=int(args.dpi),
                    robust_percentile=robust_percentile,
                    colorbar_mode=str(args.colorbar_mode),
                )
            )
    else:
        comp_text = str(args.component).strip().lower().replace("_", "")
        if len(comp_text) != 2 or any(char not in AXES for char in comp_text):
            raise SystemExit("--component for sigma1 must have two axes, e.g. zz or xz.")
        component = tuple(AXES[char] for char in comp_text)
        component_label = "".join(LABELS[index] for index in component)
        maps, x_plot, y_plot, params_by_delta, unit_scale, k_offset = _compute_sigma1_maps(
            config=config,
            module=module,
            deltas=deltas,
            omega_axis=omega_axis,
            component=component,
            plane_axis=plane_axis,
            fixed=float(args.fixed),
            points=int(args.points),
            shifted=not args.unshifted,
            velocity_step=float(args.velocity_step),
        )
        outputs.extend(
            _plot_panel(
                maps=maps,
                quantity="sigma1",
                component_label=component_label,
                part=str(args.part),
                deltas=deltas,
                frequencies_ev=frequencies_ev,
                x_axis=x_plot,
                y_axis=y_plot,
                module=module,
                params_by_delta=params_by_delta,
                plane_axis=plane_axis,
                fixed=float(args.fixed),
                unit_scale=unit_scale,
                k_offset=k_offset,
                output_base=output_dir / f"sigma1_{component_label}_{args.part}_delta_frequency_panel",
                dpi=int(args.dpi),
                robust_percentile=robust_percentile,
                colorbar_mode=str(args.colorbar_mode),
            )
        )

    print(f"[delta-panel] done in {format_duration(time.perf_counter() - t0)}", flush=True)
    for path in outputs:
        print(f"[delta-panel] plot: {path}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
