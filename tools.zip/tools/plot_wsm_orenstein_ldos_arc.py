#!/usr/bin/env python3
r"""Restyle the QXTI Orenstein LDOS spectral map.

This intentionally uses the *saved* LDOS dataset produced by

    python main.py inputs/inputParams.wsm_orenstein.cfg -ldos

and keeps the same blue spectral-map style used by ``qxti/graphics``.  The only
changes are presentation changes requested for the paper:

* x-axis shown as dimensionless ``k_x a`` with ticks in multiples of pi,
* y-axis restricted to ``-1 <= E <= 1`` eV,
* larger axis labels and ticks.
"""
from __future__ import annotations

import importlib.util
import os
import sys
from fractions import Fraction
from pathlib import Path

import numpy as np

os.environ.setdefault("MPLCONFIGDIR", "/private/tmp")
os.environ.setdefault("XDG_CACHE_HOME", "/private/tmp")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

DATASET = Path("outputs/wsm_orenstein/ldos/data/ldos.npz")
CONFIG = Path("inputs/inputParams.wsm_orenstein.cfg")
OUT = Path("outputs/wsm_orenstein_ldos")
OUT_MAIN = OUT / "ldos_arc_zoomed.png"
OUT_ALIAS = OUT / "ldos_arc_energy_cut.png"
OUT_BULK_MAIN = OUT / "ldos_arc_zoomed_bulk.png"
OUT_BULK_ALIAS = OUT / "ldos_arc_energy_cut_bulk.png"

ENERGY_MIN_EV = -1.25
ENERGY_MAX_EV = +1.25
LABEL_SIZE = 22
TICK_SIZE = 20
X_TICK_SIZE = 28
CBAR_LABEL_SIZE = 16
TITLE_SIZE = 17
DPI = 300


def _load_model():
    spec = importlib.util.spec_from_file_location(
        "wsm_o", PROJECT_ROOT / "models" / "wsm_orenstein.py"
    )
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def _load_model_params(model) -> dict[str, object]:
    params = model.default_params()
    try:
        from qxti.core.config import QXTIConfig

        config = QXTIConfig.from_file(CONFIG)
        params.update(dict(config.hamiltonian.params))
    except Exception as exc:
        print(f"[arc-ldos] warning: using model defaults; could not read {CONFIG}: {exc}")
    return params


def _resolve_normal_axis(surface_normal: str, dim: int) -> int:
    key = (surface_normal or "auto").strip().lower()
    if key in {"x", "0"}:
        return 0
    if key in {"y", "1"}:
        return 1
    if key in {"z", "2"}:
        return 2
    return max(0, int(dim) - 1)


def _surface_config_from_input() -> tuple[int, int]:
    """Return the surface normal and projection grid from the LDOS config."""
    try:
        from qxti.core.config import QXTIConfig

        config = QXTIConfig.from_file(CONFIG)
        normal = _resolve_normal_axis(config.ldos.surface_normal, int(config.kgrid.dimension))
        n_normal = max(int(config.ldos.surface_kn_points), 32)
        return normal, n_normal
    except Exception as exc:
        print(f"[arc-ldos] warning: using normal=y, n_normal=300; could not read {CONFIG}: {exc}")
        return 1, 300


def _projected_bulk_spectral_from_path(
    model,
    params: dict[str, object],
    path_k: np.ndarray,
    energies: np.ndarray,
    eta: float,
    *,
    normal_axis: int,
    n_normal: int,
) -> np.ndarray:
    """Bulk-projected A(k_parallel,E), integrated over the surface-normal momentum.

    This is the correct no-surface comparison for a semi-infinite LDOS map:
    it fills the projected bulk continuum but cannot generate boundary states.
    """
    spacing = float(np.mean(np.diff(energies))) if energies.size > 1 else float(eta)
    eta = max(float(eta), 3.0 * abs(spacing), 1.0e-12)
    a = float(params.get("a", 1.0))
    k_normal = np.linspace(-np.pi / a, np.pi / a, int(n_normal), endpoint=False)
    spectral = np.zeros((path_k.shape[0], energies.size), dtype=np.float64)
    for ik, k in enumerate(path_k):
        row = np.zeros(energies.size, dtype=np.float64)
        kk = np.array(k, dtype=np.float64)
        for kn in k_normal:
            kk[normal_axis] = kn
            eig = np.linalg.eigvalsh(
                model.H(float(kk[0]), float(kk[1]), float(kk[2]), params)
            )
            denom = (energies[None, :] - eig[:, None]) ** 2 + eta**2
            row += np.sum((eta / np.pi) / denom, axis=0)
        spectral[ik] = row / float(k_normal.size)
        if ik % max(1, path_k.shape[0] // 10) == 0 or ik == path_k.shape[0] - 1:
            print(
                f"[arc-ldos] projected bulk path {ik + 1}/{path_k.shape[0]} "
                f"(integrated {k_normal.size} k-normal pts)",
                flush=True,
            )
    return spectral


def _format_pi_label(value: float) -> str:
    frac = Fraction(float(value / np.pi)).limit_denominator(8)
    n, d = frac.numerator, frac.denominator
    if n == 0:
        return r"$0$"
    sign = "-" if n < 0 else ""
    n = abs(n)
    if d == 1:
        body = r"\pi" if n == 1 else rf"{n}\pi"
    else:
        body = rf"\frac{{\pi}}{{{d}}}" if n == 1 else rf"\frac{{{n}\pi}}{{{d}}}"
    return rf"${sign}{body}$"


def _set_pi_ticks(ax, xmin: float, xmax: float) -> None:
    step = np.pi / 2.0
    start = np.ceil((xmin - 1.0e-12) / step) * step
    ticks = np.arange(start, xmax + 0.5 * step, step)
    ticks = ticks[(ticks >= xmin - 1.0e-9) & (ticks <= xmax + 1.0e-9)]
    ax.set_xticks(ticks)
    ax.set_xticklabels([_format_pi_label(t) for t in ticks], fontsize=X_TICK_SIZE)


def _single_path_direction(path_k: np.ndarray) -> int:
    spans = path_k.max(axis=0) - path_k.min(axis=0)
    varying = np.where(spans > 1.0e-9 * (np.abs(path_k).max() + 1.0e-12))[0]
    if varying.size != 1:
        raise ValueError("Expected a single-axis LDOS spectral path for this plot.")
    return int(varying[0])


def _render_spectral_map(
    *,
    spectral: np.ndarray,
    energies_ev: np.ndarray,
    x: np.ndarray,
    data: dict,
    output_paths: tuple[Path, Path],
) -> None:
    from qxti.graphics.plot_dos import (
        _SPECTRAL_CBAR_LABEL,
        _build_alpha_colormap,
        _scaled_imshow_values,
        _spectral_style,
    )
    from qxti.graphics.plot_susceptibility_tensor import apply_paper_style

    style = _spectral_style(data)
    style["cmap"] = "Blues"
    z, vmin, vmax = _scaled_imshow_values(spectral.T, style)
    cmap = _build_alpha_colormap("Blues", style["alpha_min"], style["alpha_max"])

    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    apply_paper_style()
    fig = plt.figure(figsize=(7.8, 7.2))
    gs = fig.add_gridspec(
        1,
        2,
        width_ratios=(1.0, 0.055),
        wspace=0.06,
        left=0.12,
        right=0.92,
        bottom=0.14,
        top=0.94,
    )
    ax = fig.add_subplot(gs[0, 0])
    cax = fig.add_subplot(gs[0, 1])
    extent = (float(x[0]), float(x[-1]), float(energies_ev[0]), float(energies_ev[-1]))
    im = ax.imshow(
        z,
        origin="lower",
        aspect="auto",
        extent=extent,
        cmap=cmap,
        vmin=vmin,
        vmax=vmax,
        interpolation="nearest",
    )
    ax.axhline(0.0, color="0.25", linestyle="--", linewidth=1.1, alpha=0.85)
    ax.set_xlim(float(x[0]), float(x[-1]))
    ax.set_ylim(ENERGY_MIN_EV, ENERGY_MAX_EV)
    ax.set_box_aspect(1.0)
    _set_pi_ticks(ax, float(x[0]), float(x[-1]))
    ax.set_xlabel(r"$k_x a$", fontsize=LABEL_SIZE)
    ax.set_ylabel(r"$E\;(\mathrm{eV})$", fontsize=LABEL_SIZE)
    ax.tick_params(axis="both", which="major", labelsize=TICK_SIZE)

    cbar = fig.colorbar(im, cax=cax)
    cbar.set_label(_SPECTRAL_CBAR_LABEL, fontsize=CBAR_LABEL_SIZE)
    cbar.ax.tick_params(labelsize=TICK_SIZE - 1)

    OUT.mkdir(parents=True, exist_ok=True)
    for path in output_paths:
        fig.savefig(path, dpi=DPI, facecolor="white", bbox_inches="tight")
    plt.close(fig)


def main() -> int:
    if not DATASET.exists():
        raise FileNotFoundError(
            f"Missing {DATASET}. Run: python main.py inputs/inputParams.wsm_orenstein.cfg -ldos"
        )

    from qxti.data.io import load_dataset_npz

    data = load_dataset_npz(DATASET)
    if "spectral" not in data or "spectral_path_k" not in data:
        raise KeyError(f"{DATASET} does not contain a spectral map/path.")

    m = _load_model()
    params = _load_model_params(m)
    a = float(params.get("a", 1.0))
    ev_per_hartree = float(data.get("au_to_ev", getattr(m, "EV_PER_HARTREE", 27.211386245988)))

    spectral = np.asarray(data["spectral"], dtype=float)  # (Nk, NE)
    energies_ev = np.asarray(data["energies"], dtype=float) * ev_per_hartree
    path_k = np.asarray(data["spectral_path_k"], dtype=float)
    direction = _single_path_direction(path_k)
    x = path_k[:, direction] * a

    _render_spectral_map(
        spectral=spectral,
        energies_ev=energies_ev,
        x=x,
        data=data,
        output_paths=(OUT_MAIN, OUT_ALIAS),
    )

    print(f"[arc-ldos] wrote {OUT_MAIN}")
    print(f"[arc-ldos] wrote {OUT_ALIAS}")
    normal_axis, n_normal = _surface_config_from_input()
    bulk_spectral = _projected_bulk_spectral_from_path(
        m,
        params,
        path_k,
        np.asarray(data["energies"], dtype=float),
        float(data.get("eta", 5.0e-5)),
        normal_axis=normal_axis,
        n_normal=n_normal,
    )
    _render_spectral_map(
        spectral=bulk_spectral,
        energies_ev=energies_ev,
        x=x,
        data=data,
        output_paths=(OUT_BULK_MAIN, OUT_BULK_ALIAS),
    )
    print(f"[arc-ldos] wrote {OUT_BULK_MAIN}")
    print(f"[arc-ldos] wrote {OUT_BULK_ALIAS}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
