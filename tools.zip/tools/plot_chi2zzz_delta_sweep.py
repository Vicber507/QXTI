#!/usr/bin/env python3
"""Chi^(2)_zzz vs frequency for several Delta values — single panel, same style as
wsm_orenstein_chi2_selected_components_single_panel.png.

Frequency on x-axis, |chi^(2)_zzz| on y-axis, one curve per Delta value,
using the same palette, fill style, line weight, and font sizes.
"""
from __future__ import annotations

import os, sys
from dataclasses import replace
from pathlib import Path

import numpy as np

os.environ.setdefault("MPLCONFIGDIR", "/private/tmp")
os.environ.setdefault("XDG_CACHE_HOME", "/private/tmp")
PROJECT_ROOT = Path(__file__).resolve().parents[1]
for _p in (PROJECT_ROOT, PROJECT_ROOT / "tools"):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

from qxti.core.config import QXTIConfig
from qxti.core.simulation import QXTISimulation
from qxti.analytics.theory_response import build_k_integration_weights
from _shg_tensor_gridbased import order2_full_tensor_spectrum

_EV = 27.211386245988
OUT = Path("outputs/susceptibility_maps/wsm_orenstein")

# Same palette as plot_susceptibility_maps.py PLOT_PALETTE
PALETTE = (
    "#59819E",
    "#7C7AA2",
    "#F67E7D",
    "#FFC0A7",
    "#6CC2BD",
    "#4A4A4A",
)

DELTAS = (0.5, 0.375, 0.25, 0.125, 0.0)


def compute_chi2zzz(cfg, omega_arr):
    sim = QXTISimulation(config=cfg)
    ham = sim.build_hamiltonian()
    kg  = sim.build_kgrid(ham)
    wts = build_k_integration_weights(cfg, hamiltonian=ham, kgrid=kg)
    sigma2 = order2_full_tensor_spectrum(ham, kg, omega_arr, wts,
                                         cfg.susceptibility_solver, progress=False)
    chi2 = sigma2 / (2j * omega_arr[:, None, None, None])
    return np.abs(chi2[:, 2, 2, 2])


def main():
    cfg_base = QXTIConfig.from_file("inputs/inputParams.wsm_orenstein.cfg")
    cfg_base = replace(cfg_base, kgrid=replace(cfg_base.kgrid, k_points=(50, 50, 50)))

    emin, emax, nw = 0.05, 2.5, 150
    omega = np.linspace(emin / _EV, emax / _EV, nw)
    e_ev  = omega * _EV

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from plot_susceptibility_maps import _set_energy_ticks
    from qxti.graphics.plot_susceptibility_tensor import apply_paper_style
    apply_paper_style()

    # Compute all curves first
    curves = []
    for delta in DELTAS:
        params = dict(cfg_base.hamiltonian.params)
        params["Delta"] = float(delta)
        cfg = replace(cfg_base,
                      hamiltonian=replace(cfg_base.hamiltonian, params=params))
        print(f"[chi2zzz-sweep] Delta={delta} ...", flush=True)
        curves.append(compute_chi2zzz(cfg, omega))

    ymax = max(float(np.nanmax(y)) for y in curves)

    fig, ax = plt.subplots(figsize=(10.4, 10.4))

    for delta, color, y in zip(DELTAS, PALETTE, curves):
        ax.fill_between(e_ev, y, color=color, alpha=0.18, lw=0, zorder=2)
        ax.plot(e_ev, y, color=color, lw=4.2, label=rf"$\Delta={delta:g}$", zorder=3)

    ax.set_xlim(float(e_ev[0]), float(e_ev[-1]))
    ax.set_ylim(0.0, ymax * 1.15 if ymax > 0 else 1.0)
    ax.set_box_aspect(1.0)
    _set_energy_ticks(ax, e_ev)
    ax.set_xlabel(r"$\hbar\omega\;(\mathrm{eV})$", fontsize=36, labelpad=13)
    ax.set_ylabel(r"$|\chi^{(2)}_{zzz}(2\omega)|$  (arb.)", fontsize=36, labelpad=15)
    ax.tick_params(axis="both", which="major", labelsize=32, length=10, width=1.4)
    ax.tick_params(axis="both", which="minor", length=5, width=1.1)
    ax.ticklabel_format(axis="y", style="sci", scilimits=(-2, 3))
    ax.yaxis.get_offset_text().set_fontsize(29)
    for spine in ax.spines.values():
        spine.set_linewidth(1.4)
    ax.legend(frameon=False, fontsize=32, handlelength=1.9,
              labelspacing=0.65, loc="upper right")

    # Mark the peak of each non-trivial curve
    text_offsets = [0.06, -0.55, -0.55, -0.55]   # alternate left/right
    for i, (delta, color, y) in enumerate(zip(DELTAS, PALETTE, curves)):
        peak_val = float(np.nanmax(y))
        if peak_val < ymax * 0.02:   # skip near-zero (Delta=0)
            continue
        idx_peak = int(np.nanargmax(y))
        ep = e_ev[idx_peak]
        # dot at peak
        ax.scatter([ep], [y[idx_peak]], s=140, color=color, zorder=8, edgecolors="white", linewidths=1.5)
        # vertical dashed line
        ax.axvline(ep, color=color, lw=1.0, ls=":", alpha=0.50, zorder=1)
        # label with peak position
        dx = text_offsets[i] if i < len(text_offsets) else 0.06
        ax.annotate(
            rf"${ep:.2f}$ eV",
            xy=(ep, y[idx_peak]),
            xytext=(ep + dx, y[idx_peak] + ymax * 0.03),
            fontsize=22, color=color, fontweight="bold",
            arrowprops=dict(arrowstyle="-", color=color, lw=0.8, alpha=0.7),
        )

    fig.subplots_adjust(left=0.21, right=0.96, bottom=0.15, top=0.96)

    OUT.mkdir(parents=True, exist_ok=True)
    f = OUT / "wsm_orenstein_chi2zzz_delta_sweep.png"
    fig.savefig(f, dpi=200, facecolor="white")
    plt.close(fig)
    print(f"[chi2zzz-sweep] wrote {f}")


if __name__ == "__main__":
    main()
