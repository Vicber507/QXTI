#!/usr/bin/env python3
"""2D map of |A^z_12(ky,kz)| at kx=pi/2 for each Delta value.

One panel per Delta, same layout as chi2 delta sweep.
"""
from __future__ import annotations

import os, sys, importlib.util
from pathlib import Path
import numpy as np

os.environ.setdefault("MPLCONFIGDIR", "/private/tmp")
os.environ.setdefault("XDG_CACHE_HOME", "/private/tmp")
PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

_EV = 27.211386245988
OUT = Path("outputs/susceptibility_maps/wsm_orenstein")

PALETTE = ("#59819E", "#7C7AA2", "#F67E7D", "#FFC0A7", "#6CC2BD", "#4A4A4A")
DELTAS  = (0.5, 0.375, 0.25, 0.125, 0.0)


def compute_Ac(mod, p, kx_fixed, N, dk=1e-3):
    a = float(p["a"])
    ky_vals = np.linspace(-np.pi/4/a, np.pi/4/a, N)
    kz_vals = np.linspace(-np.pi/4/a, np.pi/4/a, N)
    Ac = np.empty((N, N))
    for i, ky in enumerate(ky_vals):
        for j, kz in enumerate(kz_vals):
            k = np.array([kx_fixed, ky, kz])
            e, U = np.linalg.eigh(mod.H(*k, p))
            Ud = np.conj(U.T)
            sh = np.zeros(3); sh[2] = dk
            dH = (mod.H(*(k+sh), p) - mod.H(*(k-sh), p)) / (2*dk)
            vz = Ud @ dH @ U
            eps12 = e[2] - e[1]
            Ac[i, j] = abs(1j * vz[1, 2] / eps12) if abs(eps12) > 1e-15 else 0.0
    return ky_vals * float(p["a"]), kz_vals * float(p["a"]), Ac


def main():
    spec = importlib.util.spec_from_file_location(
        "wsm_o", PROJECT_ROOT / "models" / "wsm_orenstein.py")
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.colors import LogNorm
    from qxti.graphics.plot_susceptibility_tensor import apply_paper_style

    p_base = mod.default_params()
    a = float(p_base["a"])
    kx_fixed = np.pi / (2.0 * a)
    N = 180

    apply_paper_style()
    n = len(DELTAS)
    fig, axes = plt.subplots(1, n, figsize=(5.0 * n, 5.8), squeeze=False)
    axes = axes[0]

    ticks  = np.array([-np.pi/4, 0.0, np.pi/4])
    tlabels = [r"$-\pi/4$", r"$0$", r"$\pi/4$"]

    # shared color scale: compute all first
    print("[Ac-2d] computing maps ...")
    all_Ac = []
    all_kya = []
    all_kza = []
    for delta in DELTAS:
        p = dict(p_base); p["Delta"] = float(delta)
        print(f"  Delta={delta} ...", flush=True)
        kya, kza, Ac = compute_Ac(mod, p, kx_fixed, N)
        all_Ac.append(Ac); all_kya.append(kya); all_kza.append(kza)

    vmin_global = min(np.percentile(Ac[Ac > 0], 2)  for Ac in all_Ac)
    vmax_global = max(np.percentile(Ac, 99.5) for Ac in all_Ac)
    norm = LogNorm(vmin=vmin_global, vmax=vmax_global)

    for k, (delta, color, kya, kza, Ac) in enumerate(
            zip(DELTAS, PALETTE, all_kya, all_kza, all_Ac)):
        ax = axes[k]
        KYA, KZA = np.meshgrid(kya, kza, indexing="ij")
        im = ax.pcolormesh(KYA, KZA, np.clip(Ac, vmin_global, None),
                           shading="auto", cmap="inferno", norm=norm)

        # Weyl node positions
        ky_node_a = np.arctan(float(delta))   # kya at node (a=1)
        if abs(delta) > 1e-10:
            for s in [+1, -1]:
                ax.scatter([s * ky_node_a], [0.0], s=100,
                           facecolors="white", edgecolors=color,
                           linewidths=2.0, zorder=7)

        ax.set_title(rf"$\Delta={delta:g}$", fontsize=22, pad=6, color=color)
        ax.set_xlabel(r"$k_y a$", fontsize=20, labelpad=6)
        if k == 0:
            ax.set_ylabel(r"$k_z a$", fontsize=20, labelpad=6)
        ax.set_xticks(ticks); ax.set_xticklabels(tlabels, fontsize=16)
        ax.set_yticks(ticks); ax.set_yticklabels(tlabels if k == 0 else [], fontsize=16)
        ax.tick_params(labelsize=16)

    # shared colorbar
    cb = fig.colorbar(im, ax=axes.tolist(), pad=0.02, fraction=0.018)
    cb.set_label(r"$|\mathcal{A}^z_{12}(\mathbf{k})|$  (Bohr)", fontsize=18)
    cb.ax.tick_params(labelsize=14)

    fig.suptitle(r"Berry connection $|\mathcal{A}^z_{12}|$,  $k_x a=\pi/2$",
                 fontsize=20, y=1.02)
    fig.tight_layout()

    OUT.mkdir(parents=True, exist_ok=True)
    f = OUT / "wsm_orenstein_berry_connection_2d_delta_sweep.png"
    fig.savefig(f, dpi=220, facecolor="white", bbox_inches="tight")
    plt.close(fig)
    print(f"[Ac-2d] wrote {f}")


if __name__ == "__main__":
    main()
