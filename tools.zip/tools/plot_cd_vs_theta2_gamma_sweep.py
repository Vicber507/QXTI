#!/usr/bin/env python3
r"""SHG circular dichroism vs analyzer angle theta2, for a sweep of dephasing rates gamma.

Geometry (Wu/Orenstein Nat. Phys. 2017, Fig. 2c):
  * Light incident along [112], polarization plane = (112) crystal plane.
  * Generator: right-circular (sigma+, ellip=+1) and left-circular (sigma-, ellip=-1).
  * Analyzer angle theta2 rotates a linear polarizer within the (112) plane:
        theta2 = 0   -->  [1, 1,-1] crystal axis  (= analyzer along e1)
        theta2 = 90  -->  [1,-1, 0] crystal axis  (= analyzer along e2)
    The detected SHG intensity is  I(theta2) = |a(theta2).J(2w)|^2
    where a(theta2) = cos(theta2) e1 + sin(theta2) e2.
  * Circular dichroism:  CD(theta2) = I_{sigma+}(theta2) - I_{sigma-}(theta2).

IMPORTANT – theta2 is NOT a run parameter in QXTI.
  In the experiment a physical polarizer is physically rotated.  In the code,
  we POST-PROCESS the complex SHG current J(2omega) from just two CMD runs
  (one sigma+, one sigma-) and ANALYTICALLY sweep a(theta2) over 0..360 deg.
  No additional simulations are needed to vary the analyzer angle.

Dephasing rate gamma = hbar / T2, where T2 = coherence_time (atomic units):
    gamma [meV] = 27211 / T2 [a.u.]

Available pre-computed run pairs (orenstein_112_cd_*):
    T2 =     220 a.u.  ->  gamma = 123.7 meV   (broadened, room temperature)
    T2 =    2200 a.u.  ->  gamma =  12.4 meV
    T2 =   22000 a.u.  ->  gamma =   1.2 meV
    T2 =     inf a.u.  ->  gamma =   0.0 meV   (gamma -> 0 limit)

T1 (population_time) controls diagonal density-matrix relaxation (intraband).
T2 (coherence_time) controls off-diagonal relaxation (interband coherences).
SHG is carried entirely by interband coherences, so T2 (= coherence_time) is
the physically relevant parameter for the CD amplitude and phase.
"""
from __future__ import annotations

import argparse
import configparser
import os
import sys
from pathlib import Path

import numpy as np

os.environ.setdefault("MPLCONFIGDIR", "/private/tmp")
os.environ.setdefault("XDG_CACHE_HOME", "/private/tmp")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

AU_TO_EV = 27.211386245988   # 1 Hartree in eV

# In-plane crystal axes for the (112) surface (paper convention)
E1 = np.array([1.0,  1.0, -1.0]) / np.sqrt(3.0)   # [1,1,-1]  theta2 = 0
E2 = np.array([1.0, -1.0,  0.0]) / np.sqrt(2.0)   # [1,-1,0]  theta2 = 90 deg

# Pre-computed run pairs indexed by folder name
_SWEEPS = [
    ("orenstein_112_cd",          220.0,   "#0072B2"),  # blue
    ("orenstein_112_cd_ct2200",   2200.0,  "#009E73"),  # green
    ("orenstein_112_cd_ct22000",  22000.0, "#E69F00"),  # orange
    ("orenstein_112_cd_nogamma",  np.inf,  "#CC79A7"),  # pink
]

_DEFAULT_OUT = PROJECT_ROOT / "outputs" / "cd_theta2_gamma_sweep"


def _gamma_meV(T2_au: float) -> float:
    return 0.0 if np.isinf(T2_au) else AU_TO_EV / T2_au * 1000.0


def _load_J2(run_dir: Path) -> tuple[np.ndarray, float]:
    """Return complex SHG current J(2w0) and omega0 for a CMD run."""
    cfg = configparser.ConfigParser(inline_comment_prefixes=("#",))
    cfg.optionxform = str
    cfg.read(run_dir / "input.cfg")
    omega0 = float(cfg["laser"]["omega"])
    d = np.load(run_dir / "cmd" / "data" / "current_spectrum.npz",
                allow_pickle=True)
    omega = np.asarray(d["omega_axis"], dtype=float)
    spec  = np.asarray(d["current_spectrum"], dtype=complex)
    idx   = int(np.argmin(np.abs(omega - 2.0 * omega0)))
    return spec[idx], omega0


def _cd_curve(J_plus: np.ndarray, J_minus: np.ndarray,
               theta: np.ndarray) -> np.ndarray:
    """CD(theta2) = I_sigma+(theta2) - I_sigma-(theta2), raw (unnormalized)."""
    ct, st = np.cos(theta), np.sin(theta)
    ap = ct * np.dot(E1, J_plus)  + st * np.dot(E2, J_plus)
    am = ct * np.dot(E1, J_minus) + st * np.dot(E2, J_minus)
    return np.abs(ap) ** 2 - np.abs(am) ** 2


def _sin2cos2_fit(theta_rad: np.ndarray, y: np.ndarray):
    """Least-squares fit  A sin(2θ + φ) to y.
    Returns: amplitude, phase_deg, fine_phi_deg, fine_fit."""
    s2 = np.sin(2 * theta_rad)
    c2 = np.cos(2 * theta_rad)
    coeff, *_ = np.linalg.lstsq(np.column_stack([s2, c2]), y, rcond=None)
    a_s, a_c   = coeff
    amp        = float(np.hypot(a_s, a_c))
    phase_deg  = float(np.degrees(np.arctan2(a_c, a_s)))
    phi_f      = np.linspace(0, 2 * np.pi, 720)
    fit_fine   = a_s * np.sin(2 * phi_f) + a_c * np.cos(2 * phi_f)
    return amp, phase_deg, np.degrees(phi_f), fit_fine


def main() -> int:
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument("--sweeps-root",
                    default=str(PROJECT_ROOT / "outputs" / "sweeps"),
                    help="Root directory that contains the orenstein_112_cd_* folders.")
    ap.add_argument("--out", default=str(_DEFAULT_OUT))
    args = ap.parse_args()

    sweeps_root = Path(args.sweeps_root)
    out_dir     = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    theta      = np.linspace(0, 2 * np.pi, 361)
    theta_deg  = np.degrees(theta)

    # ── collect curves ────────────────────────────────────────────────────────
    curves = []   # (gamma_meV, T2_au, color, cd_norm, amp, phase_deg, fit_fine, phi_fine_deg)
    for folder, T2, color in _SWEEPS:
        base = sweeps_root / folder
        sp_dir = base / "001_ellip=1"
        sm_dir = base / "000_ellip=-1"
        if not sp_dir.exists() or not sm_dir.exists():
            print(f"[CD-gamma] skipping {folder}: run directories not found")
            continue
        Jp, omega0 = _load_J2(sp_dir)
        Jm, _      = _load_J2(sm_dir)
        cd_raw     = _cd_curve(Jp, Jm, theta)
        norm       = float(np.max(np.abs(cd_raw))) or 1.0
        cd_n       = cd_raw / norm
        amp, phase_deg, phi_f_deg, fit_fine = _sin2cos2_fit(theta, cd_n)
        gamma      = _gamma_meV(T2)
        curves.append((gamma, T2, color, cd_n, amp, phase_deg, fit_fine, phi_f_deg))
        print(f"[CD-gamma]  gamma={gamma:7.2f} meV  T2={T2:>10.0f} au  "
              f"A={amp:.4f}  phase={phase_deg:+.1f} deg")

    if not curves:
        print("[CD-gamma] no valid run pairs found — check sweeps_root")
        return 1

    # ── plot ──────────────────────────────────────────────────────────────────
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    try:
        from qxti.graphics.plot_susceptibility_tensor import apply_paper_style
        apply_paper_style()
    except Exception:
        pass

    fig, ax = plt.subplots(figsize=(5.5, 4.4))

    ax.axhline(0.0, color="0.65", lw=0.9, zorder=0)
    for y in (-1.0, 1.0):
        ax.axhline(y, color="0.75", lw=0.55, ls="--", zorder=0)

    for gamma, T2, color, cd_n, amp, phase_deg, fit_fine, phi_f_deg in curves:
        if np.isinf(T2):
            lbl = rf"$\gamma=0$ meV  ($T_2\to\infty$)"
        else:
            lbl = rf"$\gamma={gamma:.1f}$ meV  ($T_2={T2:.0f}$ a.u.)"
        ax.plot(theta_deg, cd_n, "-", color=color, lw=2.0, label=lbl)

    # fit overlay for the most broadened case (most experimental-like)
    _g, _T2, _col, _cd, _amp, _ph, fit_fine, phi_f_deg = curves[0]
    ax.plot(phi_f_deg, fit_fine, ":", color=_col, lw=1.2, alpha=0.75,
            label=rf"fit  $A\sin(2\theta_2+\varphi_0)$,  $A={_amp:.2f}$")

    ax.set_xlim(0, 360)
    ax.set_ylim(-1.25, 1.25)
    ax.set_xticks([0, 90, 180, 270, 360])
    ax.set_xticklabels(
        [r"$0°$" "\n" r"$[1,1,\bar{1}]$",
         r"$90°$" "\n" r"$[1,\bar{1},0]$",
         r"$180°$" "\n" r"$[1,1,\bar{1}]$",
         r"$270°$" "\n" r"$[1,\bar{1},0]$",
         r"$360°$"],
        fontsize=9,
    )
    ax.set_xlabel(r"analyzer angle  $\theta_2$  in (112) plane", fontsize=12)
    ax.set_ylabel(
        r"$\mathrm{CD}(\theta_2)\,/\,|\mathrm{peak}|$",
        fontsize=12,
    )
    ax.set_title(
        r"SHG circular dichroism vs analyzer angle, TaAs (112)"
        "\n"
        r"$\gamma = \hbar/T_2$  (coherence\_time in config)",
        fontsize=11,
    )
    ax.legend(loc="lower center", fontsize=9.5, ncol=1,
              bbox_to_anchor=(0.5, -0.01))

    # crystal-axis guide lines
    for xv in [0, 90, 180, 270, 360]:
        ax.axvline(xv, color="0.80", lw=0.6, ls=":", zorder=0)

    fig.tight_layout()
    png = out_dir / "cd_vs_theta2_gamma_sweep.png"
    pdf = out_dir / "cd_vs_theta2_gamma_sweep.pdf"
    fig.savefig(png, dpi=300, facecolor="white", bbox_inches="tight")
    fig.savefig(pdf,           facecolor="white", bbox_inches="tight")
    plt.close(fig)
    print(f"[CD-gamma] wrote {png}")
    print(f"[CD-gamma] wrote {pdf}")

    # save summary
    np.savez_compressed(
        out_dir / "cd_vs_theta2_gamma_sweep.npz",
        theta2_deg=theta_deg,
        **{f"cd_gamma{c[0]:.0f}meV": c[3] for c in curves},
        **{f"amp_gamma{c[0]:.0f}meV": c[4] for c in curves},
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
