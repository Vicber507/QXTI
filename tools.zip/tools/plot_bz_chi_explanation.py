#!/usr/bin/env python3
"""Explanatory figure: BZ chi2 integrand with physical annotations.

Produces a 3-panel figure:
  (a) Re I^(2)_zzz(k) on kz=0 — signed map showing the 4 Weyl poles
  (b) |I^(2)_zzz(k)| on kz=0 — magnitude showing the 1/eps divergence
  (c) 1D radial cut from a Weyl node showing the pole structure and the
      three energy scales: eps_mn, omega, 2omega

Usage:
    python tools/plot_bz_chi_explanation.py
"""
from __future__ import annotations
import math, os, sys
from pathlib import Path
import numpy as np

os.environ.setdefault("MPLCONFIGDIR", "/private/tmp")
os.environ.setdefault("XDG_CACHE_HOME", "/private/tmp")
PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm, LogNorm
from matplotlib.patches import FancyArrowPatch

from qxti.graphics.custom_cmap import custom_cmap_div
from qxti.graphics.plot_susceptibility_tensor import apply_paper_style

OUT = Path("outputs/bz_chi_contribution/berry_curvature")
OUT.mkdir(parents=True, exist_ok=True)
_EV = 27.211386245988


def _pi_ticks(ax, vals, which="x"):
    lo, hi = float(vals[0]), float(vals[-1])
    step = np.pi / 2
    first = math.ceil((lo - 1e-9) / step) * step
    ticks = np.arange(first, hi + step * 0.5, step)
    ticks = ticks[(ticks >= lo - 1e-9) & (ticks <= hi + 1e-9)]
    _tex = {0.0: r"$0$", np.pi/2: r"$\frac{\pi}{2}$", np.pi: r"$\pi$",
            3*np.pi/2: r"$\frac{3\pi}{2}$", 2*np.pi: r"$2\pi$"}
    labels = [next((v for k2, v in _tex.items() if abs(t-k2) < 1e-9),
                   rf"${t/np.pi:.2g}\pi$") for t in ticks]
    if which == "x":
        ax.set_xticks(ticks); ax.set_xticklabels(labels, fontsize=13)
    else:
        ax.set_yticks(ticks); ax.set_yticklabels(labels, fontsize=13)


def _overlay_nodes(ax, nodes_disp, col):
    for (kxp, kyp, chi) in nodes_disp:
        c = col[chi]
        ax.scatter([kxp], [kyp], s=180, facecolors=c, edgecolors="white",
                   linewidths=1.8, zorder=7)
        ax.text(kxp, kyp, "+" if chi > 0 else "-", color="white",
                ha="center", va="center", fontsize=12, fontweight="bold", zorder=8)


def _radial_cut(Hf, node, params, omega_ev=0.8, gamma_ev=0.05):
    """Compute |I_zzz| along a 1D radial line from the Weyl node."""
    import importlib.util
    from qxti.analytics.theory_response import _resolve_distribution

    a = float(params.get("a", 1.0))
    omega = omega_ev / _EV
    gamma = gamma_ev / _EV
    dk = 1e-3

    dkx_vals = np.linspace(0.001, 0.8, 120)
    I_vals = []

    def H(k): return Hf(*k)

    for dkx in dkx_vals:
        k = node + np.array([dkx, 0., 0.])
        H0 = H(k)
        e, U = np.linalg.eigh(H0)
        Ud = np.conj(U.T)

        def vel(axis):
            sh = np.zeros(3); sh[axis] = dk
            return Ud @ ((H(k+sh) - H(k-sh)) / (2*dk)) @ U

        vx = vel(0); vy = vel(1); vz = vel(2)
        eps = e[:, None] - e[None, :]
        fmn = np.zeros_like(eps)
        for i in range(len(e)):
            for j in range(len(e)):
                fmn[i, j] = (1.0 if e[i] < 0 else 0.0) - (1.0 if e[j] < 0 else 0.0)
        nb = len(e)
        valid = ~np.eye(nb, dtype=bool)

        omega1 = complex(omega, gamma)
        omega2 = complex(2*omega, gamma)

        A_z = np.where(valid, 1j * vz * np.where(valid, 1/eps, 0.0), 0j)
        with np.errstate(divide="ignore", invalid="ignore"):
            rho1 = np.where(valid, (A_z * fmn) / (omega1 - eps), 0j)

        sh = np.zeros(3); sh[2] = dk
        ep = e.copy(); Um = np.linalg.eigh(H(k+sh))[1]
        em = np.linalg.eigh(H(k-sh))[1]
        Wp = Ud @ Um; Wm = Ud @ em
        rho1_plus  = Wp @ rho1 @ np.conj(Wp.T)
        rho1_minus = Wm @ rho1 @ np.conj(Wm.T)
        d_rho1 = (rho1_plus - rho1_minus) / (2*dk)

        comm = A_z @ rho1 - rho1 @ A_z
        with np.errstate(divide="ignore", invalid="ignore"):
            inv_d2 = np.where(valid, 1.0 / (omega2 - eps), 0j)
        rho2 = (d_rho1 - 1j * comm) * inv_d2

        current_op = -vz
        integrand = np.conj(np.einsum("mn,nm->", current_op, rho2))
        chi_integrand = integrand / (-1j * 2 * omega)
        I_vals.append(abs(chi_integrand))

    return dkx_vals, np.array(I_vals)


def main():
    import importlib.util
    from qxti.core import QXTIConfig
    from qxti.core.simulation import QXTISimulation

    cfg = QXTIConfig.from_file("inputs/inputParams.wsm_orenstein.cfg")
    sim = QXTISimulation(config=cfg)
    Hf = sim.build_hamiltonian()._matrix_at

    spec = importlib.util.spec_from_file_location(
        "wsm_o", PROJECT_ROOT / "models" / "wsm_orenstein.py")
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    params = mod.default_params()
    a_lat = float(params.get("a", 1.0))
    k_offset = np.pi

    # Load the saved chi2_zzz integrand data
    data_path = Path("outputs/bz_chi_contribution/chi2_zzz/chi2_zzz_kz_0_real.npz")
    if not data_path.exists():
        print("[explain] need to run chi contribution first: "
              "python tools/plot_bz_chi_contribution.py --component zzz --part real")
        return 1
    d = np.load(data_path, allow_pickle=True)
    chi_re = np.real(d["chi_integrand"])   # (Nx, Ny)
    chi_im = np.imag(d["chi_integrand"])
    x_plot = d["x_axis_plot"]
    y_plot = d["y_axis_plot"]
    omega_ev = float(d["omega_ev"])
    gamma_ev = float(d["gamma"]) * _EV

    nodes_raw = mod.weyl_nodes_with_chirality(params)
    nodes_disp = [(nd["k"][0]*a_lat + k_offset,
                   nd["k"][1]*a_lat + k_offset,
                   int(nd["chirality"])) for nd in nodes_raw if abs(nd["k"][2]) < 0.01]
    col = {+1: "#E8000B", -1: "#1E64C8"}

    # Radial cut from node at (-1.6766, -0.4636, 0)
    node = np.array([-1.6766, -0.4636, 0.0])
    print("[explain] computing 1D radial cut ...")
    dkx_vals, I_radial = _radial_cut(Hf, node, params, omega_ev=omega_ev, gamma_ev=gamma_ev)

    # pole model: I ~ C / sqrt(eps^2 + gamma^2) with eps = v_F * dkx
    v_F = 0.16  # approximate Weyl velocity in a.u. from linear fit
    eps_arr = v_F * dkx_vals
    I_pole = I_radial[0] * gamma_ev / _EV / np.sqrt(eps_arr**2 + (gamma_ev/_EV)**2)

    apply_paper_style()
    fig = plt.figure(figsize=(16, 5.5))
    gs = fig.add_gridspec(1, 3, wspace=0.38, left=0.06, right=0.97,
                          bottom=0.14, top=0.93)

    # ── Panel (a): signed Re I_zzz ──────────────────────────────────────────
    ax_a = fig.add_subplot(gs[0])
    vmax_a = np.percentile(np.abs(chi_re), 99)
    norm_a = TwoSlopeNorm(vmin=-vmax_a, vcenter=0.0, vmax=vmax_a)
    X, Y = np.meshgrid(x_plot, y_plot, indexing="ij")
    im_a = ax_a.pcolormesh(X, Y, chi_re, shading="auto",
                            cmap=custom_cmap_div, norm=norm_a)
    _overlay_nodes(ax_a, nodes_disp, col)
    ax_a.set_xlabel(r"$k_x a$", fontsize=14)
    ax_a.set_ylabel(r"$k_y a$", fontsize=14)
    _pi_ticks(ax_a, x_plot, "x"); _pi_ticks(ax_a, y_plot, "y")
    cb_a = fig.colorbar(im_a, ax=ax_a, pad=0.02)
    cb_a.set_label(r"$\mathrm{Re}\,\mathcal{I}^{(2)}_{zzz}(\mathbf{k})$", fontsize=12)
    cb_a.ax.tick_params(labelsize=11)
    ax_a.set_title(r"(a) Signed integrand $\mathrm{Re}\,\mathcal{I}^{(2)}_{zzz}$,"
                   r"  $k_z=0$", fontsize=12, pad=5)
    # annotate chiralities
    for (kxp, kyp, chi) in nodes_disp:
        ax_a.annotate(rf"$\chi={chi:+d}$", xy=(kxp, kyp),
                      xytext=(kxp + 0.55, kyp + 0.4),
                      fontsize=9, color=col[chi],
                      arrowprops=dict(arrowstyle="-", color=col[chi], lw=0.8))

    # ── Panel (b): log |I_zzz| ──────────────────────────────────────────────
    ax_b = fig.add_subplot(gs[1])
    chi_abs = np.abs(d["chi_integrand"])
    vmin_b = np.percentile(chi_abs[chi_abs > 0], 5)
    vmax_b = np.max(chi_abs)
    norm_b = LogNorm(vmin=vmin_b, vmax=vmax_b)
    im_b = ax_b.pcolormesh(X, Y, chi_abs, shading="auto", cmap="inferno", norm=norm_b)
    _overlay_nodes(ax_b, nodes_disp, col)
    ax_b.set_xlabel(r"$k_x a$", fontsize=14)
    ax_b.set_ylabel(r"$k_y a$", fontsize=14)
    _pi_ticks(ax_b, x_plot, "x"); _pi_ticks(ax_b, y_plot, "y")
    cb_b = fig.colorbar(im_b, ax=ax_b, pad=0.02)
    cb_b.set_label(r"$|\mathcal{I}^{(2)}_{zzz}(\mathbf{k})|$  [log scale]", fontsize=12)
    cb_b.ax.tick_params(labelsize=11)
    ax_b.set_title(r"(b) Magnitude $|\mathcal{I}^{(2)}_{zzz}|$"
                   r"  (log scale) — pole enhancement", fontsize=12, pad=5)
    # annotate: hot region text
    ax_b.text(0.03, 0.04,
              r"$\sim 16\%$ of BZ" "\n" r"carries $>10\%$ of peak",
              transform=ax_b.transAxes, fontsize=9, color="white",
              bbox=dict(facecolor="0.2", alpha=0.7, boxstyle="round,pad=0.3"))

    # ── Panel (c): 1D radial cut — pole structure ───────────────────────────
    ax_c = fig.add_subplot(gs[2])
    dkx_ev = dkx_vals * a_lat   # in a.u. (= k*a)
    ax_c.semilogy(dkx_ev, I_radial, color="#1F77B4", lw=2.2,
                  label=r"$|\mathcal{I}^{(2)}_{zzz}|$ (computed)")
    ax_c.semilogy(dkx_ev, I_pole, color="#D62728", lw=1.5, ls="--",
                  label=r"$\sim\gamma/\sqrt{\varepsilon_{mn}^2+\gamma^2}$ (pole model)")

    # vertical lines for energy scales
    gamma_au = gamma_ev / _EV
    omega_au = omega_ev / _EV
    # convert energy to dkx: eps = v_F * dkx -> dkx = eps/v_F
    dkx_gamma = gamma_au / v_F
    dkx_omega = omega_au / v_F
    dkx_2omega = 2*omega_au / v_F

    for val, label, ls in [
        (dkx_gamma,  rf"$\gamma={gamma_ev:.0f}$ meV",    ":", ),
        (dkx_omega,  rf"$\hbar\omega={omega_ev:.1f}$ eV", "--",),
        (dkx_2omega, rf"$2\hbar\omega$",                  "-.",),
    ]:
        if val < dkx_ev[-1]:
            ax_c.axvline(val * a_lat, color="0.45", ls=ls, lw=1.2)
            ax_c.text(val * a_lat + 0.01, I_radial.max() * 0.4, label,
                      fontsize=8.5, color="0.3", rotation=90, va="top")

    ax_c.set_xlabel(r"$\delta k_x \cdot a$  (distance from Weyl node)", fontsize=13)
    ax_c.set_ylabel(r"$|\mathcal{I}^{(2)}_{zzz}|$  (a.u.)", fontsize=13)
    ax_c.set_title("(c) Pole structure along radial cut from Weyl node",
                   fontsize=12, pad=5)
    ax_c.legend(fontsize=9.5, framealpha=0.9, loc="upper right")
    ax_c.tick_params(labelsize=12)

    # annotation: pole order
    ax_c.annotate(r"$\sim\frac{1}{\varepsilon_{mn}\cdot\omega\cdot 2\omega}$"
                  "\n(three-pole structure)",
                  xy=(0.04, I_radial[2]), xytext=(0.15, I_radial[2]*0.2),
                  fontsize=9.5,
                  arrowprops=dict(arrowstyle="->", color="0.3", lw=1.0))

    out = OUT / "bz_chi_explanation.png"
    fig.savefig(out, dpi=240, facecolor="white")
    plt.close(fig)
    print(f"[explain] wrote {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
