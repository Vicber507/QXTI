"""Validation study for the TIME-DOMAIN multi-frequency perturbative engine.

Answers, with data and a figure, whether ``mesh_response.time_domain_currents``
(the engine used for >1 laser in both the HHG/cmd and susceptibility/xtp paths)
is correct and useful:

  A. CORRECTNESS — in the single-carrier (CW) limit the time-domain engine must
     reproduce the fast frequency-domain closed form (``harmonic_currents``) for
     every harmonic sω0, to ~machine precision ("converge 100%"), and the
     reconstructed current J(t) must be REAL (physical).
  B. MULTI-FREQUENCY — with two lasers (ω1, ω2) the time-domain current spectrum
     must contain the MIXING products (ω1±ω2, 2ω1, 2ω2, …) that the single-carrier
     closed form cannot produce.
  C. TIMING — quantify the (expected) overhead of the time integration vs the
     single-frequency closed form.
  D. TIME WINDOW — two pulses with a temporal offset must be integrated over the
     FULL window, from the first pulse onset to the last pulse end.

Self-contained (periodic 4-band TaAs Weyl model, so the mesh gradient is exact).
Writes ``outputs/time_domain_engine_study.png``.

    python tools/study_time_domain_engine.py
"""
from __future__ import annotations

import time
from pathlib import Path
import sys

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "tests"))

from test_mesh_response import natphys_H, _grid                     # periodic model
from qxti.analytics.mesh_response import (
    precompute_band_data, harmonic_currents, time_domain_currents,
)

GAMMA = 1.0 / 110.0
MU, T_AU = 0.0, 0.0


def _band(N):
    kpts, w, shape, bounds, h = _grid(N)
    band = precompute_band_data(natphys_H, kpts, shape, bounds, mu=MU, T_au=T_AU, dimension=3)
    return band, w


def _cw_field(Ez, w0, P, Q):
    """Monochromatic z-field over P periods, Q samples/period; w0 lands on an FFT bin."""
    Nt = P * Q
    dt = (2 * np.pi / w0) / Q
    t = np.arange(Nt) * dt
    E_t = np.zeros((Nt, 3))
    E_t[:, 2] = 2 * Ez * np.cos(w0 * t)            # = Ez e^{-iw0 t} + c.c.  (real)
    return E_t, dt, t


def partA_correctness(band, w):
    print("== A. CORRECTNESS: time-domain vs frequency-domain (CW limit) ==")
    w0, Ez, maxo = 0.02, 1.0e-3, 4
    Ecw = np.array([0, 0, Ez], complex)
    Jc = harmonic_currents(band, w, Ecw, w0, maxo, gamma=GAMMA, gamma_pop=GAMMA)
    rows = []          # (Q, {s: relerr})
    for Q in (16, 24, 32, 48, 64):
        E_t, dt, _ = _cw_field(Ez, w0, P=8, Q=Q)
        td = time_domain_currents(band, w, E_t, dt, maxo, gamma=GAMMA, gamma_pop=GAMMA)
        freq = td["freq"]
        errs, realness = {}, {}
        for s in range(1, maxo + 1):
            b = np.argmin(np.abs(freq + s * w0))
            amp = td["J_omega"][s][b, 2] / E_t.shape[0]
            errs[s] = abs(amp) and abs(abs(amp) - abs(Jc[s][2])) / abs(Jc[s][2])
            Jt = td["J_t"][s][:, 2]
            realness[s] = np.abs(Jt.imag).max() / max(np.abs(Jt.real).max(), 1e-30)
        rows.append((Q, errs, realness))
        print(f"  Q={Q:>3}/period: " +
              "  ".join(f"err|J{s}|={errs[s]:.1e}" for s in range(1, maxo + 1)) +
              f"   |  J(t) imag/real ~ {max(realness.values()):.0e}")
    return rows


def partB_mixing(band, w):
    print("\n== B. MULTI-FREQUENCY MIXING: two lasers ω1, ω2 ==")
    w1, w2, Ez = 0.02, 0.03, 1.0e-3          # commensurate so all mixings land on bins
    Q, P = 32, 12
    dw = np.gcd(2, 3)                          # dummy; build a common grid below
    base = 0.01                               # w1=2*base, w2=3*base -> base on a bin
    period = 2 * np.pi / base
    Nt = P * Q
    dt = period / Q
    t = np.arange(Nt) * dt
    E_t = np.zeros((Nt, 3))
    E_t[:, 2] = 2 * Ez * np.cos(w1 * t)
    E_t[:, 0] = 2 * Ez * np.cos(w2 * t)       # different direction, different freq
    td = time_domain_currents(band, w, E_t, dt, 3, gamma=GAMMA, gamma_pop=GAMMA)
    freq = td["freq"]
    Jtot_w = sum(td["J_omega"][s] for s in (1, 2, 3))
    Jmag = np.linalg.norm(Jtot_w, axis=1)
    realness = max(np.abs(td["J_t"][s].imag).max() /
                   max(np.abs(td["J_t"][s].real).max(), 1e-30) for s in (1, 2, 3))
    print(f"  J(t) imag/real ~ {realness:.0e}  (physical, real)")
    labels = [("w1", w1), ("w2", w2), ("w2-w1", w2 - w1), ("w1+w2", w1 + w2),
              ("2w1", 2 * w1), ("2w2", 2 * w2), ("2w2-w1", 2 * w2 - w1),
              ("2w1+w2", 2 * w1 + w2)]
    peaks = []
    for lbl, wt in labels:
        b = np.argmin(np.abs(freq + wt))
        peaks.append((lbl, wt, Jmag[b]))
        print(f"  |J({lbl:>6} = {wt:.3f})| = {Jmag[b]:.3e}")
    return freq, Jmag, peaks


def partC_timing(w):
    print("\n== C. TIMING: time-domain vs frequency closed form ==")
    w0, Ez = 0.02, 1.0e-3
    Ecw = np.array([0, 0, Ez], complex)
    rows = []
    for N in (6, 8, 10, 12):
        band, wN = _band(N)
        E_t, dt, _ = _cw_field(Ez, w0, P=8, Q=32)
        t0 = time.perf_counter()
        harmonic_currents(band, wN, Ecw, w0, 3, gamma=GAMMA, gamma_pop=GAMMA)
        t_freq = time.perf_counter() - t0
        t0 = time.perf_counter()
        time_domain_currents(band, wN, E_t, dt, 3, gamma=GAMMA, gamma_pop=GAMMA)
        t_time = time.perf_counter() - t0
        rows.append((N ** 3, t_freq, t_time))
        print(f"  Nk={N**3:>6}: freq={t_freq:.3f}s  time-domain={t_time:.3f}s "
              f"(Nt={E_t.shape[0]})  overhead x{t_time/max(t_freq,1e-9):.0f}")
    return rows


def partD_window(band, w):
    print("\n== D. TIME WINDOW: two offset pulses integrated over the full span ==")
    w1, w2, Ez = 0.02, 0.03, 1.0e-3
    dt = 4.0
    t0a, t0b = 3000.0, 9000.0                 # two pulses, well separated in time
    sig = 900.0
    Nt = int(12000 / dt)
    t = np.arange(Nt) * dt
    E_t = np.zeros((Nt, 3))
    E_t[:, 2] = 2 * Ez * np.exp(-0.5 * ((t - t0a) / sig) ** 2) * np.cos(w1 * (t - t0a))
    E_t[:, 2] += 2 * Ez * np.exp(-0.5 * ((t - t0b) / sig) ** 2) * np.cos(w2 * (t - t0b))
    td = time_domain_currents(band, w, E_t, dt, 3, gamma=GAMMA, gamma_pop=GAMMA)
    Jt = sum(td["J_t"][s][:, 2].real for s in (1, 2, 3))
    print(f"  window [{t[0]:.0f}, {t[-1]:.0f}] a.u., pulses at t0={t0a:.0f} and {t0b:.0f}")
    print(f"  current active in BOTH pulses: |J| near pulse1={np.abs(Jt[np.argmin(np.abs(t-t0a))]):.2e}, "
          f"near pulse2={np.abs(Jt[np.argmin(np.abs(t-t0b))]):.2e}")
    return t, E_t[:, 2], Jt


def make_figure(rowsA, B, rowsC, D, out_path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(2, 2, figsize=(14, 9))
    fig.suptitle("Time-domain multi-frequency perturbative engine — validation",
                 fontsize=13, fontweight="bold")

    # A: convergence (rel error time vs freq per order) vs samples/period
    a = ax[0, 0]
    Qs = [r[0] for r in rowsA]
    for s in (1, 2, 3, 4):
        a.plot(Qs, [max(r[1][s], 1e-17) for r in rowsA], "-o", label=f"order {s}")
    a.set_yscale("log"); a.set_title("A. |J$_{time}$−J$_{freq}$|/|J$_{freq}$| (CW limit)")
    a.set_xlabel("samples / period"); a.set_ylabel("relative error")
    a.axhline(1e-13, color="gray", ls="--", lw=1)
    a.grid(True, which="both", alpha=0.3); a.legend(fontsize=8, ncol=2)

    # B: multi-frequency spectrum with mixing peaks
    a = ax[0, 1]
    freq, Jmag, peaks = B
    pos = freq > 0
    a.semilogy(freq[pos], Jmag[pos] + 1e-30, color="C0", lw=1)
    for lbl, wt, mag in peaks:
        a.annotate(lbl, (wt, mag), fontsize=7, ha="center",
                   textcoords="offset points", xytext=(0, 4), color="C3")
        a.plot([wt], [mag], "o", color="C3", ms=4)
    a.set_title("B. two-laser spectrum: mixing products appear")
    a.set_xlabel("ω (a.u.)"); a.set_ylabel("|J(ω)|"); a.set_xlim(0, 0.08)
    a.grid(True, which="both", alpha=0.3)

    # C: timing
    a = ax[1, 0]
    Nk = [r[0] for r in rowsC]
    a.plot(Nk, [r[1] for r in rowsC], "-o", label="frequency (closed form)")
    a.plot(Nk, [r[2] for r in rowsC], "-s", label="time-domain (multi-freq)")
    a.set_xscale("log"); a.set_yscale("log")
    a.set_title("C. runtime vs $N_k$"); a.set_xlabel("$N_k$"); a.set_ylabel("time (s)")
    a.grid(True, which="both", alpha=0.3); a.legend(fontsize=9)

    # D: time window (two offset pulses) — field and current
    a = ax[1, 1]
    t, Efield, Jt = D
    a.plot(t, Efield / (np.abs(Efield).max() + 1e-30), color="0.6", lw=0.8, label="E(t) (norm.)")
    a.plot(t, Jt / (np.abs(Jt).max() + 1e-30), color="C0", lw=0.8, label="J(t) (norm.)")
    a.set_title("D. two offset pulses — full window integrated")
    a.set_xlabel("t (a.u.)"); a.set_ylabel("normalized"); a.legend(fontsize=9)
    a.grid(True, alpha=0.3)

    fig.tight_layout(rect=[0, 0, 1, 0.96])
    fig.savefig(out_path, dpi=140)
    print(f"\n[figura guardada] {out_path}")


def main():
    band, w = _band(8)
    rowsA = partA_correctness(band, w)
    B = partB_mixing(band, w)
    rowsC = partC_timing(w)
    D = partD_window(band, w)
    out = Path("outputs/time_domain_engine_study.png")
    out.parent.mkdir(parents=True, exist_ok=True)
    make_figure(rowsA, B, rowsC, D, out)


if __name__ == "__main__":
    main()
