#!/usr/bin/env python3
from __future__ import annotations

"""Frequency-sliced local BZ response maps in the kz=0 plane.

This tool produces paper-style signed local-integrand maps for

  * chi^(2)_{abc}(2w; w, w),
  * sigma^(2)_{abc}(2w; w, w), and optionally
  * sigma^(1)_zz(w),

at several laser frequencies.  It reuses the same local response building
blocks as ``plot_bz_chi_contribution.py`` and displays the BZ in k*a units.
"""

import argparse
import importlib.util
import os
from pathlib import Path
import sys
import time
from typing import Any

import numpy as np
from numpy.typing import NDArray

os.environ.setdefault("MPLCONFIGDIR", "/private/tmp")
os.environ.setdefault("XDG_CACHE_HOME", "/private/tmp")

import matplotlib

matplotlib.use("Agg")
from matplotlib import pyplot as plt
from matplotlib.colors import Normalize, TwoSlopeNorm

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
if str(PROJECT_ROOT / "tools") not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT / "tools"))

from qxti.analytics.theory_response import _resolve_distribution
from qxti.core import QXTIConfig
from qxti.core.simulation import QXTISimulation
from qxti.graphics.plot_susceptibility_tensor import apply_paper_style
from qxti.utils.progress import format_duration

from plot_bz_chi_contribution import (
    AXES,
    LABELS,
    _axis_values,
    _band_data,
    _component_indices,
    _component_label,
    _load_model_module,
    _overlay_weyl_nodes,
    _pi_ticks,
    _rho1,
    _sigma2_integrand,
    _signed_cmap,
)

AU_TO_EV = 27.211386245988
DEFAULT_OUTPUT_DIR = Path("outputs") / "bz_chi_contribution" / "frequency_slices"

ComplexArray = NDArray[np.complex128]
FloatArray = NDArray[np.float64]


def _parse_frequencies_ev(text: str) -> np.ndarray:
    values = [float(item.strip()) for item in str(text).replace(";", ",").split(",") if item.strip()]
    if not values:
        raise ValueError("Debes dar al menos una frecuencia en eV.")
    if any(value <= 0.0 for value in values):
        raise ValueError("Todas las frecuencias deben ser positivas.")
    return np.asarray(values, dtype=np.float64)


def _load_model_params(config: QXTIConfig, module: Any) -> dict[str, Any]:
    params: dict[str, Any] = {}
    if module is not None and hasattr(module, "default_params"):
        try:
            params.update(dict(module.default_params()))
        except Exception:
            pass
    params.update(dict(config.hamiltonian.params))
    return params


def _sigma1_zz_integrand(data: dict[str, Any], omega: float, gamma: float) -> ComplexArray:
    """Local integrand consistent with sigma^(1): Tr[J_z rho_z^(1)], J=-v."""
    axis = AXES["z"]
    rho = _rho1(data, axis, complex(float(omega), float(gamma)))
    current_z = -np.asarray(data["vel"][axis], dtype=np.complex128)
    return np.conj(np.einsum("kmn,knm->k", current_z, rho, optimize=True))


def _row_vmax(maps: list[FloatArray], robust_percentile: float | None) -> float:
    values = np.concatenate([np.ravel(np.asarray(item, dtype=np.float64)) for item in maps])
    values = values[np.isfinite(values)]
    if values.size == 0:
        return 1.0
    if robust_percentile is not None and 0.0 < robust_percentile < 100.0:
        vmax = float(np.nanpercentile(np.abs(values), robust_percentile))
    else:
        vmax = float(np.nanmax(np.abs(values)))
    return max(vmax, 1.0e-30)


def _phase_ticks(cbar: Any) -> None:
    cbar.set_ticks([-np.pi, 0.0, np.pi])
    cbar.set_ticklabels([r"$-\pi$", r"$0$", r"$\pi$"])


def _plot_frequency_grid(
    *,
    maps: ComplexArray,
    frequencies_ev: FloatArray,
    quantity_label: str,
    cbar_label_base: str,
    x_axis: FloatArray,
    y_axis: FloatArray,
    module: Any,
    params: dict[str, Any],
    plane_axis: int,
    fixed: float,
    unit_scale: float,
    k_offset: float,
    output_base: Path,
    dpi: int,
    robust_percentile: float | None,
    representation: str,
    phase_mask_relative: float,
    phase_alpha_relative: float,
    phase_alpha_min: float,
    scale_mode: str,
) -> list[Path]:
    apply_paper_style()
    representation_key = str(representation).strip().lower()
    scale_mode_key = str(scale_mode).strip().lower()
    if scale_mode_key not in {"shared", "panel"}:
        raise ValueError("scale_mode debe ser 'shared' o 'panel'.")
    signed_cmap = _signed_cmap()
    amplitude_cmap = "magma"
    phase_cmap = "twilight_shifted"
    nfreq = int(frequencies_ev.size)
    fig, axes = plt.subplots(
        2,
        nfreq,
        figsize=(4.05 * nfreq, 7.7),
        squeeze=False,
        sharex=True,
        sharey=True,
    )
    x_grid, y_grid = np.meshgrid(x_axis, y_axis, indexing="ij")
    plane_axes = [axis for axis in range(3) if axis != plane_axis]

    if representation_key == "cartesian":
        row_specs = [
            {
                "name": "real",
                "tex": r"\mathrm{Re}",
                "maps": [np.real(maps[i]) for i in range(nfreq)],
                "cmap": signed_cmap,
                "norms": None,
                "alphas": None,
                "label": rf"$\mathrm{{Re}}\,{cbar_label_base}$",
            },
            {
                "name": "imag",
                "tex": r"\mathrm{Im}",
                "maps": [np.imag(maps[i]) for i in range(nfreq)],
                "cmap": signed_cmap,
                "norms": None,
                "alphas": None,
                "label": rf"$\mathrm{{Im}}\,{cbar_label_base}$",
            },
        ]
        for spec in row_specs:
            if scale_mode_key == "panel":
                spec["norms"] = [
                    TwoSlopeNorm(
                        vmin=-_row_vmax([panel], robust_percentile),
                        vcenter=0.0,
                        vmax=_row_vmax([panel], robust_percentile),
                    )
                    for panel in spec["maps"]
                ]
            else:
                vmax = _row_vmax(spec["maps"], robust_percentile)
                spec["norms"] = [TwoSlopeNorm(vmin=-vmax, vcenter=0.0, vmax=vmax)] * nfreq
    elif representation_key == "polar":
        amplitude_maps = [np.abs(maps[i]) for i in range(nfreq)]
        phase_maps = []
        phase_alphas = []
        for i in range(nfreq):
            amplitude = amplitude_maps[i]
            phase = np.angle(maps[i])
            panel_scale = _row_vmax([amplitude], robust_percentile)
            if phase_alpha_relative > 0.0:
                alpha_scale = max(float(phase_alpha_relative) * panel_scale, 1.0e-300)
                alpha = np.clip(amplitude / alpha_scale, 0.0, 1.0)
                alpha = alpha * alpha * (3.0 - 2.0 * alpha)
                alpha = float(phase_alpha_min) + (1.0 - float(phase_alpha_min)) * alpha
            else:
                alpha = np.ones_like(amplitude, dtype=np.float64)
            if phase_mask_relative > 0.0:
                threshold = float(phase_mask_relative) * panel_scale
                phase = np.ma.masked_where(amplitude < threshold, phase)
                alpha = np.where(amplitude < threshold, 0.0, alpha)
            phase_maps.append(phase)
            phase_alphas.append(alpha)
        if scale_mode_key == "panel":
            amplitude_norms = [
                Normalize(vmin=0.0, vmax=_row_vmax([panel], robust_percentile))
                for panel in amplitude_maps
            ]
        else:
            amplitude_vmax = _row_vmax(amplitude_maps, robust_percentile)
            amplitude_norms = [Normalize(vmin=0.0, vmax=amplitude_vmax)] * nfreq
        row_specs = [
            {
                "name": "amplitude",
                "tex": r"\left|\cdot\right|",
                "maps": amplitude_maps,
                "cmap": amplitude_cmap,
                "norms": amplitude_norms,
                "alphas": None,
                "label": rf"$\left|{cbar_label_base}\right|$",
            },
            {
                "name": "phase",
                "tex": r"\arg",
                "maps": phase_maps,
                "cmap": phase_cmap,
                "norms": [Normalize(vmin=-np.pi, vmax=np.pi)] * nfreq,
                "alphas": phase_alphas,
                "label": rf"$\arg\,{cbar_label_base}$",
            },
        ]
    else:
        raise ValueError("representation debe ser 'cartesian' o 'polar'.")

    panel_images: list[list[Any]] = [[None for _ in range(nfreq)] for _ in range(2)]
    for row, spec in enumerate(row_specs):
        part_maps = spec["maps"]
        for col, frequency_ev in enumerate(frequencies_ev):
            ax = axes[row, col]
            values = np.ma.asarray(part_maps[col], dtype=np.float64)
            alpha_values = None if spec["alphas"] is None else np.asarray(spec["alphas"][col], dtype=np.float64)
            image = ax.pcolormesh(
                x_grid,
                y_grid,
                values,
                shading="auto",
                cmap=spec["cmap"],
                norm=spec["norms"][col],
                alpha=alpha_values,
            )
            panel_images[row][col] = image
            _overlay_weyl_nodes(
                ax,
                module,
                params,
                plane_axis,
                fixed,
                unit_scale,
                k_offset=k_offset,
            )
            ax.set_title(rf"$\hbar\omega={frequency_ev:g}\,\mathrm{{eV}}$", fontsize=19, pad=8)
            if row == 1:
                ax.set_xlabel(rf"$k_{LABELS[plane_axes[0]]}a$", fontsize=20)
            if col == 0:
                ax.set_ylabel(rf"$k_{LABELS[plane_axes[1]]}a$", fontsize=20)
            _pi_ticks(ax, x_axis, "x")
            _pi_ticks(ax, y_axis, "y")
            ax.tick_params(axis="both", which="major", labelsize=16)
            if col != 0:
                ax.set_ylabel("")
            if row == 0:
                ax.set_xlabel("")

    handles, labels = axes[0, -1].get_legend_handles_labels()
    if handles:
        dedup: dict[str, Any] = {}
        for handle, label in zip(handles, labels, strict=False):
            dedup.setdefault(label, handle)
        fig.legend(
            dedup.values(),
            dedup.keys(),
            loc="upper center",
            ncol=len(dedup),
            frameon=False,
            fontsize=14,
            bbox_to_anchor=(0.5, 1.012),
        )

    fig.suptitle(quantity_label, fontsize=22, y=1.045)
    if scale_mode_key == "panel":
        fig.subplots_adjust(left=0.07, right=0.965, bottom=0.08, top=0.91, wspace=0.30, hspace=0.16)
        for row, spec in enumerate(row_specs):
            for col in range(nfreq):
                cbar = fig.colorbar(panel_images[row][col], ax=axes[row, col], fraction=0.044, pad=0.012)
                if col == nfreq - 1:
                    cbar.set_label(spec["label"], fontsize=16, labelpad=7)
                if spec["name"] == "phase":
                    _phase_ticks(cbar)
                cbar.ax.tick_params(labelsize=12)
    else:
        fig.subplots_adjust(left=0.07, right=0.855, bottom=0.08, top=0.91, wspace=0.10, hspace=0.16)
        for row, spec in enumerate(row_specs):
            row_bbox = axes[row, -1].get_position()
            cax = fig.add_axes([0.872, row_bbox.y0, 0.0115, row_bbox.height])
            cbar = fig.colorbar(panel_images[row][-1], cax=cax)
            cbar.set_label(spec["label"], fontsize=17, labelpad=8)
            if spec["name"] == "phase":
                _phase_ticks(cbar)
            cbar.ax.tick_params(labelsize=14)

    output_base.parent.mkdir(parents=True, exist_ok=True)
    outputs = [output_base.with_suffix(".png"), output_base.with_suffix(".svg")]
    fig.savefig(outputs[0], dpi=int(dpi), facecolor="white")
    fig.savefig(outputs[1], facecolor="white")
    plt.close(fig)
    return outputs


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Mapas k-resueltos en kz=0 para chi^(2), sigma^(2) y sigma^(1)_zz "
            "a varias frecuencias."
        )
    )
    parser.add_argument("--config", default="inputs/inputParams.wsm_orenstein.cfg")
    parser.add_argument("--frequencies-ev", default="0.3,0.8,1.3,1.8")
    parser.add_argument("--points", type=int, default=180)
    parser.add_argument("--plane", choices=("kx", "ky", "kz"), default="kz")
    parser.add_argument("--fixed", type=float, default=0.0)
    parser.add_argument("--component-chi2", default="xzx")
    parser.add_argument(
        "--component-sigma2",
        default=None,
        help="Componente de sigma^(2). Si se omite, usa la misma componente de chi^(2).",
    )
    parser.add_argument("--component-sigma1", default="zz")
    parser.add_argument("--skip-sigma1", action="store_true")
    parser.add_argument("--normal-points", type=int, default=None)
    parser.add_argument("--gradient-step", type=float, default=None)
    parser.add_argument("--velocity-step", type=float, default=1.0e-4)
    parser.add_argument("--output-dir", default=str(DEFAULT_OUTPUT_DIR))
    parser.add_argument("--dpi", type=int, default=320)
    parser.add_argument(
        "--representation",
        choices=("cartesian", "polar"),
        default="cartesian",
        help="cartesian: Re/Im; polar: amplitud/fase.",
    )
    parser.add_argument(
        "--phase-mask-relative",
        type=float,
        default=0.0,
        help=(
            "Solo para --representation polar: mascara dura de fase donde la amplitud local "
            "es menor que esta fraccion de la amplitud robusta de cada panel. Por defecto no corta."
        ),
    )
    parser.add_argument(
        "--phase-alpha-relative",
        type=float,
        default=0.35,
        help=(
            "Solo para --representation polar: escala de amplitud relativa para atenuar suavemente "
            "la fase en regiones de senal debil. Usa 0 para fase completamente opaca."
        ),
    )
    parser.add_argument(
        "--phase-alpha-min",
        type=float,
        default=0.02,
        help="Transparencia minima de la fase en regiones de baja amplitud.",
    )
    parser.add_argument(
        "--scale-mode",
        choices=("shared", "panel"),
        default="shared",
        help="shared usa una escala por fila; panel usa una escala/colorbar por frecuencia.",
    )
    parser.add_argument(
        "--robust-percentile",
        type=float,
        default=99.5,
        help="Percentil para la escala de color simetrica por fila. Usa 100 para escala exacta.",
    )
    parser.add_argument("--unshifted", action="store_true")
    args = parser.parse_args()

    if int(args.points) <= 1:
        raise SystemExit("--points debe ser mayor que 1.")
    frequencies_ev = _parse_frequencies_ev(args.frequencies_ev)
    omega_axis = frequencies_ev / AU_TO_EV
    robust_percentile = None if float(args.robust_percentile) >= 100.0 else float(args.robust_percentile)

    chi2_component = _component_indices(args.component_chi2)
    chi2_label = _component_label(chi2_component)
    sigma2_component = _component_indices(args.component_sigma2 or args.component_chi2)
    sigma2_label = _component_label(sigma2_component)
    sigma1_label = str(args.component_sigma1).strip().lower().replace("_", "")
    if not args.skip_sigma1 and sigma1_label != "zz":
        raise SystemExit("Por ahora esta tool esta fijada para sigma^(1)_zz.")

    config = QXTIConfig.from_file(Path(args.config))
    sim = QXTISimulation(config=config)
    hamiltonian = sim.build_hamiltonian()
    if int(hamiltonian.dimension) < 3:
        raise SystemExit("Esta herramienta necesita un modelo 3D.")
    module = _load_model_module(config)
    params = _load_model_params(config, module)

    plane_axis = AXES[args.plane[-1]]
    plane_axes = [axis for axis in range(3) if axis != plane_axis]
    bounds = hamiltonian.reciprocal_box_bounds()
    x_internal = _axis_values(bounds[plane_axes[0]], int(args.points), shifted=not args.unshifted)
    y_internal = _axis_values(bounds[plane_axes[1]], int(args.points), shifted=not args.unshifted)
    x_grid, y_grid = np.meshgrid(x_internal, y_internal, indexing="ij")
    k_points = np.zeros((x_grid.size, 3), dtype=np.float64)
    k_points[:, plane_axis] = float(args.fixed)
    k_points[:, plane_axes[0]] = x_grid.reshape(-1)
    k_points[:, plane_axes[1]] = y_grid.reshape(-1)

    normal_points = int(args.normal_points) if args.normal_points is not None else int(config.kgrid.k_points[plane_axis])
    normal_points = max(normal_points, 2)
    gradient_step = (
        float(args.gradient_step)
        if args.gradient_step is not None
        else (float(bounds[plane_axis][1]) - float(bounds[plane_axis][0])) / float(normal_points)
    )

    ccfg = config.susceptibility_solver
    distribution = _resolve_distribution(ccfg.distribution)
    mu = float(ccfg.fermi_level)
    temperature = float(ccfg.temperature)
    gamma = 0.0 if ccfg.coherence_time <= 0 else 1.0 / float(ccfg.coherence_time)

    axes_needed_set = set(chi2_component + sigma2_component)
    if not args.skip_sigma1:
        axes_needed_set.add(AXES["z"])
    axes_needed = tuple(sorted(axes_needed_set))
    gradient_axes = tuple(
        sorted({chi2_component[1], chi2_component[2], sigma2_component[1], sigma2_component[2]})
    )

    print(
        f"[bz-frequency] grid {args.points}x{args.points} on {args.plane}={args.fixed:g}; "
        f"frequencies eV={','.join(f'{v:g}' for v in frequencies_ev)}; "
        f"chi2={chi2_label}; sigma2={sigma2_label}"
        + ("" if args.skip_sigma1 else "; sigma1=zz"),
        flush=True,
    )
    t0 = time.perf_counter()
    current_data = _band_data(
        Hf=hamiltonian._matrix_at,
        k_points=k_points,
        axes_needed=axes_needed,
        distribution=distribution,
        mu=mu,
        temperature=temperature,
        velocity_step=float(args.velocity_step),
    )
    shifted_data_by_axis: dict[int, tuple[dict[str, Any], dict[str, Any]]] = {}
    for gradient_axis in gradient_axes:
        shift = np.zeros(3, dtype=np.float64)
        shift[gradient_axis] = float(gradient_step)
        plus_data = _band_data(
            Hf=hamiltonian._matrix_at,
            k_points=k_points + shift,
            axes_needed=axes_needed,
            distribution=distribution,
            mu=mu,
            temperature=temperature,
            velocity_step=float(args.velocity_step),
        )
        minus_data = _band_data(
            Hf=hamiltonian._matrix_at,
            k_points=k_points - shift,
            axes_needed=axes_needed,
            distribution=distribution,
            mu=mu,
            temperature=temperature,
            velocity_step=float(args.velocity_step),
        )
        shifted_data_by_axis[gradient_axis] = (plus_data, minus_data)

    nfreq = int(omega_axis.size)
    npoints = int(args.points)
    chi2_maps = np.zeros((nfreq, npoints, npoints), dtype=np.complex128)
    sigma2_maps = np.zeros((nfreq, npoints, npoints), dtype=np.complex128)
    sigma1_maps = None if args.skip_sigma1 else np.zeros((nfreq, npoints, npoints), dtype=np.complex128)
    for index, omega in enumerate(omega_axis):
        sigma2_cache: dict[tuple[int, int, int], ComplexArray] = {}
        for component in (chi2_component, sigma2_component):
            if component not in sigma2_cache:
                sigma2_cache[component] = _sigma2_integrand(
                    current_data=current_data,
                    shifted_data_by_axis=shifted_data_by_axis,
                    component=component,
                    omega=float(omega),
                    gamma=float(gamma),
                    gradient_step=float(gradient_step),
                )
        chi2_maps[index] = (sigma2_cache[chi2_component] / (-1j * (2.0 * float(omega)))).reshape(
            npoints,
            npoints,
        )
        sigma2_maps[index] = sigma2_cache[sigma2_component].reshape(npoints, npoints)
        if sigma1_maps is not None:
            sigma1_maps[index] = _sigma1_zz_integrand(
                current_data,
                omega=float(omega),
                gamma=float(gamma),
            ).reshape(npoints, npoints)
        print(f"[bz-frequency] frequency {index + 1}/{nfreq}: {frequencies_ev[index]:g} eV", flush=True)

    a_lat = float(params.get("a", 1.0))
    unit_scale = a_lat
    k_offset = np.pi
    x_plot = x_internal * unit_scale + k_offset
    y_plot = y_internal * unit_scale + k_offset

    out_dir = Path(args.output_dir)
    fixed_str = f"{args.fixed:g}".replace("-", "m").replace(".", "p")
    freq_tag = "_".join(f"{value:g}".replace(".", "p") for value in frequencies_ev)

    npz_path = out_dir / (
        f"bz_frequency_slices_chi2_{chi2_label}_sigma2_{sigma2_label}_"
        f"{args.plane}_{fixed_str}_{freq_tag}.npz"
    )
    out_dir.mkdir(parents=True, exist_ok=True)
    npz_arrays: dict[str, Any] = dict(
        frequencies_ev=frequencies_ev,
        omega_axis=omega_axis,
        gamma=float(gamma),
        plane=str(args.plane),
        fixed=float(args.fixed),
        component_chi2=chi2_label,
        component_sigma2=sigma2_label,
        component_sigma1=sigma1_label,
        gradient_step=float(gradient_step),
        velocity_step=float(args.velocity_step),
        x_axis=x_internal,
        y_axis=y_internal,
        x_axis_plot=x_plot,
        y_axis_plot=y_plot,
        chi2_integrand=chi2_maps,
        sigma2_integrand=sigma2_maps,
        note=(
            "Signed local k-resolved integrand slices. These are not full "
            "BZ-integrated response tensors."
        ),
    )
    npz_arrays[f"chi2_{chi2_label}_integrand"] = chi2_maps
    npz_arrays[f"sigma2_{sigma2_label}_integrand"] = sigma2_maps
    if sigma1_maps is not None:
        npz_arrays["sigma1_zz_integrand"] = sigma1_maps
    np.savez_compressed(npz_path, **npz_arrays)

    common_plot_kwargs = dict(
        frequencies_ev=frequencies_ev,
        x_axis=x_plot,
        y_axis=y_plot,
        module=module,
        params=params,
        plane_axis=plane_axis,
        fixed=float(args.fixed),
        unit_scale=unit_scale,
        k_offset=k_offset,
        dpi=int(args.dpi),
        robust_percentile=robust_percentile,
        representation=str(args.representation),
        phase_mask_relative=max(0.0, float(args.phase_mask_relative)),
        phase_alpha_relative=max(0.0, float(args.phase_alpha_relative)),
        phase_alpha_min=float(np.clip(float(args.phase_alpha_min), 0.0, 1.0)),
        scale_mode=str(args.scale_mode),
    )
    chi_outputs = _plot_frequency_grid(
        maps=chi2_maps,
        quantity_label=rf"Local BZ contribution to $\chi^{{(2)}}_{{{chi2_label}}}$ on $k_z=0$",
        cbar_label_base=rf"\mathcal{{I}}^{{\chi^{(2)}}}_{{{chi2_label}}}(\mathbf{{k}})",
        output_base=out_dir / f"chi2_{chi2_label}_{args.plane}_{fixed_str}_frequency_slices",
        **common_plot_kwargs,
    )
    sigma2_outputs = _plot_frequency_grid(
        maps=sigma2_maps,
        quantity_label=rf"Local BZ contribution to $\sigma^{{(2)}}_{{{sigma2_label}}}$ on $k_z=0$",
        cbar_label_base=rf"\mathcal{{I}}^{{\sigma^{(2)}}}_{{{sigma2_label}}}(\mathbf{{k}})",
        output_base=out_dir / f"sigma2_{sigma2_label}_{args.plane}_{fixed_str}_frequency_slices",
        **common_plot_kwargs,
    )
    sigma1_outputs: list[Path] = []
    if sigma1_maps is not None:
        sigma1_outputs = _plot_frequency_grid(
            maps=sigma1_maps,
            quantity_label=r"Local BZ contribution to $\sigma^{(1)}_{zz}$ on $k_z=0$",
            cbar_label_base=r"\mathcal{I}^{\sigma^{(1)}}_{zz}(\mathbf{k})",
            output_base=out_dir / f"sigma1_zz_{args.plane}_{fixed_str}_frequency_slices",
            **common_plot_kwargs,
        )

    elapsed = time.perf_counter() - t0
    print(f"[bz-frequency] done in {format_duration(elapsed)}")
    print(f"[bz-frequency] data: {npz_path}")
    for path in [*chi_outputs, *sigma2_outputs, *sigma1_outputs]:
        print(f"[bz-frequency] plot: {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
