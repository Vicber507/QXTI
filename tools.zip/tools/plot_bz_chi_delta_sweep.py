#!/usr/bin/env python3
"""BZ chi^(2) integrand maps for multiple Delta values at their resonant energies.

Delta / omega_eV pairs:
    Delta=0.500  ->  omega=0.91 eV
    Delta=0.375  ->  omega=0.87 eV
    Delta=0.250  ->  omega=0.82 eV
    Delta=0.125  ->  omega=0.81 eV

Produces 4 two-panel (Re+Im) figures per component (zzz and xzx).
Output: outputs/bz_chi_contribution/chi2_zzz/delta_sweep/ and chi2_xzx/delta_sweep/

Usage:
    python tools/plot_bz_chi_delta_sweep.py [--points N] [--dpi D]
"""
from __future__ import annotations

import argparse
import importlib.util
import os
import sys
import time
from pathlib import Path
from typing import Any

import numpy as np
from numpy.typing import NDArray

os.environ.setdefault("MPLCONFIGDIR", "/private/tmp")
os.environ.setdefault("XDG_CACHE_HOME", "/private/tmp")

import matplotlib
matplotlib.use("Agg")
from matplotlib import pyplot as plt

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from qxti.analytics.theory_response import _resolve_distribution
from qxti.core import QXTIConfig
from qxti.core.simulation import QXTISimulation
from qxti.graphics.plot_susceptibility_tensor import apply_paper_style
from qxti.utils.progress import format_duration

AU_TO_EV = 27.211386245988
AXES = {"x": 0, "y": 1, "z": 2}
LABELS = ("x", "y", "z")

ComplexArray = NDArray[np.complex128]
FloatArray = NDArray[np.float64]

# ── sweep parameters ──────────────────────────────────────────────────────────
SWEEP = [
    {"delta": 0.500, "omega_ev": 0.91},
    {"delta": 0.375, "omega_ev": 0.87},
    {"delta": 0.250, "omega_ev": 0.82},
    {"delta": 0.125, "omega_ev": 0.81},
]
COMPONENTS = ["zzz", "xzx"]


# ── helpers copied from plot_bz_chi_contribution.py ───────────────────────────

def _component_indices(text: str) -> tuple[int, int, int]:
    clean = (str(text).strip().lower()
             .replace("chi","").replace("xi","").replace("χ","")
             .replace("^","").replace("(","").replace(")","")
             .replace("_","").replace(",","").replace(" ",""))
    return tuple(AXES[c] for c in clean)  # type: ignore[return-value]


def _load_model_module(config: QXTIConfig):
    source = Path(str(config.hamiltonian.source_file))
    model_path = source if source.is_absolute() else PROJECT_ROOT / "models" / source
    spec = importlib.util.spec_from_file_location(f"qxti_model_{model_path.stem}", model_path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _abs_cmap():
    from matplotlib.colors import LinearSegmentedColormap
    return LinearSegmentedColormap.from_list(
        "qxti_bz_chi",
        ["#081B33","#0E4F6F","#2A9D8F","#F3E9D2","#F4A261","#B23A48"],
        N=256)


def _pi_ticks(ax, axis_values: FloatArray, which: str = "x") -> None:
    import math
    lo, hi = float(axis_values[0]), float(axis_values[-1])
    step = np.pi / 2.0
    first = math.ceil((lo - 1e-9) / step) * step
    ticks = np.arange(first, hi + step * 0.5, step)
    ticks = ticks[(ticks >= lo - 1e-9) & (ticks <= hi + 1e-9)]
    _tex = {0.0: r"$0$", np.pi/2: r"$\pi/2$", np.pi: r"$\pi$",
            3*np.pi/2: r"$3\pi/2$", 2*np.pi: r"$2\pi$",
            -np.pi/2: r"$-\pi/2$", -np.pi: r"$-\pi$"}
    labels = [next((v for k,v in _tex.items() if abs(t-k)<1e-9),
                   rf"${t/np.pi:.2g}\pi$") for t in ticks]
    if which == "x":
        ax.set_xticks(ticks); ax.set_xticklabels(labels, fontsize=15)
    else:
        ax.set_yticks(ticks); ax.set_yticklabels(labels, fontsize=15)


def _overlay_weyl_nodes(ax, mod, params, plane_axis, fixed, unit_scale, k_offset=0.0):
    if not hasattr(mod, "weyl_nodes_with_chirality"):
        return
    try:
        tagged = mod.weyl_nodes_with_chirality(params)
    except Exception:
        return
    plane_axes = [i for i in range(3) if i != plane_axis]
    col = {+1: "#E8000B", -1: "#1E64C8"}
    mrk = {+1: "+", -1: "-"}
    seen: set = set()
    xlim, ylim = ax.get_xlim(), ax.get_ylim()
    for item in tagged:
        k = np.asarray(item["k"], dtype=float)
        if abs(k[plane_axis] - fixed) > 0.35:
            continue
        chi = int(item.get("chirality", 0))
        kx0 = k[plane_axes[0]] * unit_scale + k_offset
        ky0 = k[plane_axes[1]] * unit_scale + k_offset
        lab = rf"$\chi={chi:+d}$" if chi not in seen else None
        seen.add(chi)
        for nx in range(-2, 3):
            for ny in range(-2, 3):
                kxp = kx0 + nx * 2 * np.pi
                kyp = ky0 + ny * 2 * np.pi
                if not (xlim[0]-0.1 <= kxp <= xlim[1]+0.1): continue
                if not (ylim[0]-0.1 <= kyp <= ylim[1]+0.1): continue
                ax.scatter([kxp],[kyp], s=160, facecolors=col.get(chi,"grey"),
                           edgecolors="white", linewidths=1.5, zorder=7,
                           label=lab)
                ax.text(kxp, kyp, mrk.get(chi,"?"), color="white",
                        ha="center", va="center", fontsize=11,
                        fontweight="bold", zorder=8)
                lab = None


def _axis_values(bounds, n):
    lo, hi = float(bounds[0]), float(bounds[1])
    step = (hi - lo) / float(n)
    return np.linspace(lo, hi, n, endpoint=False) + 0.5 * step


def _batched_H(Hf, k_points):
    return np.asarray([Hf(float(k[0]),float(k[1]),float(k[2])) for k in k_points],
                      dtype=np.complex128)


def _band_data(Hf, k_points, axes_needed, dist, mu, temperature, velocity_step=1e-4):
    h0 = _batched_H(Hf, k_points)
    energies, U = np.linalg.eigh(h0)
    Udag = np.conj(np.transpose(U,(0,2,1)))
    vel: dict[int, ComplexArray] = {}
    for ax in sorted(set(axes_needed)):
        sh = np.zeros(3); sh[ax] = velocity_step
        dH = (_batched_H(Hf, k_points+sh) - _batched_H(Hf, k_points-sh)) / (2*velocity_step)
        vel[ax] = Udag @ dH @ U
    occ = np.asarray(dist(energies, mu, temperature), dtype=np.float64)
    eps = energies[:,:,None] - energies[:,None,:]
    fmn = occ[:,None,:] - occ[:,:,None]
    nb = int(energies.shape[1])
    valid = (~np.eye(nb,dtype=bool))[None] & (np.abs(eps)>1e-20)
    with np.errstate(divide="ignore",invalid="ignore"):
        inv_eps = np.where(valid, 1.0/eps, 0.0)
    dfde = (-occ*(1-occ)/temperature if temperature>1e-15
            else np.zeros_like(occ))
    return {"energies":energies,"U":U,"Udag":Udag,"vel":vel,
            "eps":eps,"fmn":fmn,"valid":valid,"inv_eps":inv_eps,
            "dfde":dfde,"nb":nb}


def _rho1(data, input_axis, omega_complex):
    nb = data["nb"]
    vel = np.asarray(data["vel"][input_axis], dtype=np.complex128)
    inv_eps = np.asarray(data["inv_eps"], dtype=np.complex128)
    fmn = np.asarray(data["fmn"], dtype=np.float64)
    eps = np.asarray(data["eps"], dtype=np.float64)
    valid = np.asarray(data["valid"], dtype=bool)
    dfde = np.asarray(data["dfde"], dtype=np.float64)
    A = 1j * vel * inv_eps
    with np.errstate(divide="ignore",invalid="ignore"):
        rho = np.where(valid, (A*fmn)/(omega_complex-eps), 0+0j)
    diag = (-1j)*dfde*np.real(np.diagonal(vel,axis1=1,axis2=2))
    rho[:,np.arange(nb),np.arange(nb)] += diag/omega_complex
    return np.where((valid | np.eye(nb,dtype=bool)[None]), rho, 0+0j)


def _ordered_integrand(current_data, plus_data, minus_data, component,
                        omega, gamma, gradient_step):
    output_axis, gradient_axis, input_axis = component
    w1 = complex(omega, gamma)
    w2 = complex(2*omega, gamma)
    rho_c = _rho1(current_data, input_axis, w1)
    rho_p = _rho1(plus_data,   input_axis, w1)
    rho_m = _rho1(minus_data,  input_axis, w1)
    Uc  = np.asarray(current_data["U"], dtype=np.complex128)
    Ucd = np.asarray(current_data["Udag"], dtype=np.complex128)
    Up  = np.asarray(plus_data["U"],  dtype=np.complex128)
    Um  = np.asarray(minus_data["U"], dtype=np.complex128)
    Wp  = Ucd @ Up;   Wm  = Ucd @ Um
    Wpd = np.conj(np.swapaxes(Wp,-1,-2))
    Wmd = np.conj(np.swapaxes(Wm,-1,-2))
    dpart = (Wp@rho_p@Wpd - Wm@rho_m@Wmd) / (2*gradient_step)
    A_g = 1j * np.asarray(current_data["vel"][gradient_axis],dtype=np.complex128) \
            * np.asarray(current_data["inv_eps"],dtype=np.complex128)
    comm = A_g@rho_c - rho_c@A_g
    valid = np.asarray(current_data["valid"], dtype=bool)
    eps   = np.asarray(current_data["eps"],   dtype=np.float64)
    with np.errstate(divide="ignore",invalid="ignore"):
        inv_d2 = np.where(valid, 1.0/(w2-eps), 0+0j)
    rho2 = (dpart - 1j*comm)*inv_d2
    vout = -np.asarray(current_data["vel"][output_axis], dtype=np.complex128)
    return np.conj(np.einsum("pmn,pnm->p", vout, rho2, optimize=True))


def _sigma2_integrand(current_data, shifted_by_axis, component, omega, gamma, gradient_step):
    comp = tuple(component)
    pd, md = shifted_by_axis[comp[1]]
    first = _ordered_integrand(current_data, pd, md, comp, omega, gamma, gradient_step)
    if comp[1] == comp[2]:
        return first
    swapped = (comp[0], comp[2], comp[1])
    pd2, md2 = shifted_by_axis[swapped[1]]
    second = _ordered_integrand(current_data, pd2, md2, swapped, omega, gamma, gradient_step)
    return 0.5*(first+second)


# ── main computation per (delta, omega, component) ────────────────────────────

def compute_and_plot(config_path: str, delta: float, omega_ev: float,
                     component_str: str, N: int, dpi: int,
                     out_base: Path,
                     plane: str = "kz", fixed: float = 0.0) -> None:
    component  = _component_indices(component_str)
    comp_label = "".join(LABELS[i] for i in component)
    plane_axis = {"kx": 0, "ky": 1, "kz": 2}[plane]
    plane_axes = [i for i in range(3) if i != plane_axis]
    ax_labels  = [("x", "y", "z")[i] for i in plane_axes]

    config = QXTIConfig.from_file(Path(config_path))
    config.hamiltonian.params["Delta"] = delta

    sim = QXTISimulation(config=config)
    ham = sim.build_hamiltonian()
    Hf  = ham._matrix_at

    mod    = _load_model_module(config)
    params = dict(config.hamiltonian.params)

    dist        = _resolve_distribution(config.susceptibility_solver.distribution)
    mu          = float(config.susceptibility_solver.fermi_level)
    temperature = float(config.susceptibility_solver.temperature)
    gamma_au    = (0.0 if config.susceptibility_solver.coherence_time <= 0
                   else 1.0 / float(config.susceptibility_solver.coherence_time))
    omega_au    = omega_ev / AU_TO_EV

    bounds = ham.reciprocal_box_bounds()
    x_int  = _axis_values(bounds[plane_axes[0]], N)
    y_int  = _axis_values(bounds[plane_axes[1]], N)
    XG, YG = np.meshgrid(x_int, y_int, indexing="ij")
    k_flat = np.zeros((N * N, 3))
    k_flat[:, plane_axes[0]] = XG.ravel()
    k_flat[:, plane_axes[1]] = YG.ravel()
    k_flat[:, plane_axis]    = fixed

    normal_pts = int(config.kgrid.k_points[plane_axis])
    grad_step  = (float(bounds[plane_axis][1]) - float(bounds[plane_axis][0])) / normal_pts

    axes_needed   = tuple(sorted(set(component)))
    gradient_axes = tuple(sorted({component[1], component[2]}))

    t0 = time.perf_counter()
    print(f"  [Δ={delta}  ω={omega_ev}eV  {comp_label}  {plane}={fixed:.4f}]  "
          f"computing {N}x{N} ...", flush=True)

    cur = _band_data(Hf, k_flat, axes_needed, dist, mu, temperature)
    shifted: dict[int, tuple] = {}
    for ga in gradient_axes:
        sh = np.zeros(3); sh[ga] = grad_step
        shifted[ga] = (
            _band_data(Hf, k_flat + sh, axes_needed, dist, mu, temperature),
            _band_data(Hf, k_flat - sh, axes_needed, dist, mu, temperature),
        )

    sig     = _sigma2_integrand(cur, shifted, component, omega_au, gamma_au, grad_step)
    chi_map = (sig / (-1j * 2 * omega_au)).reshape(N, N)

    a_lat  = float(params.get("a", 1.0))
    x_plot = x_int * a_lat
    y_plot = y_int * a_lat

    # ── single-panel |chi| figure ─────────────────────────────────────────────
    apply_paper_style()
    fig, ax = plt.subplots(figsize=(7.4, 6.2))
    XP, YP  = np.meshgrid(x_plot, y_plot, indexing="ij")
    values  = np.abs(chi_map)
    im = ax.pcolormesh(XP, YP, values, shading="auto", cmap=_abs_cmap())
    _overlay_weyl_nodes(ax, mod, params, plane_axis, fixed, a_lat, k_offset=0.0)
    ax.set_xlabel(rf"$k_{{{ax_labels[0]}}}\,a$", fontsize=20)
    ax.set_ylabel(rf"$k_{{{ax_labels[1]}}}\,a$", fontsize=20)
    _pi_ticks(ax, x_plot, "x")
    _pi_ticks(ax, y_plot, "y")
    ax.tick_params(labelsize=15)
    cb = fig.colorbar(im, ax=ax, pad=0.02)
    cb.set_label(rf"$|\mathcal{{I}}^{{(2)}}_{{{comp_label}}}(\mathbf{{k}})|$", fontsize=18)
    cb.ax.tick_params(labelsize=14)

    fixed_tex = f"{fixed/np.pi:.3g}\\pi" if fixed != 0.0 else "0"
    ax.set_title(
        rf"$|\chi^{{(2)}}_{{{comp_label}}}|$,  $\Delta={delta}$,  "
        rf"$\omega={omega_ev}\,\mathrm{{eV}}$,  $k_{{{plane[-1]}}}a={fixed_tex}$",
        fontsize=14, pad=6)
    fig.tight_layout()

    delta_str = f"{delta:.3f}".replace(".", "p")
    omega_str = f"{omega_ev:.2f}".replace(".", "p")
    fixed_str = f"{fixed:.4f}".replace("-", "m").replace(".", "p")
    out_dir   = out_base / f"chi2_{comp_label}" / "delta_sweep"
    out_dir.mkdir(parents=True, exist_ok=True)
    fname = out_dir / f"chi2_{comp_label}_delta{delta_str}_omega{omega_str}_{plane}{fixed_str}_abs.png"
    fig.savefig(fname, dpi=dpi, facecolor="white", bbox_inches="tight")
    plt.close(fig)
    print(f"  -> {fname}  [{format_duration(time.perf_counter() - t0)}]", flush=True)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="inputs/inputParams.wsm_orenstein.cfg")
    ap.add_argument("--points", type=int, default=180)
    ap.add_argument("--dpi",    type=int, default=280)
    ap.add_argument("--plane",  choices=("kx", "ky", "kz"), default="kz")
    ap.add_argument("--fixed",  type=float, default=0.0,
                    help="Valor fijo del plano en 1/Bohr. Ej: -1.5708 para -pi/2.")
    args = ap.parse_args()

    out_base = Path("outputs/bz_chi_contribution")

    for entry in SWEEP:
        for comp in COMPONENTS:
            compute_and_plot(
                config_path=args.config,
                delta=entry["delta"],
                omega_ev=entry["omega_ev"],
                component_str=comp,
                N=args.points,
                dpi=args.dpi,
                out_base=out_base,
                plane=args.plane,
                fixed=args.fixed,
            )

    print("\n[done] all delta-sweep plots generated.", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
