#!/usr/bin/env python3
"""Band structure E vs ky at kx*a=pi/2, kz=0 for several Delta values.

Uses the same colors as plot_chi2zzz_delta_sweep.py. Shows only the band
contours (no fill), same large-font paper style. The Weyl node crossing
is visible as the gap closing at ky*a = arctan(Delta).
"""
from __future__ import annotations

import os, sys
from pathlib import Path

import numpy as np

os.environ.setdefault("MPLCONFIGDIR", "/private/tmp")
os.environ.setdefault("XDG_CACHE_HOME", "/private/tmp")
PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import importlib.util

_EV = 27.211386245988
OUT  = Path("outputs/susceptibility_maps/wsm_orenstein")

PALETTE = (
    "#59819E",
    "#7C7AA2",
    "#F67E7D",
    "#FFC0A7",
    "#6CC2BD",
    "#4A4A4A",
)
DELTAS = (0.5, 0.375, 0.25, 0.125, 0.0)


def main():
    spec = importlib.util.spec_from_file_location(
        "wsm_o", PROJECT_ROOT / "models" / "wsm_orenstein.py")
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from qxti.graphics.plot_susceptibility_tensor import apply_paper_style
    apply_paper_style()

    p_base = mod.default_params()
    a = float(p_base["a"])
    kx_fixed = np.pi / (2.0 * a)          # kx*a = pi/2

    # Sweep kz at kx=pi/2, ky=0
    N = 600
    kz_vals = np.linspace(-np.pi / a, np.pi / a, N)
    kz_a    = kz_vals * a

    fig, ax = plt.subplots(figsize=(10.4, 10.4))

    # Stack labels vertically on the right side, one below the other
    label_kz = np.pi/4 - 0.02   # right edge (data coords)
    label_y_positions = np.linspace(0.20, -0.20, len(DELTAS))

    for k, (delta, color) in enumerate(zip(DELTAS, PALETTE)):
        p = dict(p_base); p["Delta"] = float(delta)
        bands = np.array([
            np.linalg.eigvalsh(mod.H(kx_fixed, 0.0, kz, p)) * _EV
            for kz in kz_vals
        ])   # (N, 4)

        for i in range(4):
            ax.plot(kz_a, bands[:, i], color=color, lw=2.8, zorder=3)

        # minimum gap — label only, no arrow
        gap = bands[:, 2] - bands[:, 1]
        gap_min = float(gap.min())
        ax.text(label_kz, label_y_positions[k],
                rf"$\Delta E={gap_min:.3f}$ eV",
                fontsize=20, color=color, va="center", ha="right", fontweight="bold",
                bbox=dict(facecolor="white", edgecolor="none", alpha=0.7, pad=1))

    ax.axhline(0.0, color="0.55", lw=1.2, ls="--", zorder=1)
    ax.axvline(0.0, color="0.75", lw=0.8, ls=":", zorder=1)

    ax.set_xlim(-np.pi / 4, np.pi / 4)
    ax.set_ylim(-0.6, 0.6)
    ax.set_box_aspect(1.0)

    ticks_x = np.array([-np.pi/4, 0.0, np.pi/4])
    _tex = {-np.pi/4: r"$-\pi/4$", 0.0: r"$0$", np.pi/4: r"$\pi/4$"}
    ax.set_xticks(ticks_x)
    ax.set_xticklabels([_tex[t] for t in ticks_x], fontsize=32)

    ax.set_xlabel(r"$k_z a$", fontsize=36, labelpad=13)
    ax.set_ylabel(r"$E\;(\mathrm{eV})$", fontsize=36, labelpad=15)
    ax.tick_params(axis="both", which="major", labelsize=32, length=10, width=1.4)
    ax.tick_params(axis="both", which="minor", length=5, width=1.1)
    for spine in ax.spines.values():
        spine.set_linewidth(1.4)

    ax.set_title(r"$k_x a = \pi/2$,  $k_y = 0$", fontsize=30, pad=10)

    fig.subplots_adjust(left=0.21, right=0.96, bottom=0.15, top=0.93)
    OUT.mkdir(parents=True, exist_ok=True)
    f = OUT / "wsm_orenstein_bands_kz_kxa_pi2_ky0_delta_sweep.png"
    fig.savefig(f, dpi=200, facecolor="white")
    plt.close(fig)
    print(f"[bands] wrote {f}")


if __name__ == "__main__":
    main()
