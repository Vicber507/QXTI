"""Comparative + convergence study: mesh-vectorized vs per-k recursion.

Answers, with data and a figure, the two things that matter about the new base
implementation of the perturbative response (orders >= 2):

  1. **Same physics** — the vectorized mesh (`mesh_response.harmonic_currents`)
     reproduces the OLD per-k recursion (`rho_analytic.rho_order_s`, via
     `perk_harmonic_currents`) for the harmonic observable |J^(s)| at every grid,
     and both converge to the SAME value as the k-grid is refined.
  2. **Much faster** — wall-clock vs grid size, and the speedup factor.

Both paths honor the SAME occupation: whatever ``distribution`` the config sets
(here ``valence_occupation``, matching antelope's fixed-valence filling).  With
``dk_grad`` = grid spacing the two use the identical finite-difference stencil,
so on a periodic model they agree to machine precision; the script prints the
actual relative error so the claim is checkable for any model.

Order 1 is NOT recomputed here as a "slow path": in production it is the batched
Kubo pass (vectorized eigh + einsum, full sigma^(1) tensor).  We still include the
order-1 harmonic current from both mesh and per-k to show they agree too.

Usage:
    python tools/compare_mesh_vs_perk.py                        # defaults
    python tools/compare_mesh_vs_perk.py --config inputs/inputParams.wsm.cfg \
        --mesh-grids 4 6 8 10 12 16 20 24 --perk-grids 4 6 8 10 12 \
        --max-order 3 --drive z
"""
from __future__ import annotations

import argparse
import time
from pathlib import Path

import numpy as np

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from qxti.core.config import QXTIConfig
from qxti.core.simulation import QXTISimulation
from qxti.analytics.theory_response import _resolve_distribution
from qxti.analytics.mesh_response import (
    precompute_band_data, harmonic_currents, perk_harmonic_currents, uniform_mp_grid,
)


def _drive_vector(drive: str, amp: float) -> np.ndarray:
    axis = {"x": 0, "y": 1, "z": 2}[drive]
    E = np.zeros(3, dtype=np.complex128)
    E[axis] = amp
    return E


def run_study(config_path: str, mesh_grids, perk_grids, max_order, drive, amp):
    cfg = QXTIConfig.from_file(config_path)
    sim = QXTISimulation(config=cfg)
    ham = sim.build_hamiltonian()
    H_func = ham._matrix_at
    bounds = ham.reciprocal_box_bounds()
    dim = int(ham.dimension)

    ccfg = cfg.susceptibility_solver
    mu = float(ccfg.fermi_level)
    T_au = float(ccfg.temperature)
    gamma = 0.0 if ccfg.coherence_time <= 0 else 1.0 / float(ccfg.coherence_time)
    omega = float(cfg.laser.omega)
    distribution = _resolve_distribution(ccfg.distribution)   # <-- HONORS the config
    E_field = _drive_vector(drive, amp)

    print(f"# model      : {config_path}")
    print(f"# distribution: {ccfg.distribution}   mu={mu}  T={T_au}  gamma={gamma:.5f}")
    print(f"# omega={omega}  drive={drive}  |E|={amp}  max_order={max_order}\n")

    orders = list(range(1, max_order + 1))
    results = {"mesh": {}, "perk": {}}   # N -> {"t": sec, "J": {s: complex3}}

    def _grid(N):
        shape = (N,) * dim + (1,) * (3 - dim)
        shape = tuple(shape[:3])
        kpts, w = uniform_mp_grid(bounds, shape)
        return kpts, w, shape

    # ---- NEW: mesh-vectorized ------------------------------------------------
    print("== mesh (vectorized) ==")
    print(f"{'N':>4} {'Nk':>8} {'t(s)':>8}  " + "  ".join(f"|J{s}|" for s in orders))
    for N in mesh_grids:
        kpts, w, shape = _grid(N)
        t0 = time.perf_counter()
        band = precompute_band_data(H_func, kpts, shape, bounds, mu=mu, T_au=T_au,
                                    dimension=dim, distribution=distribution)
        J = harmonic_currents(band, w, E_field, omega, max_order,
                              gamma=gamma, gamma_pop=gamma)
        dt = time.perf_counter() - t0
        results["mesh"][N] = {"t": dt, "J": {s: J[s].copy() for s in orders}}
        print(f"{N:>4} {N**dim:>8} {dt:>8.3f}  "
              + "  ".join(f"{np.linalg.norm(J[s]):.3e}" for s in orders))

    # ---- OLD: per-k recursion (dk_grad = grid spacing) -----------------------
    print("\n== per-k (rho_order_s) ==")
    print(f"{'N':>4} {'Nk':>8} {'t(s)':>8}  " + "  ".join(f"|J{s}|" for s in orders))
    for N in perk_grids:
        kpts, w, shape = _grid(N)
        dk_grad = (float(bounds[0][1]) - float(bounds[0][0])) / N   # = grid spacing
        t0 = time.perf_counter()
        J = perk_harmonic_currents(H_func, kpts, w, E_field, omega, max_order,
                                   gamma=gamma, mu=mu, T_au=T_au, dimension=dim,
                                   dk_grad=dk_grad, distribution=distribution)
        dt = time.perf_counter() - t0
        results["perk"][N] = {"t": dt, "J": {s: J[s].copy() for s in orders}}
        print(f"{N:>4} {N**dim:>8} {dt:>8.3f}  "
              + "  ".join(f"{np.linalg.norm(J[s]):.3e}" for s in orders))

    # ---- agreement (mesh vs per-k where both ran) ----------------------------
    print("\n== agreement mesh vs per-k (rel. error of |J^(s)|-vector) & speedup ==")
    print(f"{'N':>4}  " + "  ".join(f"err{s}" for s in orders) + "   speedup")
    for N in perk_grids:
        if N not in results["mesh"]:
            continue
        Jm, Jp = results["mesh"][N]["J"], results["perk"][N]["J"]
        errs = [np.linalg.norm(Jm[s] - Jp[s]) / max(np.linalg.norm(Jp[s]), 1e-300)
                for s in orders]
        sp = results["perk"][N]["t"] / max(results["mesh"][N]["t"], 1e-12)
        print(f"{N:>4}  " + "  ".join(f"{e:.1e}" for e in errs) + f"   {sp:6.1f}x")

    return results, orders, dim, ccfg.distribution


def make_figure(results, orders, dim, dist_name, out_path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    mesh_N = sorted(results["mesh"])
    perk_N = sorted(results["perk"])
    mesh_nk = [n ** dim for n in mesh_N]
    perk_nk = [n ** dim for n in perk_N]

    fig, ax = plt.subplots(2, 3, figsize=(15, 8))
    fig.suptitle(f"Mesh-vectorized vs per-k recursion  (distribution = {dist_name})",
                 fontsize=13, fontweight="bold")

    # Row 1: observable |J^(s)| vs Nk (convergence + overlap), one per order
    for j, s in enumerate(orders[:3]):
        a = ax[0, j]
        ym = [np.linalg.norm(results["mesh"][n]["J"][s]) for n in mesh_N]
        yp = [np.linalg.norm(results["perk"][n]["J"][s]) for n in perk_N]
        a.plot(mesh_nk, ym, "-o", color="C0", label="mesh (new)", zorder=2)
        a.plot(perk_nk, yp, "x", color="C3", ms=10, mew=2.5, label="per-k (old)", zorder=3)
        a.set_xscale("log")
        a.set_title(f"observable  |J$^{{({s})}}$|  vs  $N_k$")
        a.set_xlabel("$N_k$ (k-points)")
        a.set_ylabel(f"|J$^{{({s})}}$|  (a.u.)")
        a.grid(True, which="both", alpha=0.3)
        a.legend(fontsize=9)

    # Row 2, col 0: wall-time vs Nk
    a = ax[1, 0]
    a.plot(mesh_nk, [results["mesh"][n]["t"] for n in mesh_N], "-o", color="C0", label="mesh (new)")
    a.plot(perk_nk, [results["perk"][n]["t"] for n in perk_N], "-s", color="C3", label="per-k (old)")
    a.set_xscale("log"); a.set_yscale("log")
    a.set_title("wall-clock time  vs  $N_k$")
    a.set_xlabel("$N_k$"); a.set_ylabel("time (s)")
    a.grid(True, which="both", alpha=0.3); a.legend(fontsize=9)

    # Row 2, col 1: speedup vs Nk
    a = ax[1, 1]
    common = [n for n in perk_N if n in results["mesh"]]
    sp = [results["perk"][n]["t"] / max(results["mesh"][n]["t"], 1e-12) for n in common]
    a.plot([n ** dim for n in common], sp, "-^", color="C2")
    a.set_xscale("log")
    a.set_title("speedup  (per-k time / mesh time)")
    a.set_xlabel("$N_k$"); a.set_ylabel("speedup  (x)")
    a.grid(True, which="both", alpha=0.3)
    for x, y in zip([n ** dim for n in common], sp):
        a.annotate(f"{y:.0f}x", (x, y), textcoords="offset points", xytext=(0, 6), fontsize=8, ha="center")

    # Row 2, col 2: relative error mesh vs per-k (physics agreement)
    a = ax[1, 2]
    for s in orders[:3]:
        errs = [np.linalg.norm(results["mesh"][n]["J"][s] - results["perk"][n]["J"][s])
                / max(np.linalg.norm(results["perk"][n]["J"][s]), 1e-300) for n in common]
        a.plot([n ** dim for n in common], errs, "-o", label=f"order {s}")
    a.set_xscale("log"); a.set_yscale("log")
    a.set_title("rel. error  |J$^{(s)}_{mesh}$ − J$^{(s)}_{perk}$| / |J$^{(s)}_{perk}$|")
    a.set_xlabel("$N_k$"); a.set_ylabel("relative error")
    a.axhline(1e-12, color="gray", ls="--", lw=1, alpha=0.7)
    a.grid(True, which="both", alpha=0.3); a.legend(fontsize=9)

    fig.tight_layout(rect=[0, 0, 1, 0.96])
    fig.savefig(out_path, dpi=140)
    print(f"\n[figura guardada] {out_path}")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--config", default="inputs/inputParams.wsm.cfg")
    p.add_argument("--mesh-grids", type=int, nargs="+", default=[4, 6, 8, 10, 12, 16, 20, 24])
    p.add_argument("--perk-grids", type=int, nargs="+", default=[4, 6, 8, 10, 12])
    p.add_argument("--max-order", type=int, default=3)
    p.add_argument("--drive", choices=["x", "y", "z"], default="z")
    p.add_argument("--amp", type=float, default=1.0e-3)
    p.add_argument("--out", default="outputs/mesh_vs_perk_comparison.png")
    args = p.parse_args()

    results, orders, dim, dist_name = run_study(
        args.config, args.mesh_grids, args.perk_grids, args.max_order, args.drive, args.amp)
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    make_figure(results, orders, dim, dist_name, args.out)


if __name__ == "__main__":
    main()
