#!/usr/bin/env python3
"""2D maps at kx=pi/2: Berry connection |A^z_12(ky,kz)| and Berry curvature Omega^z(ky,kz).

Both quantities for the two crossing Weyl bands, shown as 2D colormaps.
Axes: kya (x), kza (y).  Each plot for the physical Delta=0.5.
"""
from __future__ import annotations

import os, sys, importlib.util
from pathlib import Path
import numpy as np

os.environ.setdefault("MPLCONFIGDIR", "/private/tmp")
os.environ.setdefault("XDG_CACHE_HOME", "/private/tmp")
PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

_EV = 27.211386245988
OUT = Path("outputs/susceptibility_maps/wsm_orenstein")


def main():
    spec = importlib.util.spec_from_file_location(
        "wsm_o", PROJECT_ROOT / "models" / "wsm_orenstein.py")
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.colors import LogNorm, TwoSlopeNorm
    from qxti.graphics.custom_cmap import custom_cmap_div
    from qxti.graphics.plot_susceptibility_tensor import apply_paper_style

    p = mod.default_params()
    a = float(p["a"])
    kx_fixed = np.pi / (2.0 * a)
    dk = 1e-3

    N = 180
    ky_vals = np.linspace(-np.pi/4 / a, np.pi/4 / a, N)
    kz_vals = np.linspace(-np.pi/4 / a, np.pi/4 / a, N)
    KYA, KZA = np.meshgrid(ky_vals * a, kz_vals * a, indexing="ij")

    Ac_map   = np.empty((N, N))   # |A^z_12|
    Oz_map   = np.empty((N, N))   # Omega^z (band 2, index 1)
    gap_map  = np.empty((N, N))   # band gap e3-e2

    print(f"[2d-berry] computing {N}x{N} grid at kx*a=pi/2 ...")
    for i, ky in enumerate(ky_vals):
        for j, kz in enumerate(kz_vals):
            k = np.array([kx_fixed, ky, kz])
            H0 = mod.H(*k, p)
            e, U = np.linalg.eigh(H0)
            Ud = np.conj(U.T)

            def vel(ax):
                sh = np.zeros(3); sh[ax] = dk
                dH = (mod.H(*(k+sh), p) - mod.H(*(k-sh), p)) / (2*dk)
                return Ud @ dH @ U

            vx_b = vel(0); vy_b = vel(1); vz_b = vel(2)

            eps = e[:, None] - e[None, :]   # en - em
            valid = ~np.eye(4, dtype=bool)

            # Interband Berry connection |A^z_12| = |i*vz_12 / (e2-e1)|
            eps12 = e[2] - e[1]
            Ac_map[i, j] = abs(1j * vz_b[1, 2] / eps12) if abs(eps12) > 1e-15 else 0.0
            gap_map[i, j] = eps12 * _EV

            # Berry curvature Omega^z for band 2 (index 1):
            # Omega^z_n = -2 Im sum_{m!=n} vx_{nm} vy_{mn} / (em-en)^2
            n = 1
            total = 0.0
            for mm in range(4):
                if mm == n: continue
                emn = e[mm] - e[n]
                if abs(emn) < 1e-15: continue
                total += -2.0 * np.imag(vx_b[n, mm] * vy_b[mm, n] / emn**2)
            Oz_map[i, j] = total

        if (i+1) % 30 == 0:
            print(f"  {i+1}/{N} rows done")

    print("[2d-berry] done. Plotting ...")

    apply_paper_style()
    fig, axes = plt.subplots(1, 3, figsize=(20, 7.0))

    ticks = np.array([-np.pi/4, 0.0, np.pi/4])
    tlabels = [r"$-\pi/4$", r"$0$", r"$\pi/4$"]

    def _style(ax, title):
        ax.set_xlabel(r"$k_y a$", fontsize=22, labelpad=8)
        ax.set_ylabel(r"$k_z a$", fontsize=22, labelpad=8)
        ax.set_title(title, fontsize=20, pad=6)
        ax.set_xticks(ticks); ax.set_xticklabels(tlabels, fontsize=18)
        ax.set_yticks(ticks); ax.set_yticklabels(tlabels, fontsize=18)
        ax.tick_params(labelsize=18)

    # ── Panel 1: band gap ──────────────────────────────────────────────────
    ax = axes[0]
    vmax_g = np.percentile(gap_map, 99)
    im0 = ax.pcolormesh(KYA, KZA, gap_map, shading="auto",
                        cmap="viridis",
                        norm=LogNorm(vmin=max(gap_map.min(), 1e-4), vmax=vmax_g))
    cb0 = fig.colorbar(im0, ax=ax, pad=0.02)
    cb0.set_label(r"$\varepsilon_{23}(\mathbf{k})$ (eV)", fontsize=16)
    cb0.ax.tick_params(labelsize=14)
    # mark Weyl node
    ky_node = np.arctan(float(p["Delta"])) / a * a   # kya
    ax.scatter([ky_node], [0.0], s=120, color="red", edgecolors="white",
               linewidths=1.5, zorder=7)
    ax.scatter([-ky_node], [0.0], s=120, color="red", edgecolors="white",
               linewidths=1.5, zorder=7)
    _style(ax, r"Band gap $\varepsilon_{23}(\mathbf{k})$")

    # ── Panel 2: Berry connection |A^z_12| ────────────────────────────────
    ax = axes[1]
    Ac_plot = np.clip(Ac_map, 1e-4, None)
    vmax_a = np.percentile(Ac_plot, 99.5)
    im1 = ax.pcolormesh(KYA, KZA, Ac_plot, shading="auto",
                        cmap="inferno",
                        norm=LogNorm(vmin=Ac_plot.min(), vmax=vmax_a))
    cb1 = fig.colorbar(im1, ax=ax, pad=0.02)
    cb1.set_label(r"$|\mathcal{A}^z_{12}(\mathbf{k})|$ (Bohr)", fontsize=16)
    cb1.ax.tick_params(labelsize=14)
    ax.scatter([ky_node, -ky_node], [0.0, 0.0], s=120, color="white",
               edgecolors="grey", linewidths=1.5, zorder=7)
    _style(ax, r"Berry connection $|\mathcal{A}^z_{12}|$")

    # ── Panel 3: Berry curvature Omega^z (band 2) ─────────────────────────
    ax = axes[2]
    vmax_o = np.percentile(np.abs(Oz_map), 99)
    norm_o = TwoSlopeNorm(vmin=-vmax_o, vcenter=0.0, vmax=vmax_o)
    im2 = ax.pcolormesh(KYA, KZA, Oz_map, shading="auto",
                        cmap=custom_cmap_div, norm=norm_o)
    cb2 = fig.colorbar(im2, ax=ax, pad=0.02)
    cb2.set_label(r"$\Omega^z_2(\mathbf{k})$ (a.u.)", fontsize=16)
    cb2.ax.tick_params(labelsize=14)
    ax.scatter([ky_node, -ky_node], [0.0, 0.0], s=120, color="black",
               edgecolors="white", linewidths=1.5, zorder=7)
    _style(ax, r"Berry curvature $\Omega^z_2(\mathbf{k})$")

    fig.suptitle(r"$k_x a = \pi/2$,  $\Delta=0.5$ — 2D maps in $k_y$–$k_z$ plane",
                 fontsize=20, y=1.01)
    fig.tight_layout()

    OUT.mkdir(parents=True, exist_ok=True)
    f = OUT / "wsm_orenstein_berry_2d_kxpi2.png"
    fig.savefig(f, dpi=220, facecolor="white", bbox_inches="tight")
    plt.close(fig)
    print(f"[2d-berry] wrote {f}")


if __name__ == "__main__":
    main()
