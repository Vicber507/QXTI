#!/usr/bin/env python3
"""BZ |chi^(1)_zz| integrand maps for multiple Delta values at their resonant energies.

Delta / omega_eV pairs:
    Delta=0.500  ->  omega=0.91 eV
    Delta=0.375  ->  omega=0.87 eV
    Delta=0.250  ->  omega=0.82 eV
    Delta=0.125  ->  omega=0.81 eV

Output: outputs/bz_chi_contribution/chi1_zz/delta_sweep/

Usage:
    python tools/plot_bz_chi1_zz_delta_sweep.py [--points N] [--dpi D]
"""
from __future__ import annotations

import argparse
import importlib.util
import os
import sys
import time
from pathlib import Path

import numpy as np
from numpy.typing import NDArray

os.environ.setdefault("MPLCONFIGDIR", "/private/tmp")
os.environ.setdefault("XDG_CACHE_HOME", "/private/tmp")

import matplotlib
matplotlib.use("Agg")
from matplotlib import pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from qxti.analytics.theory_response import _resolve_distribution
from qxti.core import QXTIConfig
from qxti.core.simulation import QXTISimulation
from qxti.graphics.plot_susceptibility_tensor import apply_paper_style
from qxti.utils.progress import format_duration

AU_TO_EV = 27.211386245988

ComplexArray = NDArray[np.complex128]
FloatArray = NDArray[np.float64]

SWEEP = [
    {"delta": 0.500, "omega_ev": 0.91},
    {"delta": 0.375, "omega_ev": 0.87},
    {"delta": 0.250, "omega_ev": 0.82},
    {"delta": 0.125, "omega_ev": 0.81},
]


def _abs_cmap():
    return LinearSegmentedColormap.from_list(
        "qxti_bz_chi",
        ["#081B33", "#0E4F6F", "#2A9D8F", "#F3E9D2", "#F4A261", "#B23A48"],
        N=256)


def _pi_ticks(ax, axis_values, which="x"):
    import math
    lo, hi = float(axis_values[0]), float(axis_values[-1])
    step = np.pi / 2.0
    first = math.ceil((lo - 1e-9) / step) * step
    ticks = np.arange(first, hi + step * 0.5, step)
    ticks = ticks[(ticks >= lo - 1e-9) & (ticks <= hi + 1e-9)]
    _tex = {0.0: r"$0$", np.pi/2: r"$\pi/2$", np.pi: r"$\pi$",
            3*np.pi/2: r"$3\pi/2$", 2*np.pi: r"$2\pi$",
            -np.pi/2: r"$-\pi/2$", -np.pi: r"$-\pi$"}
    labels = [next((v for k, v in _tex.items() if abs(t - k) < 1e-9),
                   rf"${t/np.pi:.2g}\pi$") for t in ticks]
    if which == "x":
        ax.set_xticks(ticks); ax.set_xticklabels(labels, fontsize=15)
    else:
        ax.set_yticks(ticks); ax.set_yticklabels(labels, fontsize=15)


def _batched_H(Hf, k_points):
    return np.asarray([Hf(float(k[0]), float(k[1]), float(k[2])) for k in k_points],
                      dtype=np.complex128)


def _compute_data(Hf, k_points, dist, mu, temperature, velocity_step=1e-4):
    h0 = _batched_H(Hf, k_points)
    energies, U = np.linalg.eigh(h0)
    Udag = np.conj(np.transpose(U, (0, 2, 1)))
    vel = {}
    for axis in range(3):
        sh = np.zeros(3); sh[axis] = velocity_step
        dH = (_batched_H(Hf, k_points + sh) - _batched_H(Hf, k_points - sh)) / (2 * velocity_step)
        vel[axis] = Udag @ dH @ U
    occ = np.asarray(dist(energies, mu, temperature), dtype=np.float64)
    eps = energies[:, :, None] - energies[:, None, :]
    fmn = occ[:, None, :] - occ[:, :, None]
    nb = int(energies.shape[1])
    valid = (~np.eye(nb, dtype=bool))[None] & (np.abs(eps) > 1e-20)
    with np.errstate(divide="ignore", invalid="ignore"):
        inv_eps = np.where(valid, 1.0 / eps, 0.0)
    dfde = (-occ * (1 - occ) / temperature if temperature > 1e-15
            else np.zeros_like(occ))
    return {"vel": vel, "fmn": fmn, "eps": eps, "valid": valid,
            "inv_eps": inv_eps, "dfde": dfde, "nb": nb}


def _rho1(data, axis, omega_c):
    nb = data["nb"]
    vel = np.asarray(data["vel"][axis], dtype=np.complex128)
    inv_eps = np.asarray(data["inv_eps"], dtype=np.complex128)
    fmn = np.asarray(data["fmn"], dtype=np.float64)
    eps = np.asarray(data["eps"], dtype=np.float64)
    valid = np.asarray(data["valid"], dtype=bool)
    dfde = np.asarray(data["dfde"], dtype=np.float64)
    A = 1j * vel * inv_eps
    with np.errstate(divide="ignore", invalid="ignore"):
        rho = np.where(valid, (A * fmn) / (omega_c - eps), 0j)
    diag = (-1j) * dfde * np.real(np.diagonal(vel, axis1=1, axis2=2))
    rho[:, np.arange(nb), np.arange(nb)] += diag / omega_c
    return np.asarray(rho, dtype=np.complex128)


def _sigma1_integrand(data, axis, omega_c):
    vel_a = np.asarray(data["vel"][axis], dtype=np.complex128)
    rho = _rho1(data, axis, omega_c)
    return np.einsum("kmn,knm->k", vel_a, rho)


def compute_and_plot(config_path: str, delta: float, omega_ev: float,
                     N: int, dpi: int, out_base: Path,
                     plane: str = "kz", fixed: float = 0.0) -> None:
    plane_axis = {"kx": 0, "ky": 1, "kz": 2}[plane]
    plane_axes = [i for i in range(3) if i != plane_axis]
    ax_labels  = [("x", "y", "z")[i] for i in plane_axes]

    config = QXTIConfig.from_file(Path(config_path))
    config.hamiltonian.params["Delta"] = delta

    sim = QXTISimulation(config=config)
    ham = sim.build_hamiltonian()
    Hf  = ham._matrix_at

    source = Path(str(config.hamiltonian.source_file))
    model_path = source if source.is_absolute() else PROJECT_ROOT / "models" / source
    spec = importlib.util.spec_from_file_location(f"model_{model_path.stem}", model_path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    params = dict(config.hamiltonian.params)

    dist        = _resolve_distribution(config.susceptibility_solver.distribution)
    mu          = float(config.susceptibility_solver.fermi_level)
    temperature = float(config.susceptibility_solver.temperature)
    gamma_au    = (0.0 if config.susceptibility_solver.coherence_time <= 0
                   else 1.0 / float(config.susceptibility_solver.coherence_time))
    omega_au    = omega_ev / AU_TO_EV
    omega_c     = complex(omega_au, gamma_au)

    bounds = ham.reciprocal_box_bounds()
    lo0, hi0 = float(bounds[plane_axes[0]][0]), float(bounds[plane_axes[0]][1])
    lo1, hi1 = float(bounds[plane_axes[1]][0]), float(bounds[plane_axes[1]][1])
    step0 = (hi0 - lo0) / N; ax1 = np.linspace(lo0, hi0, N, endpoint=False) + 0.5 * step0
    step1 = (hi1 - lo1) / N; ax2 = np.linspace(lo1, hi1, N, endpoint=False) + 0.5 * step1

    G1, G2 = np.meshgrid(ax1, ax2, indexing="ij")
    k_flat = np.zeros((N * N, 3), dtype=np.float64)
    k_flat[:, plane_axes[0]] = G1.ravel()
    k_flat[:, plane_axes[1]] = G2.ravel()
    k_flat[:, plane_axis]    = fixed

    t0 = time.perf_counter()
    print(f"  [Δ={delta}  ω={omega_ev}eV  chi1_zz  {plane}={fixed:.4f}]  "
          f"computing {N}x{N} ...", flush=True)

    data = _compute_data(Hf, k_flat, dist, mu, temperature)
    integrand = _sigma1_integrand(data, axis=2, omega_c=omega_c)
    chi_map = integrand.reshape(N, N)

    a_lat  = float(params.get("a", 1.0))
    x_plot = ax1 * a_lat
    y_plot = ax2 * a_lat

    apply_paper_style()
    fig, ax = plt.subplots(figsize=(7.4, 6.2))
    XP, YP = np.meshgrid(x_plot, y_plot, indexing="ij")
    im = ax.pcolormesh(XP, YP, np.abs(chi_map), shading="auto", cmap=_abs_cmap())
    ax.set_xlabel(rf"$k_{{{ax_labels[0]}}}\,a$", fontsize=20)
    ax.set_ylabel(rf"$k_{{{ax_labels[1]}}}\,a$", fontsize=20)
    _pi_ticks(ax, x_plot, "x")
    _pi_ticks(ax, y_plot, "y")
    ax.tick_params(labelsize=15)
    cb = fig.colorbar(im, ax=ax, pad=0.02)
    cb.set_label(r"$|\mathcal{I}^{(1)}_{zz}(\mathbf{k})|$", fontsize=18)
    cb.ax.tick_params(labelsize=14)
    fixed_tex = f"{fixed/np.pi:.3g}\\pi" if fixed != 0.0 else "0"
    ax.set_title(
        rf"$|\chi^{{(1)}}_{{zz}}|$,  $\Delta={delta}$,  "
        rf"$\omega={omega_ev}\,\mathrm{{eV}}$,  $k_{{{plane[-1]}}}a={fixed_tex}$",
        fontsize=14, pad=6)
    fig.tight_layout()

    delta_str = f"{delta:.3f}".replace(".", "p")
    omega_str = f"{omega_ev:.2f}".replace(".", "p")
    fixed_str = f"{fixed:.4f}".replace("-", "m").replace(".", "p")
    out_dir = out_base / "chi1_zz" / "delta_sweep"
    out_dir.mkdir(parents=True, exist_ok=True)
    fname = out_dir / f"chi1_zz_delta{delta_str}_omega{omega_str}_{plane}{fixed_str}_abs.png"
    fig.savefig(fname, dpi=dpi, facecolor="white", bbox_inches="tight")
    plt.close(fig)
    print(f"  -> {fname}  [{format_duration(time.perf_counter() - t0)}]", flush=True)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="inputs/inputParams.wsm_orenstein.cfg")
    ap.add_argument("--points", type=int, default=180)
    ap.add_argument("--dpi",    type=int, default=280)
    ap.add_argument("--plane",  choices=("kx", "ky", "kz"), default="kz")
    ap.add_argument("--fixed",  type=float, default=0.0,
                    help="Valor fijo del plano en 1/Bohr. Ej: -1.5708 para -pi/2.")
    args = ap.parse_args()

    out_base = Path("outputs/bz_chi_contribution")
    for entry in SWEEP:
        compute_and_plot(args.config, entry["delta"], entry["omega_ev"],
                         args.points, args.dpi, out_base,
                         plane=args.plane, fixed=args.fixed)

    print("\n[done] all chi1_zz delta-sweep plots generated.", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
