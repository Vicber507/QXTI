#!/usr/bin/env python3
from __future__ import annotations

"""Paper-style transverse Cartesian sigma plots from saved WSM node-mask data."""

import argparse
import os
from pathlib import Path
import sys

os.environ.setdefault("MPLCONFIGDIR", "/private/tmp")
os.environ.setdefault("XDG_CACHE_HOME", "/private/tmp")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
TOOLS_DIR = PROJECT_ROOT / "tools"
for candidate in (PROJECT_ROOT, TOOLS_DIR):
    if str(candidate) not in sys.path:
        sys.path.insert(0, str(candidate))

from plot_wsm_helicity_sigma_node_masks import (
    DEFAULT_OUTPUT_DIR,
    TRANSVERSE_COMPONENTS,
    _load_saved_cartesian_node_mask_cases,
    _plot_cartesian_transverse_paper,
)
from qxti.graphics.plot_susceptibility_tensor import apply_paper_style


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Genera plots tipo paper de sigma_xy, sigma_xz y sigma_yz usando los "
            "datos ya guardados por plot_wsm_helicity_sigma_node_masks.py."
        )
    )
    parser.add_argument(
        "--base-dir",
        default=str(DEFAULT_OUTPUT_DIR),
        help="Directorio base con full/no_positive_chirality/no_negative_chirality.",
    )
    parser.add_argument(
        "--output-dir",
        default=None,
        help="Directorio de salida. Default: <base-dir>/comparison/cartesian_transverse.",
    )
    parser.add_argument(
        "--components",
        default=",".join(TRANSVERSE_COMPONENTS),
        help="Componentes separadas por coma, default: %(default)s.",
    )
    parser.add_argument(
        "--quantity",
        default="abs",
        choices=("abs", "real", "imag"),
        help="Cantidad a graficar para cada sigma.",
    )
    parser.add_argument("--dpi", type=int, default=340)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    apply_paper_style()
    base_dir = Path(args.base_dir)
    output_dir = Path(args.output_dir) if args.output_dir else base_dir / "comparison" / "cartesian_transverse"
    components = tuple(part.strip().lower() for part in args.components.split(",") if part.strip())
    omega_axis_ev, case_tensors, cart_labels = _load_saved_cartesian_node_mask_cases(base_dir)
    outputs = _plot_cartesian_transverse_paper(
        output_dir=output_dir,
        omega_axis_ev=omega_axis_ev,
        case_tensors=case_tensors,
        cart_labels=cart_labels,
        components=components,
        quantity=args.quantity,
        dpi=int(args.dpi),
    )
    for path in outputs:
        print(path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
