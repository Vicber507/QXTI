#!/usr/bin/env python3
"""Publication figures from the Orenstein convergence study:
  Fig 1: k-grid convergence of chi^(2) components at low vs high frequency.
  Fig 2: gamma (broadening) and frequency dependence.
  Fig 3: the converged CD(theta2) at 0.9 eV -> reproduces Wu Fig. 2c (pure sin 2theta2).
"""
from __future__ import annotations
import os, sys
from pathlib import Path
import numpy as np

os.environ.setdefault("MPLCONFIGDIR", "/private/tmp")
os.environ.setdefault("XDG_CACHE_HOME", "/private/tmp")
PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from qxti.core import QXTIConfig, QXTISimulation
from qxti.analytics.theory_response import order2_tensor_at_omega, build_k_integration_weights

AU_TO_EV = 27.211386245988
E1 = np.array([1., 1.,-1.])/np.sqrt(3.)
E2 = np.array([1.,-1., 0.])/np.sqrt(2.)
OUT = PROJECT_ROOT / 'outputs/convergence_orenstein'


def _load():
    d = np.load(OUT / 'convergence_results.npz', allow_pickle=True)
    return {k: d[k] for k in d.files}


def _series(flat, study, key, n):
    return np.array([complex(flat[f"{study}_{i}_{key}"]) for i in range(n)])


def main():
    import matplotlib; matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    try:
        from qxti.graphics.plot_susceptibility_tensor import apply_paper_style
        apply_paper_style()
    except Exception:
        pass

    flat = _load()

    # grids used in studies A and B
    gridsA = [40, 50, 60, 70, 80, 100, 120]
    gridsB = [40, 50, 60, 70, 80, 100]
    nkA = [int(round(abs(flat[f"A_lowfreq_guard_{i}_nk_eff"]))) for i in range(len(gridsA))]
    nkB = [int(round(abs(flat[f"B_highfreq_guard_{i}_nk_eff"]))) for i in range(len(gridsB))]

    comps = ['chi_zzz', 'chi_zxx', 'chi_zyy', 'chi_xzx']
    clr = {'chi_zzz':'#D55E00', 'chi_zxx':'#0072B2',
           'chi_zyy':'#009E73', 'chi_xzx':'#CC79A7'}
    lbl = {'chi_zzz':r'$|\chi_{zzz}|$ (diag.)', 'chi_zxx':r'$|\chi_{zxx}|$',
           'chi_zyy':r'$|\chi_{zyy}|$', 'chi_xzx':r'$|\chi_{xzx}|=|2d_{15}|$'}

    # ══ FIG 1: k-grid convergence, low vs high freq ═══════════════════════════
    fig, (axL, axH) = plt.subplots(1, 2, figsize=(11, 4.4),
                                   gridspec_kw={'wspace': 0.28})
    for c in comps:
        yL = np.abs(_series(flat, 'A_lowfreq_guard', c, len(gridsA)))
        yH = np.abs(_series(flat, 'B_highfreq_guard', c, len(gridsB)))
        # normalize each to its 120³/100³ converged value
        axL.plot(nkA, yL/yL[-1], 'o-', color=clr[c], lw=1.8, ms=5, label=lbl[c])
        axH.plot(nkB, yH/yH[-1], 'o-', color=clr[c], lw=1.8, ms=5, label=lbl[c])

    for ax, ttl in [(axL, r'(a) $\hbar\omega=0.27$ eV (near Weyl nodes, $2\omega$ sub-gap)'),
                    (axH, r'(b) $\hbar\omega=0.90$ eV (near $\chi$ peak, off-node)')]:
        ax.axhspan(0.95, 1.05, color='0.85', alpha=0.5, zorder=0,
                   label='_nolegend_')
        ax.axhline(1.0, color='0.5', lw=0.8, ls='--')
        ax.set_xlabel(r'k-grid linear size $N$ ($N^3$ points)', fontsize=12)
        ax.set_ylabel(r'$|\chi^{(2)}| / |\chi^{(2)}|_{\rm converged}$', fontsize=12)
        ax.set_title(ttl, fontsize=10.5)
        ax.set_ylim(0, 2.6)
        ax.legend(fontsize=9, loc='upper right')
    axL.text(0.5, 0.06, '±5% band', transform=axL.transAxes, fontsize=8, color='0.4')
    fig.suptitle('k-grid convergence of the Orenstein model $\\chi^{(2)}$ components',
                 fontsize=11.5, y=1.01)
    fig.savefig(OUT/'fig1_kgrid_convergence.png', dpi=300, facecolor='white', bbox_inches='tight')
    plt.close(fig)
    print(f"wrote {OUT/'fig1_kgrid_convergence.png'}")

    # ══ FIG 2: gamma sweep + frequency dependence ═════════════════════════════
    gam_meV = [494.8, 247.4, 123.7, 61.8, 30.9]
    fig, (axG, axF) = plt.subplots(1, 2, figsize=(11, 4.4),
                                   gridspec_kw={'wspace': 0.30})
    for c in comps:
        yG = np.abs(_series(flat, 'C_gamma', c, len(gam_meV)))
        axG.plot(gam_meV, yG, 'o-', color=clr[c], lw=1.8, ms=5, label=lbl[c])
    axG.axvline(123.7, color='0.5', lw=0.9, ls=':')
    axG.text(130, axG.get_ylim()[1]*0.5, r'physical $\gamma$', fontsize=8.5, color='0.4', rotation=90)
    axG.set_xlabel(r'broadening $\gamma$ (meV)', fontsize=12)
    axG.set_ylabel(r'$|\chi^{(2)}|$ (arb.)', fontsize=12)
    axG.set_title(r'(a) $\gamma$ sweep @ 0.27 eV, $80^3$ (fixed grid)', fontsize=10.5)
    axG.set_yscale('log')
    axG.legend(fontsize=9, loc='upper right')
    axG.annotate('off-diagonal blow up\nas node singularity\nunder-resolved',
                 xy=(30.9, 9080), xytext=(80, 200), fontsize=8.5,
                 arrowprops=dict(arrowstyle='->', color='0.4'))

    # frequency dependence
    freqs = [0.15, 0.30, 0.50, 0.70, 0.90, 1.20, 1.55]
    zzz = np.abs(_series(flat, 'D_frequency', 'chi_zzz', len(freqs)))
    xzx = np.abs(_series(flat, 'D_frequency', 'chi_xzx', len(freqs)))
    ratio = zzz/np.maximum(xzx, 1e-30)
    ax2 = axF.twinx()
    axF.plot(freqs, zzz, 'o-', color='#D55E00', lw=2.0, ms=5, label=r'$|\chi_{zzz}|$')
    axF.plot(freqs, xzx, 's-', color='#CC79A7', lw=2.0, ms=5, label=r'$|\chi_{xzx}|$')
    ax2.plot(freqs, ratio, '^--', color='#0072B2', lw=1.6, ms=5, label=r'$|d_{33}/d_{15}|$')
    ax2.axhspan(25, 33, color='#0072B2', alpha=0.12, zorder=0)
    ax2.text(1.05, 29, 'exp. 25-33', color='#0072B2', fontsize=8.5)
    axF.axvline(0.9, color='0.5', lw=0.9, ls=':')
    axF.set_xlabel(r'$\hbar\omega$ (eV)', fontsize=12)
    axF.set_ylabel(r'$|\chi^{(2)}|$ (arb.)', fontsize=11, color='#D55E00')
    ax2.set_ylabel(r'$|d_{33}/d_{15}|$ ratio', fontsize=11, color='#0072B2')
    axF.set_title(r'(b) frequency dependence @ $80^3$', fontsize=10.5)
    ax2.set_ylim(0, 40)
    l1,b1 = axF.get_legend_handles_labels(); l2,b2 = ax2.get_legend_handles_labels()
    axF.legend(l1+l2, b1+b2, fontsize=9, loc='upper left')
    fig.suptitle('Broadening and frequency dependence: node singularity regularization',
                 fontsize=11.5, y=1.01)
    fig.savefig(OUT/'fig2_gamma_frequency.png', dpi=300, facecolor='white', bbox_inches='tight')
    plt.close(fig)
    print(f"wrote {OUT/'fig2_gamma_frequency.png'}")

    # ══ FIG 3: converged CD(theta2) at 0.9 eV -> reproduces Wu Fig 2c ═════════
    print("Computing converged CD at 0.9 eV, 100^3 ...", flush=True)
    cfg = QXTIConfig.from_file('inputs/inputParams.wsm_orenstein.cfg')
    cfg.kgrid.k_points = [100, 100, 100]
    cfg.kgrid.auto_degeneracy_guard = True
    cfg.kgrid.shifted = True
    sim = QXTISimulation(config=cfg)
    H = sim.build_hamiltonian(); kg = sim.build_kgrid(H)
    w = build_k_integration_weights(cfg, hamiltonian=H, kgrid=kg)
    s2 = order2_tensor_at_omega(H, kg, 0.9/AU_TO_EV, w, cfg.cmd)

    E_plus, E_minus = 0.5*(E1+1j*E2), 0.5*(E1-1j*E2)
    Jp = np.einsum('ijk,j,k->i', s2, E_plus, E_plus)
    Jm = np.einsum('ijk,j,k->i', s2, E_minus, E_minus)
    theta = np.linspace(0, 2*np.pi, 721); tdeg = np.degrees(theta)
    ct, st = np.cos(theta), np.sin(theta)
    Ip = np.abs(ct*np.dot(E1,Jp)+st*np.dot(E2,Jp))**2
    Im = np.abs(ct*np.dot(E1,Jm)+st*np.dot(E2,Jm))**2
    cd = Ip - Im
    norm = np.max(np.abs(cd)); cd_n = cd/norm
    a_s = 2*np.mean(cd_n*np.sin(2*theta)); a_c = 2*np.mean(cd_n*np.cos(2*theta))
    dc  = np.mean(cd_n)
    chi2 = s2/(-1j*2*(0.9/AU_TO_EV))
    ratio_val = abs(chi2[2,2,2])/abs(chi2[0,2,0])

    fig, ax = plt.subplots(figsize=(6.2, 4.6))
    ax.axhline(0, color='0.65', lw=0.9)
    for y in (-1,1): ax.axhline(y, color='0.75', lw=0.5, ls='--')
    ax.plot(tdeg, cd_n, '-', color='#5B4A9B', lw=2.4, label='Model, converged $100^3$')
    ax.plot(tdeg, a_s*np.sin(2*theta), '--', color='#009E73', lw=1.6,
            label=rf'$A_s\sin 2\theta_2$ ($A_s={a_s:+.2f}$)')
    ax.plot(tdeg, np.sin(2*theta+np.pi)*np.sign(a_s), ':', color='k', lw=1.4, alpha=0.6,
            label='Wu et al. Fig. 2c (pure sin)')
    ax.set_xlim(0,360); ax.set_ylim(-1.2,1.2)
    ax.set_xticks([0,90,180,270,360])
    ax.set_xticklabels([r'0°'+'\n'+r'$[1,1,\bar1]$', r'90°'+'\n'+r'$[1,\bar1,0]$',
                        r'180°', r'270°', r'360°'], fontsize=9)
    ax.set_xlabel(r'analyzer angle $\theta_2$', fontsize=12)
    ax.set_ylabel(r'CD$(\theta_2)$ / |peak|', fontsize=12)
    ax.legend(fontsize=9.5, loc='lower right')
    ax.text(0.03, 0.97,
        rf'$\hbar\omega=0.9$ eV (near $\chi$ peak)' '\n'
        rf'$|d_{{33}}/d_{{15}}|={ratio_val:.1f}$ (exp. 25-33)' '\n'
        rf'$A_c={a_c:+.2f}$, DC$={dc:+.2f}$ (small)',
        transform=ax.transAxes, fontsize=8.5, va='top',
        bbox=dict(fc='#e8f5e9', ec='#009E73', pad=3, alpha=0.9))
    ax.set_title('Converged SHG circular dichroism, TaAs (112)\n'
                 'Orenstein model reproduces Wu Fig. 2c at the physical frequency',
                 fontsize=10.5)
    fig.savefig(OUT/'fig3_converged_cd_0p9eV.png', dpi=300, facecolor='white', bbox_inches='tight')
    plt.close(fig)
    print(f"wrote {OUT/'fig3_converged_cd_0p9eV.png'}")
    print(f"\nConverged CD @ 0.9 eV: A_sin={a_s:+.3f}, A_cos={a_c:+.3f}, DC={dc:+.3f}, "
          f"|d33/d15|={ratio_val:.1f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
