#!/usr/bin/env python3
"""Berry curvature and Berry connection heatmaps on the kx-kz plane (ky=0).

Panels produced (per Delta):
  Berry curvature (Fermi-weighted sum over bands):
    - Omega^x(kx, kz)
    - Omega^y(kx, kz)
    - Omega^z(kx, kz)
    - |Omega|(kx, kz)

  Berry connection (diagonal, band-averaged with occupation):
    - A^x_z  — x-component of A along kz direction (dagger gauge)
    - A^z_z  — z-component of A along kz direction

  Berry curvature per band (2x2 grid, bands 2 and 3 — the Weyl crossing pair)

Usage:
    python tools/plot_bz_berry_kxkz.py [--points N] [--dpi D]
"""
from __future__ import annotations

import argparse
import importlib.util
import math
import os
import sys
from pathlib import Path

import numpy as np

os.environ.setdefault("MPLCONFIGDIR", "/private/tmp")
os.environ.setdefault("XDG_CACHE_HOME", "/private/tmp")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm, LogNorm

from qxti.analytics.theory_response import _resolve_distribution
from qxti.core import QXTIConfig
from qxti.core.simulation import QXTISimulation
from qxti.graphics.custom_cmap import custom_cmap_div
from qxti.graphics.plot_susceptibility_tensor import apply_paper_style

_EV  = 27.211386245988
OUT  = Path("outputs/bz_chi_contribution/berry_kxkz")
DELTAS = (0.5, 0.375, 0.25, 0.125)


# ── helpers ───────────────────────────────────────────────────────────────────

def _pi_ticks(ax, vals, which="x"):
    lo, hi = float(vals[0]), float(vals[-1])
    step = np.pi / 2
    first = math.ceil((lo - 1e-9) / step) * step
    ticks = np.arange(first, hi + step * 0.5, step)
    ticks = ticks[(ticks >= lo - 1e-9) & (ticks <= hi + 1e-9)]
    _tex = {0.: r"$0$", np.pi/2: r"$\pi/2$", np.pi: r"$\pi$",
            -np.pi/2: r"$-\pi/2$", -np.pi: r"$-\pi$"}
    labels = [next((v for k, v in _tex.items() if abs(t-k) < 1e-9),
                   rf"${t/np.pi:.2g}\pi$") for t in ticks]
    if which == "x":
        ax.set_xticks(ticks); ax.set_xticklabels(labels, fontsize=13)
    else:
        ax.set_yticks(ticks); ax.set_yticklabels(labels, fontsize=13)


def _overlay_nodes(ax, nodes, horiz_ax, vert_ax, plane_ax, fixed_val, a):
    col = {+1: "#E8000B", -1: "#1E64C8"}
    mrk = {+1: "+", -1: "-"}
    seen: set = set()
    for nd in nodes:
        k = nd["k"]; c = int(nd["chirality"])
        if abs(k[plane_ax] - fixed_val) > 0.05:
            continue
        kh = k[horiz_ax] * a
        kv = k[vert_ax]  * a
        lab = rf"$\chi={c:+d}$" if c not in seen else None
        seen.add(c)
        ax.scatter([kh], [kv], s=180, facecolors=col.get(c, "w"),
                   edgecolors="white", linewidths=1.5, zorder=7, label=lab)
        ax.text(kh, kv, mrk.get(c, "?"), color="white", ha="center",
                va="center", fontsize=11, fontweight="bold", zorder=8)


def _panel(fig, ax, XA, ZA, data, title, cbar_label,
           x_plot, z_plot, nodes, horiz_ax, vert_ax, plane_ax, fixed, a,
           symmetric=True, log=False):
    vmax = float(np.nanmax(np.abs(data)))
    if vmax < 1e-30: vmax = 1.0
    if log:
        pos = data[data > 0]
        norm = LogNorm(vmin=max(pos.min(), 1e-6*vmax), vmax=vmax) if pos.size else None
        cmap = "inferno"
    elif symmetric:
        norm = TwoSlopeNorm(vmin=-vmax, vcenter=0., vmax=vmax)
        cmap = custom_cmap_div
    else:
        norm = None
        cmap = "inferno"
    im = ax.pcolormesh(XA, ZA, data, shading="auto", cmap=cmap, norm=norm)
    _overlay_nodes(ax, nodes, horiz_ax, vert_ax, plane_ax, fixed, a)
    ax.set_xlabel(r"$k_x\,a$", fontsize=16)
    ax.set_ylabel(r"$k_z\,a$", fontsize=16)
    _pi_ticks(ax, x_plot, "x")
    _pi_ticks(ax, z_plot, "y")
    ax.tick_params(labelsize=12)
    ax.set_title(title, fontsize=13, pad=4)
    cb = fig.colorbar(im, ax=ax, pad=0.02)
    cb.set_label(cbar_label, fontsize=13)
    cb.ax.tick_params(labelsize=11)
    h, l = ax.get_legend_handles_labels()
    if h:
        dedup = {}
        for hh, ll in zip(h, l): dedup.setdefault(ll, hh)
        ax.legend(dedup.values(), dedup.keys(), fontsize=9,
                  loc="upper right", frameon=True, framealpha=0.6)


# ── physics ───────────────────────────────────────────────────────────────────

def _velocities(Hf, k_flat, dk=1e-3):
    H0 = np.array([Hf(*k) for k in k_flat], dtype=np.complex128)
    en, U = np.linalg.eigh(H0)
    Ud = np.conj(np.transpose(U, (0, 2, 1)))
    vel = {}
    for ax in range(3):
        sh = np.zeros(3); sh[ax] = dk
        Hp = np.array([Hf(*(k+sh)) for k in k_flat], dtype=np.complex128)
        Hm = np.array([Hf(*(k-sh)) for k in k_flat], dtype=np.complex128)
        vel[ax] = Ud @ ((Hp - Hm) / (2*dk)) @ U
    return en, U, Ud, vel


def _berry_curvature_component(en, va, vb):
    """Omega^{ab}_n = -2 Im sum_{m≠n} va_{nm} vb_{mn} / (en-em)^2."""
    nb = en.shape[1]
    eps = en[:, :, None] - en[:, None, :]          # (Nk, n, m)
    num = va * np.transpose(vb, (0, 2, 1))         # va_{nm} * vb_{mn}
    off = ~np.eye(nb, dtype=bool)
    with np.errstate(divide="ignore", invalid="ignore"):
        ratio = np.where(off[None] & (np.abs(eps) > 1e-15),
                         num / eps**2, 0+0j)
    return -2.0 * np.imag(ratio.sum(axis=2))       # (Nk, nb)


def _berry_connection(U, Ud, vel, axis):
    """A^a_n(k) = i <n|d/dk_a|n> ≈ i * U†_{nj} (dU/dk_a)_{jn}.

    Approximated via finite-difference velocity in band basis diagonal:
    A^a_n = i * v^a_{nn} / (en - en) → use off-diagonal structure instead.

    Here we use the gauge-invariant diagonal: A^a_n = Re(i * v_{nn}) / eps_nn
    which is zero. Instead we return the Berry connection vector field via
    the finite-difference of the eigenvectors:
        A^a_n(k) = i * <u_n(k) | d/dk_a u_n(k)>
    approximated as:
        A^a_n ≈ Im( diag( U†(k) @ U(k+dk) ) ) / dk
    (imaginary part of the overlap diagonal).
    """
    # We already have the velocity in band basis; the diagonal is v_{nn}
    # Berry connection: A^a_n = i <n|v_a|n> / (this is not standard)
    # Standard: A^a_n(k) = i sum_j u*_{nj}(k) d/dk_a u_{nj}(k)
    # Approximation: Im(diag(U†(k) U(k+dk))) / dk  (computed externally)
    # Here just return velocity diagonal (real part = 0, imag part = A)
    v_diag = np.diagonal(vel[axis], axis1=1, axis2=2)   # (Nk, nb) complex
    return np.imag(v_diag)   # gauge-dependent but locally informative


def compute(Hf, k_flat, dist, mu, T, dk=1e-3):
    en, U, Ud, vel = _velocities(Hf, k_flat, dk)
    occ = np.asarray(dist(en, mu, T), dtype=np.float64)

    Ox = _berry_curvature_component(en, vel[1], vel[2])
    Oy = _berry_curvature_component(en, vel[2], vel[0])
    Oz = _berry_curvature_component(en, vel[0], vel[1])
    Om = np.sqrt(Ox**2 + Oy**2 + Oz**2)

    # Berry connection via eigenvector finite difference (more accurate)
    # A^a_n = Im(diag(U†(k) @ U(k+dka))) / dk  — need k+dk grids
    # We approximate with the off-diagonal momentum matrix element formula:
    # A^a_n(k) = Im sum_{m≠n} v^a_{nm} / (en - em)  (length gauge)
    def berry_conn(axis):
        nb = en.shape[1]
        eps = en[:, :, None] - en[:, None, :]
        off = ~np.eye(nb, dtype=bool)
        v = vel[axis]
        with np.errstate(divide="ignore", invalid="ignore"):
            # A_n = sum_{m≠n} Im(v_{nm}) / (en - em)
            ratio = np.where(off[None] & (np.abs(eps) > 1e-15),
                             np.imag(v) / eps, 0.0)
        return ratio.sum(axis=2)   # (Nk, nb)  real

    Ax = berry_conn(0)
    Az = berry_conn(2)

    # Fermi-weighted sums
    def w(X): return (occ * X).sum(axis=1)

    return {
        "en": en, "occ": occ,
        "Ox": w(Ox), "Oy": w(Oy), "Oz": w(Oz), "Om": w(Om),
        "Ox_band": Ox, "Oy_band": Oy, "Oz_band": Oz,
        "Ax": w(Ax), "Az": w(Az),
    }


# ── main ──────────────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="inputs/inputParams.wsm_orenstein.cfg")
    ap.add_argument("--points", type=int, default=250)
    ap.add_argument("--dpi",    type=int, default=260)
    args = ap.parse_args()

    cfg = QXTIConfig.from_file(args.config)
    sim = QXTISimulation(config=cfg)
    Hf  = sim.build_hamiltonian()._matrix_at

    import importlib.util as ilu
    src = Path(str(cfg.hamiltonian.source_file))
    mp  = src if src.is_absolute() else PROJECT_ROOT / "models" / src
    sp  = ilu.spec_from_file_location("wsm_o", mp)
    mod = ilu.module_from_spec(sp); sp.loader.exec_module(mod)
    params = dict(cfg.hamiltonian.params)
    a = float(params.get("a", 1.0))

    dist = _resolve_distribution(cfg.susceptibility_solver.distribution)
    mu   = float(cfg.susceptibility_solver.fermi_level)
    T    = float(cfg.susceptibility_solver.temperature)

    nodes = mod.weyl_nodes_with_chirality(params) if hasattr(mod, "weyl_nodes_with_chirality") else []

    N = args.points
    kx_1d = (np.arange(N) + 0.5) * (2*np.pi/a) / N - np.pi/a
    kz_1d = (np.arange(N) + 0.5) * (2*np.pi/a) / N - np.pi/a
    KX, KZ = np.meshgrid(kx_1d, kz_1d, indexing="ij")
    k_flat = np.zeros((N*N, 3))
    k_flat[:, 0] = KX.ravel()
    k_flat[:, 2] = KZ.ravel()
    # ky = 0

    x_plot = kx_1d * a
    z_plot = kz_1d * a
    XA, ZA = np.meshgrid(x_plot, z_plot, indexing="ij")

    OUT.mkdir(parents=True, exist_ok=True)

    for delta in DELTAS:
        cfg2 = QXTIConfig.from_file(args.config)
        cfg2.hamiltonian.params["Delta"] = delta
        sim2 = QXTISimulation(config=cfg2)
        Hf2  = sim2.build_hamiltonian()._matrix_at

        print(f"[berry-kxkz] Δ={delta}  {N}x{N} grid ...", flush=True)
        res = compute(Hf2, k_flat, dist, mu, T)
        nb  = res["en"].shape[1]

        apply_paper_style()
        kw = dict(nodes=nodes, horiz_ax=0, vert_ax=2, plane_ax=1,
                  fixed=0.0, a=a, x_plot=x_plot, z_plot=z_plot)

        # ── Figure 1: Berry curvature weighted (4 panels) ────────────────────
        fig, axes = plt.subplots(2, 2, figsize=(13.0, 11.0))
        panels = [
            (axes[0,0], res["Ox"], r"$\Omega^x$",
             r"$\sum_n f_n\,\Omega^x_n(\mathbf{k})$"),
            (axes[0,1], res["Oy"], r"$\Omega^y$",
             r"$\sum_n f_n\,\Omega^y_n(\mathbf{k})$"),
            (axes[1,0], res["Oz"], r"$\Omega^z$",
             r"$\sum_n f_n\,\Omega^z_n(\mathbf{k})$"),
            (axes[1,1], res["Om"], r"$|\Omega|$",
             r"$\sum_n f_n\,|\Omega_n(\mathbf{k})|$"),
        ]
        for ax, data, title, clab in panels:
            sym = (title != r"$|\Omega|$")
            _panel(fig, ax, XA, ZA, data.reshape(N,N), title, clab,
                   symmetric=sym, **kw)
        delta_str = f"{delta:.3f}".replace(".", "p")
        fig.suptitle(
            rf"Berry curvature,  $k_y=0$,  $\Delta={delta}$",
            fontsize=15, y=1.01)
        fig.tight_layout()
        f1 = OUT / f"berry_curvature_kxkz_ky0_delta{delta_str}.png"
        fig.savefig(f1, dpi=args.dpi, facecolor="white", bbox_inches="tight")
        plt.close(fig)
        print(f"  -> {f1}", flush=True)

        # ── Figure 2: Berry connection (2 panels) ────────────────────────────
        fig, axes = plt.subplots(1, 2, figsize=(13.0, 5.6))
        for ax, data, title, clab in [
            (axes[0], res["Ax"].reshape(N,N), r"$A^x$",
             r"$\sum_n f_n\,A^x_n(\mathbf{k})$"),
            (axes[1], res["Az"].reshape(N,N), r"$A^z$",
             r"$\sum_n f_n\,A^z_n(\mathbf{k})$"),
        ]:
            _panel(fig, ax, XA, ZA, data, title, clab, **kw)
        fig.suptitle(
            rf"Berry connection,  $k_y=0$,  $\Delta={delta}$",
            fontsize=15, y=1.01)
        fig.tight_layout()
        f2 = OUT / f"berry_connection_kxkz_ky0_delta{delta_str}.png"
        fig.savefig(f2, dpi=args.dpi, facecolor="white", bbox_inches="tight")
        plt.close(fig)
        print(f"  -> {f2}", flush=True)

        # ── Figure 3: Omega^z per band (all 4 bands) ─────────────────────────
        ncols = 2; nrows = (nb + 1) // 2
        fig, axes = plt.subplots(nrows, ncols,
                                  figsize=(6.5*ncols, 5.5*nrows), squeeze=False)
        for n in range(nb):
            ax = axes[n // ncols][n % ncols]
            data = res["Oz_band"][:, n].reshape(N, N)
            _panel(fig, ax, XA, ZA, data,
                   rf"Band {n+1}: $\Omega^z_{{n}}$",
                   rf"$\Omega^z_{{{n+1}}}(\mathbf{{k}})$", **kw)
        for n in range(nb, nrows*ncols):
            axes[n//ncols][n%ncols].set_visible(False)
        fig.suptitle(
            rf"$\Omega^z$ per band,  $k_y=0$,  $\Delta={delta}$",
            fontsize=15, y=1.01)
        fig.tight_layout()
        f3 = OUT / f"berry_curvature_z_perband_kxkz_ky0_delta{delta_str}.png"
        fig.savefig(f3, dpi=args.dpi, facecolor="white", bbox_inches="tight")
        plt.close(fig)
        print(f"  -> {f3}", flush=True)

    print("[done]", flush=True)


if __name__ == "__main__":
    main()
