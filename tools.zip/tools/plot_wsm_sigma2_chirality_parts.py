#!/usr/bin/env python3
from __future__ import annotations

"""Paper-style sigma^(2) component plots split into Weyl-node sectors.

The sector contribution is reconstructed from the full tensor node-mask dataset:

    positive sector = full - no_pos
    negative sector = full - no_neg

The saved dataset stores chi^(2), so this script converts back to conductivity
using sigma^(2) = 2 i omega chi^(2).
"""

import argparse
import os
from pathlib import Path
import sys

import numpy as np

os.environ.setdefault("MPLCONFIGDIR", "/private/tmp")
os.environ.setdefault("XDG_CACHE_HOME", "/private/tmp")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import matplotlib

matplotlib.use("Agg")
import matplotlib as mpl
from matplotlib import pyplot as plt

from qxti.graphics.plot_susceptibility_tensor import apply_paper_style


DEFAULT_DATASET = Path("outputs/wsm_orenstein_order2_node_masks/order2_tensor_node_masks.npz")
DEFAULT_OUTPUT_DIR = Path("outputs/wsm_orenstein_order2_node_masks/sigma2_chirality_parts")
AXES = {"x": 0, "y": 1, "z": 2}
SECTOR_COLORS = {
    "positive": {
        "real": "#F67E7D",
        "imag": "#FFC0A7",
    },
    "negative": {
        "real": "#59819E",
        "imag": "#7C7AA2",
    },
}
LABELS = {
    "real": r"$\Re\,\sigma^{(2)}$",
    "imag": r"$\Im\,\sigma^{(2)}$",
}


def _component_indices(component: str) -> tuple[int, int, int]:
    key = str(component).strip().lower()
    if len(key) != 3 or any(axis not in AXES for axis in key):
        raise ValueError(f"Componente invalida {component!r}; usa algo como xyz o xzz.")
    return tuple(AXES[axis] for axis in key)  # type: ignore[return-value]


def _load_sigma2_sectors(dataset_path: Path, component: str) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    if not dataset_path.exists():
        raise FileNotFoundError(f"No existe el dataset requerido: {dataset_path}")
    data = np.load(dataset_path, allow_pickle=True)
    omega = np.asarray(data["omega"], dtype=np.float64)
    energy_ev = np.asarray(data["energy_ev"], dtype=np.float64)
    i, j, k = _component_indices(component)
    chi_full = np.asarray(data["chi_full"][:, i, j, k], dtype=np.complex128)
    chi_no_pos = np.asarray(data["chi_no_pos"][:, i, j, k], dtype=np.complex128)
    chi_no_neg = np.asarray(data["chi_no_neg"][:, i, j, k], dtype=np.complex128)
    sigma_pos = (chi_full - chi_no_pos) * (2j * omega)
    sigma_neg = (chi_full - chi_no_neg) * (2j * omega)
    return energy_ev, sigma_pos, sigma_neg


def _symmetric_ylim(*arrays: np.ndarray) -> tuple[float, float]:
    span = max(float(np.nanmax(np.abs(values))) for values in arrays)
    if not np.isfinite(span) or span <= 0.0:
        span = 1.0
    return -1.12 * span, 1.12 * span


def _save_square(fig, output_base: Path, *, dpi: int) -> list[Path]:
    output_base.parent.mkdir(parents=True, exist_ok=True)
    outputs = [output_base.with_suffix(".png"), output_base.with_suffix(".svg")]
    with mpl.rc_context({"savefig.bbox": "standard"}):
        fig.savefig(outputs[0], dpi=int(dpi), facecolor="white")
        fig.savefig(outputs[1], facecolor="white")
    return outputs


def _plot_one_sector(
    *,
    energy_ev: np.ndarray,
    values: np.ndarray,
    component: str,
    sector: str,
    output_dir: Path,
    dpi: int,
) -> list[Path]:
    real = np.real(values)
    imag = np.imag(values)
    ylo, yhi = _symmetric_ylim(real, imag)
    colors = SECTOR_COLORS[sector]

    fig, ax = plt.subplots(figsize=(10.8, 10.8))
    ax.fill_between(energy_ev, 0.0, real, color=colors["real"], alpha=0.20, lw=0, zorder=2)
    ax.plot(energy_ev, real, color=colors["real"], lw=4.4, label=LABELS["real"], zorder=3)
    ax.fill_between(energy_ev, 0.0, imag, color=colors["imag"], alpha=0.23, lw=0, zorder=2)
    ax.plot(energy_ev, imag, color=colors["imag"], lw=4.4, label=LABELS["imag"], zorder=3)

    ax.axhline(0.0, color="#AEB7C2", lw=1.15, zorder=1)
    ax.set_xlim(float(energy_ev[0]), float(energy_ev[-1]))
    ax.set_ylim(ylo, yhi)
    ax.set_box_aspect(1.0)
    ax.xaxis.set_major_locator(mpl.ticker.MultipleLocator(0.5))
    ax.xaxis.set_minor_locator(mpl.ticker.MultipleLocator(0.25))
    ax.xaxis.set_major_formatter(mpl.ticker.FormatStrFormatter("%g"))
    ax.set_xlabel(r"$\hbar\omega\;(\mathrm{eV})$", fontsize=48, labelpad=18)
    ax.set_ylabel(rf"$\sigma^{{(2)}}_{{{component}}}$", fontsize=52, labelpad=24)
    ax.tick_params(axis="both", which="major", labelsize=46, length=13, width=1.8)
    ax.tick_params(axis="both", which="minor", length=7, width=1.25)
    ax.ticklabel_format(axis="y", style="sci", scilimits=(-2, 3))
    ax.yaxis.get_offset_text().set_fontsize(38)
    ax.legend(
        frameon=False,
        fontsize=42,
        loc="upper right",
        handlelength=1.8,
        labelspacing=0.48,
    )
    for spine in ax.spines.values():
        spine.set_linewidth(1.8)
    fig.subplots_adjust(left=0.25, right=0.955, bottom=0.19, top=0.955)
    output_base = output_dir / f"sigma2_{component}_{sector}_chirality_sector_re_im_paper"
    outputs = _save_square(fig, output_base, dpi=dpi)
    plt.close(fig)
    return outputs


def plot_sigma2_chirality_parts(
    *,
    dataset_path: Path,
    output_dir: Path,
    components: tuple[str, ...],
    dpi: int,
) -> list[Path]:
    apply_paper_style()
    outputs: list[Path] = []
    for component in components:
        energy_ev, sigma_pos, sigma_neg = _load_sigma2_sectors(dataset_path, component)
        outputs.extend(
            _plot_one_sector(
                energy_ev=energy_ev,
                values=sigma_pos,
                component=component,
                sector="positive",
                output_dir=output_dir,
                dpi=dpi,
            )
        )
        outputs.extend(
            _plot_one_sector(
                energy_ev=energy_ev,
                values=sigma_neg,
                component=component,
                sector="negative",
                output_dir=output_dir,
                dpi=dpi,
            )
        )
    return outputs


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Grafica Re/Im de componentes sigma^(2) separadas por sectores de nodos Weyl."
    )
    parser.add_argument("--dataset", default=str(DEFAULT_DATASET))
    parser.add_argument("--output-dir", default=str(DEFAULT_OUTPUT_DIR))
    parser.add_argument("--components", default="xyz,xzz")
    parser.add_argument("--dpi", type=int, default=340)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    components = tuple(part.strip().lower() for part in str(args.components).split(",") if part.strip())
    outputs = plot_sigma2_chirality_parts(
        dataset_path=Path(args.dataset),
        output_dir=Path(args.output_dir),
        components=components,
        dpi=int(args.dpi),
    )
    for path in outputs:
        print(path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
