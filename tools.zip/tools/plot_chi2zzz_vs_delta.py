#!/usr/bin/env python3
"""Chi^(2)_zzz(2omega) vs frequency for Delta=0 (centrosymmetric) and Delta=0.5 (physical).

Shows Re, Im, and |chi^(2)_zzz| on the same axes to demonstrate that Delta
breaks inversion and activates the SHG response.
"""
from __future__ import annotations

import os, sys
from dataclasses import replace
from pathlib import Path

import numpy as np

os.environ.setdefault("MPLCONFIGDIR", "/private/tmp")
os.environ.setdefault("XDG_CACHE_HOME", "/private/tmp")
PROJECT_ROOT = Path(__file__).resolve().parents[1]
for _p in (PROJECT_ROOT, PROJECT_ROOT / "tools"):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

from qxti.core.config import QXTIConfig
from qxti.core.simulation import QXTISimulation
from qxti.analytics.theory_response import (
    build_k_integration_weights, compute_linear_response_spectrum)
from _shg_tensor_gridbased import order2_full_tensor_spectrum

_EV = 27.211386245988
OUT = Path("outputs/bz_chi_contribution/berry_curvature")


def compute_sigma1zz(cfg, omega_arr, label=""):
    print(f"[sigma1zz] {label}: computing {len(omega_arr)} frequencies, "
          f"grid={cfg.kgrid.k_points} ...")
    res = compute_linear_response_spectrum(cfg, omega_arr, progress=True)
    sigma1 = res["sigma"]   # (nw, 3, 3)
    return sigma1[:, 2, 2]  # zz component


def compute_chi2zzz(cfg, omega_arr, label=""):
    sim = QXTISimulation(config=cfg)
    ham = sim.build_hamiltonian()
    kg  = sim.build_kgrid(ham)
    wts = build_k_integration_weights(cfg, hamiltonian=ham, kgrid=kg)
    print(f"[chi2zzz] {label}: computing {len(omega_arr)} frequencies, "
          f"grid={cfg.kgrid.k_points} ...")
    sigma2 = order2_full_tensor_spectrum(ham, kg, omega_arr, wts,
                                         cfg.susceptibility_solver, progress=True)
    # sigma2: (nw, 3, 3, 3)
    chi2 = sigma2 / (2j * omega_arr[:, None, None, None])
    return chi2[:, 2, 2, 2]   # zzz component


def main():
    cfg_base = QXTIConfig.from_file("inputs/inputParams.wsm_orenstein.cfg")

    # Coarser grid for speed — still converged for comparison purposes
    grid = (30, 30, 30)
    cfg_base = replace(cfg_base, kgrid=replace(cfg_base.kgrid, k_points=grid))

    # Delta = 0.5  (physical, inversion broken)
    params_d1 = dict(cfg_base.hamiltonian.params)   # already has Delta=0.5
    cfg_d1 = cfg_base

    # Delta = 0  (centrosymmetric, chi^(2) must vanish)
    params_d0 = dict(cfg_base.hamiltonian.params); params_d0["Delta"] = 0.0
    cfg_d0 = replace(cfg_base,
                     hamiltonian=replace(cfg_base.hamiltonian, params=params_d0))

    emin, emax, nw = 0.05, 2.5, 120
    omega = np.linspace(emin / _EV, emax / _EV, nw)
    e_ev  = omega * _EV

    chi_d0 = compute_chi2zzz(cfg_d0, omega, label="Delta=0.0")
    chi_d1 = compute_chi2zzz(cfg_d1, omega, label="Delta=0.5")

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from qxti.graphics.plot_susceptibility_tensor import apply_paper_style
    apply_paper_style()

    col_d0 = {"re": "#5B9BD5", "im": "#70AD47", "abs": "#4472C4"}
    col_d1 = {"re": "#C00000", "im": "#FF8C00", "abs": "#7030A0"}

    fig, axes = plt.subplots(1, 3, figsize=(15, 5.0))

    def _plot(ax, y0, y1, ylabel, key):
        ax.axhline(0, color="0.7", lw=0.8, ls="-")
        ax.fill_between(e_ev, y0, alpha=0.15, color=col_d0[key], lw=0)
        ax.fill_between(e_ev, y1, alpha=0.15, color=col_d1[key], lw=0)
        ax.plot(e_ev, y0, color=col_d0[key], lw=1.8, label=r"$\Delta=0$")
        ax.plot(e_ev, y1, color=col_d1[key], lw=2.2, label=r"$\Delta=0.5$")
        ax.set_xlabel(r"$\hbar\omega$ (eV)", fontsize=13)
        ax.set_ylabel(ylabel, fontsize=12)
        ax.tick_params(labelsize=11)
        ax.ticklabel_format(axis="y", style="sci", scilimits=(-2, 3))
        ax.yaxis.get_offset_text().set_fontsize(10)
        ax.legend(fontsize=9.5, framealpha=0.9)
        ax.set_xlim(emin, emax)

    _plot(axes[0],
          np.real(chi_d0), np.real(chi_d1),
          r"$\mathrm{Re}\,\chi^{(2)}_{zzz}(2\omega)$  (arb.)",
          "re")
    axes[0].set_title(r"Real part", fontsize=13)

    _plot(axes[1],
          np.imag(chi_d0), np.imag(chi_d1),
          r"$\mathrm{Im}\,\chi^{(2)}_{zzz}(2\omega)$  (arb.)",
          "im")
    axes[1].set_title(r"Imaginary part", fontsize=13)

    _plot(axes[2],
          np.abs(chi_d0), np.abs(chi_d1),
          r"$|\chi^{(2)}_{zzz}(2\omega)|$  (arb.)",
          "abs")
    axes[2].set_title(r"Modulus", fontsize=13)

    # this plot has no BZ maps so no node markers needed

    fig.suptitle(
        r"SHG susceptibility $\chi^{(2)}_{zzz}(2\omega)$: "
        r"$\Delta=0$ (centrosymmetric) vs $\Delta=0.5$ (inversion broken)",
        fontsize=13, y=1.01)
    fig.tight_layout()

    OUT.mkdir(parents=True, exist_ok=True)
    f = OUT / "chi2zzz_vs_delta.png"
    fig.savefig(f, dpi=230, facecolor="white", bbox_inches="tight")
    plt.close(fig)
    print(f"[chi2zzz] wrote {f}")

    print(f"[chi2zzz] |chi_d0| max = {np.max(np.abs(chi_d0)):.3e}")
    print(f"[chi2zzz] |chi_d1| max = {np.max(np.abs(chi_d1)):.3e}")

    # ── sigma^(1)_zz panel ─────────────────────────────────────────────────
    sig_d0 = compute_sigma1zz(cfg_d0, omega, label="Delta=0.0")
    sig_d1 = compute_sigma1zz(cfg_d1, omega, label="Delta=0.5")

    fig2, axes2 = plt.subplots(1, 3, figsize=(15, 5.0))

    _plot(axes2[0],
          np.real(sig_d0), np.real(sig_d1),
          r"$\mathrm{Re}\,\sigma^{(1)}_{zz}(\omega)$  (arb.)",
          "re")
    axes2[0].set_title(r"Real part", fontsize=13)

    _plot(axes2[1],
          np.imag(sig_d0), np.imag(sig_d1),
          r"$\mathrm{Im}\,\sigma^{(1)}_{zz}(\omega)$  (arb.)",
          "im")
    axes2[1].set_title(r"Imaginary part", fontsize=13)

    _plot(axes2[2],
          np.abs(sig_d0), np.abs(sig_d1),
          r"$|\sigma^{(1)}_{zz}(\omega)|$  (arb.)",
          "abs")
    axes2[2].set_title(r"Modulus", fontsize=13)

    fig2.suptitle(
        r"Linear conductivity $\sigma^{(1)}_{zz}(\omega)$: "
        r"$\Delta=0$ vs $\Delta=0.5$",
        fontsize=13, y=1.01)
    fig2.tight_layout()
    f2 = OUT / "sigma1zz_vs_delta.png"
    fig2.savefig(f2, dpi=230, facecolor="white", bbox_inches="tight")
    plt.close(fig2)
    print(f"[sigma1zz] wrote {f2}")


if __name__ == "__main__":
    main()
