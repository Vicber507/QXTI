#!/usr/bin/env python3
"""Berry curvature maps for the Orenstein WSM on the kz=0 plane.

Physical note on what to plot:
  - Omega^z = 0 exactly on kz=0 because the monopole at a Weyl node is
    radial: Omega(k) ~ chi*(k-k0)/|k-k0|^3, so the z-component at kz=kz0=0
    is zero by symmetry.
  - Omega^x and Omega^y are nonzero on kz=0 and diverge at the nodes.
  - |Omega| = sqrt(Ox^2+Oy^2+Oz^2) is the total Berry flux and also peaks
    at the nodes.
  - To see Omega^z peaks, compute at kz = 0.2 a.u. (just above the nodal plane).

This script generates four panels:
  1. Omega^x (kz=0) — per band and weighted sum
  2. Omega^y (kz=0)
  3. |Omega| (kz=0) — total magnitude
  4. Omega^z (kz=0.2) — shows clear monopole peaks with chirality signs

Usage:
    python tools/plot_bz_berry_curvature.py [--points N] [--config CFG]
"""
from __future__ import annotations

import argparse
import importlib.util
import math
import os
import sys
from pathlib import Path

import numpy as np

os.environ.setdefault("MPLCONFIGDIR", "/private/tmp")
os.environ.setdefault("XDG_CACHE_HOME", "/private/tmp")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from qxti.core import QXTIConfig
from qxti.core.simulation import QXTISimulation
from qxti.analytics.theory_response import _resolve_distribution
from qxti.graphics.custom_cmap import custom_cmap_div
from qxti.graphics.plot_susceptibility_tensor import apply_paper_style

OUT_DIR = Path("outputs/bz_chi_contribution/berry_curvature")
_EV = 27.211386245988


def _load_model(cfg_path: str):
    cfg = QXTIConfig.from_file(cfg_path)
    source = Path(str(cfg.hamiltonian.source_file))
    model_path = source if source.is_absolute() else PROJECT_ROOT / "models" / source
    spec = importlib.util.spec_from_file_location(f"model_{model_path.stem}", model_path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return cfg, mod


def _pi_ticks(ax, axis_values, which="x"):
    lo, hi = float(axis_values[0]), float(axis_values[-1])
    step = np.pi / 2.0
    first = math.ceil((lo - 1e-9) / step) * step
    ticks = np.arange(first, hi + step * 0.5, step)
    ticks = ticks[(ticks >= lo - 1e-9) & (ticks <= hi + 1e-9)]
    _tex = {0.0: r"$0$", np.pi/2: r"$\pi/2$", np.pi: r"$\pi$",
            3*np.pi/2: r"$3\pi/2$", 2*np.pi: r"$2\pi$",
            -np.pi/2: r"$-\pi/2$", -np.pi: r"$-\pi$"}
    labels = [next((v for k2, v in _tex.items() if abs(t - k2) < 1e-9),
                   rf"${t/np.pi:.2g}\pi$") for t in ticks]
    if which == "x":
        ax.set_xticks(ticks); ax.set_xticklabels(labels, fontsize=15)
    else:
        ax.set_yticks(ticks); ax.set_yticklabels(labels, fontsize=15)


def _overlay_nodes(ax, mod, params, a_lat, k_offset, kz_fixed=0.0):
    if not hasattr(mod, "weyl_nodes_with_chirality"):
        return
    col = {+1: "#E8000B", -1: "#1E64C8"}
    mrk = {+1: "+", -1: "-"}
    seen: set = set()
    try:
        for nd in mod.weyl_nodes_with_chirality(params):
            k = nd["k"]; c = int(nd["chirality"])
            if abs(k[2] - kz_fixed) > 0.1:
                continue
            kx_p = k[0] * a_lat + k_offset
            ky_p = k[1] * a_lat + k_offset
            lab = rf"$\chi={c:+d}$" if c not in seen else None
            seen.add(c)
            ax.scatter([kx_p], [ky_p], s=200, facecolors=col.get(c, "grey"),
                       edgecolors="white", linewidths=1.8, zorder=7, label=lab)
            ax.text(kx_p, ky_p, mrk.get(c, "?"), color="white",
                    ha="center", va="center", fontsize=13, fontweight="bold", zorder=8)
    except Exception:
        pass


def _berry_component(energies, va, vb):
    """Omega^{ab}_n = -2 Im sum_{m!=n} va_{nm} vb_{mn} / (en-em)^2 per band."""
    nb = int(energies.shape[1])
    eps = energies[:, :, None] - energies[:, None, :]   # en - em: (Nk,n,m)
    num = va * np.transpose(vb, (0, 2, 1))              # va[n,m]*vb[m,n]: (Nk,n,m)
    offdiag = ~np.eye(nb, dtype=bool)
    with np.errstate(divide="ignore", invalid="ignore"):
        ratio = np.where(offdiag[None] & (np.abs(eps) > 1e-15),
                         num / eps**2, 0.0 + 0.0j)
    return -2.0 * np.imag(ratio.sum(axis=2))   # (Nk, nb)


def compute_all_bc(Hf, k_flat, dist, mu, temperature, dk=1e-3):
    """Compute all 3 Berry curvature components and magnitude."""
    H0 = np.array([Hf(*k) for k in k_flat], dtype=np.complex128)
    energies, U = np.linalg.eigh(H0)
    Udag = np.conj(np.transpose(U, (0, 2, 1)))

    def vel(axis):
        sh = np.zeros(3); sh[axis] = dk
        Hp = np.array([Hf(*(k+sh)) for k in k_flat], dtype=np.complex128)
        Hm = np.array([Hf(*(k-sh)) for k in k_flat], dtype=np.complex128)
        return Udag @ ((Hp - Hm) / (2*dk)) @ U

    vx = vel(0); vy = vel(1); vz = vel(2)
    occ = np.asarray(dist(energies, mu, temperature), dtype=np.float64)

    Ox = _berry_component(energies, vy, vz)   # Omega^x = -2Im vy_nm vz_mn/eps^2
    Oy = _berry_component(energies, vz, vx)   # Omega^y = -2Im vz_nm vx_mn/eps^2
    Oz = _berry_component(energies, vx, vy)   # Omega^z = -2Im vx_nm vy_mn/eps^2
    Omag = np.sqrt(Ox**2 + Oy**2 + Oz**2)

    return energies, occ, Ox, Oy, Oz, Omag


def weighted(Omega, occ):
    """Fermi-weighted sum: sum_n f_n * Omega_n -> (Nk,)."""
    return (occ * Omega).sum(axis=1)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="inputs/inputParams.wsm_orenstein.cfg")
    ap.add_argument("--points", type=int, default=200)
    ap.add_argument("--kz-off", type=float, default=0.2,
                    help="kz value for the Omega^z plot (a.u., default 0.2)")
    ap.add_argument("--dpi", type=int, default=230)
    args = ap.parse_args()

    cfg, mod = _load_model(args.config)
    params = mod.default_params() if hasattr(mod, "default_params") else {}
    a_lat = float(params.get("a", 1.0))
    k_offset = np.pi

    sim = QXTISimulation(config=cfg)
    Hf = sim.build_hamiltonian()._matrix_at
    dist = _resolve_distribution(cfg.susceptibility_solver.distribution)
    mu   = float(getattr(cfg.susceptibility_solver, "mu", 0.0))
    T    = float(getattr(cfg.susceptibility_solver, "temperature", 1e-4))

    N = int(args.points)
    # shifted grid: avoids landing on exact degeneracy
    kx_1d = (np.arange(N) + 0.5) * (2*np.pi/a_lat) / N - np.pi/a_lat
    ky_1d = (np.arange(N) + 0.5) * (2*np.pi/a_lat) / N - np.pi/a_lat
    KX, KY = np.meshgrid(kx_1d, ky_1d, indexing="ij")

    # --- kz=0 plane ---
    k_flat0 = np.zeros((N*N, 3))
    k_flat0[:, 0] = KX.ravel(); k_flat0[:, 1] = KY.ravel()

    print(f"[berry] kz=0 plane: {N}x{N} grid ...")
    en0, occ0, Ox0, Oy0, Oz0, Om0 = compute_all_bc(Hf, k_flat0, dist, mu, T)
    nb = int(en0.shape[1])

    # weighted sums -> (Nk,) -> (N,N)
    wx0 = weighted(Ox0, occ0).reshape(N, N)
    wy0 = weighted(Oy0, occ0).reshape(N, N)
    wm0 = weighted(Om0, occ0).reshape(N, N)
    print(f"[berry] kz=0 done. |Omega_x| max={np.abs(wx0).max():.3f}")

    # --- kz=kz_off plane ---
    kz_off = float(args.kz_off)
    k_flatZ = k_flat0.copy(); k_flatZ[:, 2] = kz_off

    print(f"[berry] kz={kz_off:.2f} plane: {N}x{N} grid ...")
    enZ, occZ, OxZ, OyZ, OzZ, OmZ = compute_all_bc(Hf, k_flatZ, dist, mu, T)
    wzZ = weighted(OzZ, occZ).reshape(N, N)
    print(f"[berry] kz={kz_off:.2f} done. |Omega_z| max={np.abs(wzZ).max():.3f}")

    # display axes
    x_plot = kx_1d * a_lat + k_offset
    y_plot = ky_1d * a_lat + k_offset

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.colors import TwoSlopeNorm, LogNorm

    apply_paper_style()
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    def _panel(ax, data, title, cbar_label, log=False, kz_fix=0.0):
        X, Y = np.meshgrid(x_plot, y_plot, indexing="ij")
        vmax = float(np.nanpercentile(np.abs(data), 99.5))
        if vmax < 1e-15:
            vmax = 1.0
        if log:
            pos = data[data > 0]
            vmin_log = float(np.percentile(pos, 5)) if pos.size else 1e-6
            norm = LogNorm(vmin=vmin_log, vmax=vmax)
            cmap_use = "inferno"
        else:
            norm = TwoSlopeNorm(vmin=-vmax, vcenter=0.0, vmax=vmax)
            cmap_use = custom_cmap_div
        im = ax.pcolormesh(X, Y, data, shading="auto", cmap=cmap_use, norm=norm)
        _overlay_nodes(ax, mod, params, a_lat, k_offset, kz_fix)
        ax.set_xlabel(r"$k_x a$", fontsize=16)
        ax.set_ylabel(r"$k_y a$", fontsize=16)
        ax.tick_params(labelsize=14)
        _pi_ticks(ax, x_plot, "x")
        _pi_ticks(ax, y_plot, "y")
        ax.set_title(title, fontsize=13, pad=4)
        cb = plt.colorbar(im, ax=ax, pad=0.02)
        cb.set_label(cbar_label, fontsize=13)
        cb.ax.tick_params(labelsize=12)
        handles, lbls = ax.get_legend_handles_labels()
        if handles:
            d = {}
            for h, l in zip(handles, lbls):
                d.setdefault(l, h)
            ax.legend(d.values(), d.keys(), fontsize=9, loc="upper right", frameon=True)

    # ── Figure 1: main 2×2 summary ──────────────────────────────────────────
    fig, axes = plt.subplots(2, 2, figsize=(13.5, 11.0))

    _panel(axes[0, 0], wx0,
           r"$\Omega^x(\mathbf{k})$,  $k_z=0$",
           r"$\Omega^x$ (a.u.)")

    _panel(axes[0, 1], wy0,
           r"$\Omega^y(\mathbf{k})$,  $k_z=0$",
           r"$\Omega^y$ (a.u.)")

    _panel(axes[1, 0], wm0,
           r"$|\mathbf{\Omega}|(\mathbf{k})$,  $k_z=0$  (total flux)",
           r"$|\mathbf{\Omega}|$ (a.u.)", log=False)

    _panel(axes[1, 1], wzZ,
           rf"$\Omega^z(\mathbf{{k}})$,  $k_z={kz_off:.2f}$ a.u. (above nodes)",
           r"$\Omega^z$ (a.u.)", kz_fix=kz_off)

    fig.suptitle(r"Berry curvature — Orenstein WSM (Fermi-weighted sum $\sum_n f_n\,\Omega_n$)",
                 fontsize=14)
    fig.tight_layout()
    f1 = OUT_DIR / "berry_curvature_summary.png"
    fig.savefig(f1, dpi=int(args.dpi), facecolor="white")
    plt.close(fig)
    print(f"[berry] wrote {f1}")

    # ── Figure 2: per-band Omega^z at kz_off ────────────────────────────────
    nrows = (nb + 1) // 2
    fig, axes = plt.subplots(nrows, 2, figsize=(13.0, 5.5 * nrows), squeeze=False)
    for n in range(nb):
        ax = axes[n // 2][n % 2]
        data = OzZ[:, n].reshape(N, N)
        _panel(ax, data,
               rf"Band $n={n+1}$:  $\Omega^z_n(\mathbf{{k}})$,  $k_z={kz_off:.2f}$ a.u.",
               r"$\Omega^z_n$ (a.u.)", kz_fix=kz_off)
    for n in range(nb, nrows * 2):
        axes[n // 2][n % 2].set_visible(False)
    fig.suptitle(rf"Berry curvature per band, $k_z={kz_off:.2f}$ a.u. (Orenstein WSM)",
                 fontsize=14)
    fig.tight_layout()
    f2 = OUT_DIR / f"berry_curvature_per_band_kz{kz_off:.2f}.png".replace(".","p")
    fig.savefig(f2, dpi=int(args.dpi), facecolor="white")
    plt.close(fig)
    print(f"[berry] wrote {f2}")

    # ── Summary stats ────────────────────────────────────────────────────────
    dk_area = (kx_1d[1]-kx_1d[0])*(ky_1d[1]-ky_1d[0])
    print("[berry] Integrated Omega per band (kz=0, fraction of 2pi):")
    for n in range(nb):
        for comp, arr in [("x", Ox0), ("y", Oy0), ("z", Oz0)]:
            val = arr[:, n].reshape(N, N).sum() * dk_area / (2*np.pi)
            print(f"  band {n+1}  Omega_{comp}: {val:+.4f}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
