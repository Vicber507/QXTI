#!/usr/bin/env python3
"""Berry connection A_z(kz) at kx=pi/2, ky=0 for the two crossing bands.

A^z_n(k) = i <u_n | d/dkz | u_n>  (diagonal, intraband)
           = i * v^z_{nn}(k) / ... using the relation A^z_{mn} = i v^z_{mn}/(em-en)

For the off-diagonal (interband) Berry connection between bands 1 and 2:
A^z_{12}(k) = i * v^z_{12}(k) / (e2 - e1)

Plots:
  (a) |A^z_{12}(kz)| — interband Berry connection (diverges at Weyl node)
  (b) Band dispersion E(kz) for context
"""
from __future__ import annotations

import os, sys, importlib.util
from pathlib import Path

import numpy as np

os.environ.setdefault("MPLCONFIGDIR", "/private/tmp")
os.environ.setdefault("XDG_CACHE_HOME", "/private/tmp")
PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

_EV = 27.211386245988
OUT = Path("outputs/susceptibility_maps/wsm_orenstein")

PALETTE = (
    "#59819E",
    "#7C7AA2",
    "#F67E7D",
    "#FFC0A7",
    "#6CC2BD",
    "#4A4A4A",
)
DELTAS = (0.5, 0.375, 0.25, 0.125, 0.0)


def main():
    spec = importlib.util.spec_from_file_location(
        "wsm_o", PROJECT_ROOT / "models" / "wsm_orenstein.py")
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from qxti.graphics.plot_susceptibility_tensor import apply_paper_style

    p_base = mod.default_params()
    a = float(p_base["a"])
    kx_fixed = np.pi / (2.0 * a)
    dk_vel = 1e-3

    N = 600
    kz_vals = np.linspace(-np.pi/4 / a, np.pi/4 / a, N)
    kz_a    = kz_vals * a

    apply_paper_style()
    fig, axes = plt.subplots(1, 2, figsize=(18, 9.5))

    for delta, color in zip(DELTAS, PALETTE):
        p = dict(p_base); p["Delta"] = float(delta)

        E_arr   = np.empty((N, 4))
        Az_diag = np.empty((N, 4))   # intraband A^z_nn (real, = 0 by convention in smooth gauge)
        Az_12   = np.empty(N)        # |interband A^z_{12}|
        Az_12_re = np.empty(N)
        Az_12_im = np.empty(N)

        for j, kz in enumerate(kz_vals):
            k = np.array([kx_fixed, 0.0, kz])
            H0 = mod.H(*k, p)
            e, U = np.linalg.eigh(H0)
            Ud = np.conj(U.T)
            # velocity dH/dkz
            sh = np.zeros(3); sh[2] = dk_vel
            dH = (mod.H(*(k+sh), p) - mod.H(*(k-sh), p)) / (2*dk_vel)
            vz = Ud @ dH @ U   # band basis

            E_arr[j] = e * _EV
            eps = e[:, None] - e[None, :]

            # interband Berry connection A^z_{mn} = i * v^z_{mn} / (em - en)
            # for m=1, n=2 (0-indexed: bands 1 and 2)
            eps12 = e[2] - e[1]   # e3 - e2 in 0-based
            if abs(eps12) > 1e-15:
                A12 = 1j * vz[1, 2] / eps12
            else:
                A12 = 0j
            Az_12[j]    = abs(A12)
            Az_12_re[j] = A12.real
            Az_12_im[j] = A12.imag

        # --- Left panel: |A^z_{12}(kz)| ---
        axes[0].plot(kz_a, Az_12, color=color, lw=2.8, zorder=3,
                     label=rf"$\Delta={delta:g}$")

        # --- Right panel: bands ---
        for i in [1, 2]:
            axes[1].plot(kz_a, E_arr[:, i], color=color, lw=2.8,
                         label=(rf"$\Delta={delta:g}$" if i == 1 else None))

    # Left panel styling
    axes[0].axvline(0.0, color="0.75", lw=0.8, ls=":", zorder=1)
    axes[0].set_xlabel(r"$k_z a$", fontsize=36, labelpad=13)
    axes[0].set_ylabel(r"$|\mathcal{A}^z_{12}(\mathbf{k})|$  (Bohr)", fontsize=30, labelpad=15)
    axes[0].set_title(r"Interband Berry connection", fontsize=28, pad=8)
    axes[0].set_xlim(-np.pi/4, np.pi/4)
    axes[0].set_box_aspect(1.0)
    ticks = np.array([-np.pi/4, 0.0, np.pi/4])
    labels = [r"$-\pi/4$", r"$0$", r"$\pi/4$"]
    for ax in axes:
        ax.set_xticks(ticks); ax.set_xticklabels(labels, fontsize=32)
        ax.tick_params(axis="both", which="major", labelsize=28, length=10, width=1.4)
        for spine in ax.spines.values():
            spine.set_linewidth(1.4)
    axes[0].legend(frameon=False, fontsize=26, handlelength=1.6, loc="upper right")

    # Right panel styling
    axes[1].axhline(0.0, color="0.55", lw=1.2, ls="--", zorder=1)
    axes[1].axvline(0.0, color="0.75", lw=0.8, ls=":", zorder=1)
    axes[1].set_xlabel(r"$k_z a$", fontsize=36, labelpad=13)
    axes[1].set_ylabel(r"$E\;(\mathrm{eV})$", fontsize=36, labelpad=15)
    axes[1].set_title(r"Band dispersion (bands 2 \& 3)", fontsize=28, pad=8)
    axes[1].set_xlim(-np.pi/4, np.pi/4)
    axes[1].set_ylim(-0.6, 0.6)
    axes[1].set_box_aspect(1.0)

    fig.suptitle(r"$k_x a = \pi/2$,  $k_y = 0$  — Berry connection and bands",
                 fontsize=28, y=1.01)
    fig.subplots_adjust(left=0.10, right=0.97, bottom=0.14, top=0.94, wspace=0.35)

    OUT.mkdir(parents=True, exist_ok=True)
    f = OUT / "wsm_orenstein_berry_connection_kxpi2_ky0.png"
    fig.savefig(f, dpi=200, facecolor="white", bbox_inches="tight")
    plt.close(fig)
    print(f"[Ac] wrote {f}")


if __name__ == "__main__":
    main()
